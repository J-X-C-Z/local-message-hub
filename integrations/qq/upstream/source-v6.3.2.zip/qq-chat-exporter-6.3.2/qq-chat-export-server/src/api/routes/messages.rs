mod roaming_export;

use std::collections::{HashMap, HashSet};
use std::path::{Path as FsPath, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex, OnceLock};

use axum::extract::{Extension, Json, State};
use axum::response::Response;
use chrono::{Local, NaiveDate};
use percent_encoding::{utf8_percent_encode, NON_ALPHANUMERIC};
use serde_json::{json, Value};

use qce_exporter::excel_exporter::{ExcelExporter, ExcelFormatOptions};
use qce_exporter::json_exporter::{
    ChunkedJsonlExportOptions, JsonExportMode, JsonExporter, JsonFormatOptions,
};
use qce_exporter::modern_html_exporter::{
    ChunkedHtmlExportOptions, HtmlExportOptions, ModernHtmlExporter,
};
use qce_exporter::text_exporter::{TextExporter, TextFormatOptions};
use qce_exporter::{ChatInfo, CleanMessage, DownloadedResourceIndex, ExportOptions};

use crate::api::helpers::{
    backfill_self_sender_names, chat_avatar_url, resolve_peer_uid, resolve_session_name,
    PeerUinResolver,
};
use crate::api::response::{self, ApiError, ErrorType, RequestId};
use crate::api::routes::groups::standalone_guard;
use crate::api::routes::roaming;
use crate::api::state::{MessageCacheEntry, RunMode, SharedState, CACHE_EXPIRE_TIME_MS};

const MAX_MESSAGE_CACHE_ENTRIES: usize = 64;
const MAX_QUEUED_TASKS: usize = 1000;
const MAX_CACHED_MESSAGES_PER_ENTRY: usize = 20_000;
const MAX_ROAMING_SCAN_DAYS: i64 = 1_461;
const DEFAULT_ROAMING_MAX_MESSAGES: usize = 50_000;
const MAX_ROAMING_MESSAGES: usize = 100_000;
const ROAMING_LATEST_MESSAGE_COUNT: i64 = 10;
const ROAMING_SINGLE_QUERY_CONCURRENCY: usize = 4;
const DEFAULT_ROAMING_MAX_SEQUENCE_QUERIES: usize = 50_000;
const MAX_ROAMING_SEQUENCE_QUERIES: usize = 100_000;
const ROAMING_CLOSING_LOOKAHEAD_DAYS: i64 = 31;
const ROAMING_DAILY_PROBE_DELAY_MS: u64 = 120;
const ROAMING_SEQUENCE_BATCH_DELAY_MS: u64 = 120;
const ROAMING_RETRY_BACKOFF_BASE_MS: u64 = 120;
const ROAMING_MAX_RETRIES: usize = 3;
const ROAMING_CANCEL_POLL_MS: u64 = 25;
use crate::clean_message_spool::{CleanMessageSpool, SpooledCleanMessageSource};
use crate::export_debug::ExportDebugSession;
use crate::fetcher::{
    acquire_history_query_permit, chat_type_prefix, classify_chat_type_binary,
    repair_group_message_sequence, BatchFetchConfig, BatchMessageFetcher, MessageFilter, Peer,
    SequenceRepairConfig, GROUP_CHAT_TYPE,
};
use crate::parser::simple_parser::ReplyImageIndex;
use crate::parser::{ForwardFetcher, SimpleMessageParser, SimpleParserOptions};
use crate::paths::PathManager;
use crate::resource::ResourceBatchSummary;
use crate::storage::ResourceInfo;

/// 当前毫秒时间戳。
fn now_ms() -> i64 {
    chrono::Utc::now().timestamp_millis()
}

/// 当前 ISO 时间串。
fn now_iso() -> String {
    chrono::Utc::now().to_rfc3339_opts(chrono::SecondsFormat::Millis, true)
}

/// 10 位秒级时间戳转毫秒（TS 同款启发式）。
fn normalize_to_ms(ts: i64) -> i64 {
    if ts > 1_000_000_000 && ts < 10_000_000_000 {
        ts * 1000
    } else {
        ts
    }
}

/// 从 JSON 里宽松取 i64（数字或数字字符串）。
fn loose_i64(value: Option<&Value>) -> Option<i64> {
    match value {
        Some(Value::Number(n)) => n.as_i64().or_else(|| n.as_f64().map(|f| f as i64)),
        Some(Value::String(s)) => s.trim().parse::<i64>().ok(),
        _ => None,
    }
}

fn loose_bool(value: Option<&Value>) -> bool {
    match value {
        Some(Value::Bool(value)) => *value,
        Some(Value::Number(value)) => value.as_i64().is_some_and(|value| value != 0),
        Some(Value::String(value)) => matches!(
            value.trim().to_ascii_lowercase().as_str(),
            "1" | "true" | "yes"
        ),
        _ => false,
    }
}

/// 从请求体解析 peer（chatType 允许数字或字符串）。
fn parse_peer(body: &Value) -> Option<(i64, String)> {
    let peer = body.get("peer")?;
    let chat_type = loose_i64(peer.get("chatType"))?;
    let peer_uid = peer
        .get("peerUid")
        .and_then(Value::as_str)
        .filter(|s| !s.is_empty())?
        .to_string();
    Some((chat_type, peer_uid))
}

/// 消息 msgTime → 毫秒。
fn msg_time_ms(message: &Value) -> i64 {
    normalize_to_ms(loose_i64(message.get("msgTime")).unwrap_or(0))
}

/// 把用户可见信息压成 Windows / Unicode 安全的文件名片段。
fn sanitize_chat_name(name: &str, max_length: usize) -> String {
    let mut safe = String::new();
    let mut last_underscore = false;
    for ch in name.chars() {
        let mapped = match ch {
            '<' | '>' | ':' | '"' | '/' | '\\' | '|' | '?' | '*' => '_',
            c if (c as u32) < 0x20 || c == '\u{7f}' => '_',
            c if c.is_whitespace() => '_',
            c => c,
        };
        if mapped == '_' {
            if !last_underscore {
                safe.push('_');
            }
            last_underscore = true;
        } else {
            safe.push(mapped);
            last_underscore = false;
        }
    }
    let mut safe = safe.trim_matches(['_', ' ', '.']).to_string();
    if safe.chars().count() > max_length {
        safe = safe.chars().take(max_length).collect();
        safe = safe.trim_end_matches(['_', ' ', '.']).to_string();
    }
    let reserved = matches!(
        safe.to_ascii_uppercase().as_str(),
        "CON"
            | "PRN"
            | "AUX"
            | "NUL"
            | "COM1"
            | "COM2"
            | "COM3"
            | "COM4"
            | "COM5"
            | "COM6"
            | "COM7"
            | "COM8"
            | "COM9"
            | "LPT1"
            | "LPT2"
            | "LPT3"
            | "LPT4"
            | "LPT5"
            | "LPT6"
            | "LPT7"
            | "LPT8"
            | "LPT9"
    );
    if reserved {
        safe.insert(0, '_');
    }
    safe
}

fn export_name_stem(
    chat_type_prefix: &str,
    peer_identity: &str,
    session_name: &str,
    date_str: &str,
    time_str: &str,
) -> String {
    let safe_name = sanitize_chat_name(session_name, 40);
    let safe_name = if safe_name.is_empty() {
        "未命名会话".to_string()
    } else {
        safe_name
    };
    let safe_identity = sanitize_chat_name(peer_identity, 32);
    let safe_identity = if safe_identity.is_empty() {
        "unknown".to_string()
    } else {
        safe_identity
    };
    format!("{chat_type_prefix}_{safe_name}_{safe_identity}_{date_str}_{time_str}")
}

/// 生成统一的人类可读导出文件名。
#[allow(clippy::too_many_arguments)]
fn build_export_file_name(
    chat_type_prefix: &str,
    peer_identity: &str,
    session_name: &str,
    date_str: &str,
    time_str: &str,
    extension: &str,
    _use_name_in_file_name: bool,
    _use_friendly_file_name: bool,
) -> String {
    format!(
        "{}.{extension}",
        export_name_stem(
            chat_type_prefix,
            peer_identity,
            session_name,
            date_str,
            time_str
        )
    )
}

/// 生成统一的人类可读导出目录名。
#[allow(clippy::too_many_arguments)]
fn build_export_dir_name(
    chat_type_prefix: &str,
    peer_identity: &str,
    session_name: &str,
    date_str: &str,
    time_str: &str,
    suffix: &str,
    _use_name_in_file_name: bool,
    _use_friendly_file_name: bool,
) -> String {
    format!(
        "{}{suffix}",
        export_name_stem(
            chat_type_prefix,
            peer_identity,
            session_name,
            date_str,
            time_str
        )
    )
}

fn collision_name(file_name: &str, suffix: u32) -> String {
    let (base, extension) = match file_name.rsplit_once('.') {
        Some((base, extension))
            if matches!(
                extension.to_ascii_lowercase().as_str(),
                "html" | "json" | "txt" | "xlsx" | "zip"
            ) =>
        {
            (base, &file_name[base.len()..])
        }
        _ => (file_name, ""),
    };
    format!("{base}_{suffix}{extension}")
}

fn reserved_export_paths() -> &'static Mutex<HashSet<PathBuf>> {
    static RESERVED: OnceLock<Mutex<HashSet<PathBuf>>> = OnceLock::new();
    RESERVED.get_or_init(|| Mutex::new(HashSet::new()))
}

/// 为运行中的任务预留唯一输出路径；预留项在任务结束时释放。
fn reserve_export_file_name(output_dir: &FsPath, file_name: &str) -> String {
    let mut reserved = reserved_export_paths()
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner);
    for suffix in 1_u32.. {
        let candidate = if suffix == 1 {
            file_name.to_string()
        } else {
            collision_name(file_name, suffix)
        };
        let path = output_dir.join(&candidate);
        if !path.exists() && !reserved.contains(&path) {
            reserved.insert(path);
            return candidate;
        }
    }
    unreachable!("u32 filename suffix space exhausted")
}

fn release_export_path(path: &FsPath) {
    reserved_export_paths()
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner)
        .remove(path);
}

/// Issue #192：根据是否使用自定义路径生成下载 URL。
fn generate_download_url(
    file_path: &FsPath,
    file_name: &str,
    custom_output_dir: &str,
    url_prefix: &str,
) -> String {
    if !custom_output_dir.trim().is_empty() {
        let encoded =
            utf8_percent_encode(&file_path.to_string_lossy(), NON_ALPHANUMERIC).to_string();
        return format!("/api/download-file?path={encoded}");
    }
    format!("{url_prefix}{file_name}")
}

/// 生成 `export_{ms}_{rand9}` 风格任务 ID。
fn generate_task_id(prefix: &str) -> String {
    let rand: String = uuid::Uuid::new_v4()
        .simple()
        .to_string()
        .chars()
        .take(9)
        .collect();
    format!("{prefix}_{}_{rand}", now_ms())
}

/// 本地日期 / 时间字符串（YYYYMMDD / HHMMSSmmm）。
fn local_date_time_strings() -> (String, String) {
    let now = chrono::Local::now();
    (
        now.format("%Y%m%d").to_string(),
        now.format("%H%M%S%3f").to_string(),
    )
}

/// issue #363：把资源摘要翻译成给用户看的一句话。
fn build_resource_summary_message(summary: Option<&ResourceBatchSummary>) -> Option<String> {
    let summary = summary?;
    if summary.attempted == 0 {
        return None;
    }
    let reused = summary.already_available + summary.downloaded;
    let head = format!("资源 {reused}/{}", summary.attempted);
    if summary.failed == 0 {
        return Some(head);
    }
    Some(format!(
        "{head}，失败 {}。文本记录已完整导出。\
         部分多媒体文件因 QQ 接口限流或暂时降级导致下载失败。\
         修复：可在 QQ 客户端中手动点开这些图片以刷新缓存，\
         随后在 QCE 任务列表中点击「重试」补齐。",
        summary.failed
    ))
}

/// 发件人过滤器。
fn build_sender_filter(filter: &Value) -> Option<(HashSet<String>, HashSet<String>)> {
    fn normalize(list: Option<&Value>) -> HashSet<String> {
        list.and_then(Value::as_array)
            .map(|arr| {
                arr.iter()
                    .filter_map(|v| match v {
                        Value::String(s) => Some(s.trim().to_string()),
                        Value::Number(n) => Some(n.to_string()),
                        _ => None,
                    })
                    .filter(|s| !s.is_empty())
                    .collect()
            })
            .unwrap_or_default()
    }
    let include = normalize(filter.get("includeUserUins"));
    let exclude = normalize(filter.get("excludeUserUins"));
    if include.is_empty() && exclude.is_empty() {
        None
    } else {
        Some((include, exclude))
    }
}

/// 应用发件人过滤器。
fn apply_sender_filter(messages: Vec<Value>, filter: &Value) -> Vec<Value> {
    let Some((include, exclude)) = build_sender_filter(filter) else {
        return messages;
    };
    messages
        .into_iter()
        .filter(|msg| {
            let uin = msg
                .get("senderUin")
                .map(|v| match v {
                    Value::String(s) => s.trim().to_string(),
                    Value::Number(n) => n.to_string(),
                    _ => String::new(),
                })
                .unwrap_or_default();
            if !exclude.is_empty() && exclude.contains(&uin) {
                return false;
            }
            if !include.is_empty() && !include.contains(&uin) {
                return false;
            }
            true
        })
        .collect()
}

/// 更新内存任务表并持久化到数据库。
fn apply_task_patch(task: Option<&mut Value>, patch: &Value) -> Option<Value> {
    let task = task?;
    if !should_apply_task_patch(task, patch) {
        return None;
    }
    if let (Some(target), Some(source)) = (task.as_object_mut(), patch.as_object()) {
        for (key, value) in source {
            if value.is_null() {
                target.remove(key);
            } else {
                target.insert(key.clone(), value.clone());
            }
        }
    }
    Some(task.clone())
}

fn apply_live_progress_patch(task: Option<&mut Value>, patch: &Value) -> Option<Value> {
    let task = task?;
    if !matches!(
        task.get("status").and_then(Value::as_str),
        Some("queued" | "pending" | "running")
    ) {
        return None;
    }
    apply_task_patch(Some(task), patch)
}

fn publish_live_task_progress<F>(task: Option<&Value>, publish: F) -> bool
where
    F: FnOnce(&Value),
{
    let Some(task) = task else {
        return false;
    };
    if !matches!(
        task.get("status").and_then(Value::as_str),
        Some("queued" | "pending" | "running")
    ) {
        return false;
    }
    publish(task);
    true
}

async fn update_task(state: &SharedState, task_id: &str, patch: Value) -> Option<Value> {
    // Keep the task mutation and its database snapshot in the same ordering
    // boundary used by cancellation. Otherwise an older running snapshot can
    // acquire the database lock after a newer forced cancellation write.
    let mut tasks = state.export_tasks.lock().await;
    let updated = apply_task_patch(tasks.get_mut(task_id), &patch)?;
    if let Err(error) = state.db.save_task(&updated, &updated, false).await {
        tracing::warn!("[ApiServer] 保存任务到数据库失败: {error}");
    }
    Some(updated)
}

fn should_apply_task_patch(task: &Value, patch: &Value) -> bool {
    task.get("status").and_then(Value::as_str) != Some("cancelled")
        || patch.get("status").and_then(Value::as_str) == Some("cancelled")
}

fn fallback_terminal_roaming_scan(task: &Value, stop_reason: &str) -> Option<Value> {
    if task.get("taskKind").and_then(Value::as_str) != Some("roaming_export") {
        return None;
    }
    let mut scan = task.get("roamingScan")?.clone();
    let scan_object = scan.as_object_mut()?;
    if scan_object.get("stopReason").and_then(Value::as_str) != Some("running") {
        return None;
    }
    scan_object.insert("partial".to_string(), Value::Bool(true));
    scan_object.insert(
        "stopReason".to_string(),
        Value::String(stop_reason.to_string()),
    );
    scan_object.insert("currentDate".to_string(), Value::Null);
    Some(scan)
}

/// issue #668：独立模式下没有 bridge，实时数据接口直接返回
/// `503 STANDALONE_MODE`，而不是误导性的「bridge 传输错误」。
fn standalone_guard_with(state: &SharedState, feature: &str) -> Option<ApiError> {
    state
        .is_standalone()
        .then(|| RunMode::standalone_mode_error(feature))
}

fn task_roaming_scan(task: &Value) -> Option<&Value> {
    if task.get("taskKind").and_then(Value::as_str) != Some("roaming_export") {
        return None;
    }
    task.get("roamingScan")
}

fn export_ws_event(event_type: &str, mut data: Value, roaming_scan: Option<&Value>) -> Value {
    if let Some(roaming_scan) = roaming_scan {
        data["taskKind"] = Value::String("roaming_export".to_string());
        data["roamingScan"] = roaming_scan.clone();
    }
    json!({
        "type": event_type,
        "data": data,
    })
}

/// 广播导出进度；漫游任务同时携带最新扫描摘要，普通任务保持原有契约。
fn broadcast_progress(
    state: &SharedState,
    task_id: &str,
    status: &str,
    progress: i64,
    message: &str,
    count: usize,
    roaming_scan: Option<&Value>,
) {
    state.broadcast_ws(&export_ws_event(
        "export_progress",
        json!({
            "taskId": task_id,
            "status": status,
            "progress": progress,
            "message": message,
            "messageCount": count,
        }),
        roaming_scan,
    ));
}

/// Apply a live-state patch and publish its WebSocket event under the same
/// task lock used by cancellation.
async fn update_and_broadcast_progress(
    state: &SharedState,
    task_id: &str,
    patch: Value,
    progress: i64,
    message: &str,
    count: usize,
) -> bool {
    // The task mutation and event publication share the export-task lock with
    // `cancel_task`. Whichever side acquires it first determines the observable
    // order: progress is published before a later cancellation, while a
    // cancellation that wins first makes `apply_task_patch` reject this update.
    // Keep persistence in the same boundary too: a progress snapshot that was
    // accepted first must reach the database before a later cancellation.
    let mut tasks = state.export_tasks.lock().await;
    let Some(updated) = apply_live_progress_patch(tasks.get_mut(task_id), &patch) else {
        return false;
    };
    if let Err(error) = state.db.save_task(&updated, &updated, false).await {
        tracing::warn!("[ApiServer] 保存任务到数据库失败: {error}");
    }
    let status = updated
        .get("status")
        .and_then(Value::as_str)
        .unwrap_or("running");
    broadcast_progress(
        state,
        task_id,
        status,
        progress,
        message,
        count,
        task_roaming_scan(&updated),
    );
    true
}

/// Publish best-effort resource progress only while the task is still live.
///
/// Resource callbacks are synchronous, so they cannot await the task mutex.
/// `try_lock` deliberately drops a non-critical update under contention; when
/// it succeeds, the live-state check and publication are atomic with respect to
/// cancellation because both use `export_tasks`.
fn try_broadcast_live_progress(
    state: &SharedState,
    task_id: &str,
    progress: i64,
    message: &str,
    count: usize,
) -> bool {
    let Ok(tasks) = state.export_tasks.try_lock() else {
        return false;
    };
    publish_live_task_progress(tasks.get(task_id), |task| {
        broadcast_progress(
            state,
            task_id,
            "running",
            progress,
            message,
            count,
            task_roaming_scan(task),
        );
    })
}

/// `POST /api/messages/fetch` — 分页抓取消息（10 分钟缓存 + 懒加载分页）。
pub async fn fetch_messages(
    State(state): State<SharedState>,
    Extension(RequestId(request_id)): Extension<RequestId>,
    Json(body): Json<Value>,
) -> Response {
    if let Some(err) = standalone_guard(&state) {
        return response::error(&err, &request_id);
    }
    let Some((chat_type, peer_uid)) = parse_peer(&body) else {
        let err = ApiError::validation("peer参数不完整", "INVALID_PEER");
        return response::error(&err, &request_id);
    };
    let filter = body.get("filter").cloned().unwrap_or(Value::Null);
    let batch_size = loose_i64(body.get("batchSize"))
        .unwrap_or(5000)
        .clamp(1, 5000);
    let page = loose_i64(body.get("page")).unwrap_or(1).clamp(1, 1_000_000);
    let limit = loose_i64(body.get("limit")).unwrap_or(50).clamp(1, 2000);
    let force_refresh = loose_bool(body.get("forceRefresh")) || loose_bool(body.get("bypassCache"));

    let start_time = loose_i64(filter.get("startTime"));
    let end_time = loose_i64(filter.get("endTime"));
    if let (Some(start), Some(end)) = (start_time, end_time) {
        if end < start {
            let err = ApiError::validation("结束时间不能早于开始时间", "INVALID_TIME_RANGE");
            return response::error(&err, &request_id);
        }
    }

    let now = now_ms();
    let cache_key = format!(
        "{chat_type}_{peer_uid}_{}_{}",
        start_time.unwrap_or(0),
        end_time.unwrap_or(now)
    );

    if force_refresh {
        state
            .invalidate_message_cache_for_peer(chat_type, &peer_uid)
            .await;
    }

    let cached = {
        let mut cache = state.message_cache.lock().await;
        match cache.get(&cache_key) {
            Some(entry) if now - entry.last_update > CACHE_EXPIRE_TIME_MS => {
                cache.remove(&cache_key);
                None
            }
            Some(entry) => Some(entry.clone()),
            None => None,
        }
    };

    let mut cache_hit = cached.is_some();
    let mut all_messages: Vec<Value> = Vec::new();
    let mut has_more = false;
    if let Some(entry) = cached {
        all_messages = entry.messages;
        has_more = entry.has_more;
    }

    let peer = Peer {
        chat_type,
        peer_uid: peer_uid.clone(),
        guild_id: None,
    };
    if chat_type == GROUP_CHAT_TYPE && !all_messages.is_empty() {
        match repair_group_message_sequence(
            &state.napcat,
            &peer,
            &mut all_messages,
            SequenceRepairConfig::default(),
        )
        .await
        {
            Ok(report) if report.initial_gap_count > 0 => {
                tracing::info!(
                    "[Messages] 缓存消息序列修复完成: gaps={}, missing={}, added={}, rounds={}",
                    report.initial_gap_count,
                    report.initial_missing_positions,
                    report.repaired_messages,
                    report.rounds
                );
                state
                    .invalidate_message_cache_for_peer(chat_type, &peer_uid)
                    .await;
                cache_hit = false;
            }
            Ok(_) => {}
            Err(error) => {
                tracing::warn!("[Messages] 缓存消息序列未能确认完整，继续返回已有消息: {error}");
                state
                    .invalidate_message_cache_for_peer(chat_type, &peer_uid)
                    .await;
                cache_hit = false;
            }
        }
    }

    let start_index = usize::try_from((page - 1).saturating_mul(limit)).unwrap_or(0);
    let end_index = usize::try_from(page.saturating_mul(limit)).unwrap_or(usize::MAX);

    let paginate_response = |messages: &[Value], has_next: bool, hit: bool| -> Response {
        let total = messages.len();
        let slice: Vec<Value> = messages
            .iter()
            .skip(start_index)
            .take(end_index.saturating_sub(start_index))
            .cloned()
            .collect();
        let total_pages = total.div_ceil(usize::try_from(limit).unwrap_or(1));
        response::success(
            json!({
                "messages": slice,
                "totalCount": total,
                "currentPage": page,
                "totalPages": total_pages,
                "hasNext": has_next,
                "cacheHit": hit,
                "fetchedAt": now_iso(),
            }),
            &request_id,
        )
    };

    // 缓存足够当前页，或缓存已是全部消息 → 直接返回。
    if cache_hit {
        if all_messages.len() > end_index {
            return paginate_response(&all_messages, has_more, true);
        }
        if !has_more {
            return paginate_response(&all_messages, false, true);
        }
    }

    // 懒加载：目标 = 当前页 + 富余 10 页，减少请求次数。
    let fetcher = BatchMessageFetcher::new(
        Arc::new(state.napcat.clone()),
        BatchFetchConfig {
            batch_size,
            timeout_ms: 30_000,
            retry_count: 3,
            ..BatchFetchConfig::default()
        },
    );
    let fetch_filter = MessageFilter {
        start_time: Some(start_time.unwrap_or(0)),
        end_time: Some(end_time.unwrap_or(now)),
        ..MessageFilter::default()
    };

    let target_count = usize::try_from(page * limit + limit * 10).unwrap_or(usize::MAX);
    let mut seen_ids: HashSet<String> = all_messages
        .iter()
        .filter_map(|m| m.get("msgId").and_then(Value::as_str).map(str::to_string))
        .collect();
    let mut previous = None;
    let mut reached_target = false;

    loop {
        let mut batch = match fetcher
            .fetch_next_batch(&peer, &fetch_filter, previous.as_ref())
            .await
        {
            Ok(Some(batch)) => batch,
            Ok(None) => break,
            Err(error) => {
                let err = ApiError::internal(format!("获取消息失败: {error}"), "FETCH_FAILED");
                return response::error(&err, &request_id);
            }
        };
        for message in batch.messages.drain(..) {
            let msg_id = message
                .get("msgId")
                .and_then(Value::as_str)
                .unwrap_or_default()
                .to_string();
            if msg_id.is_empty() || seen_ids.insert(msg_id) {
                all_messages.push(message);
            }
        }
        if all_messages.len() >= target_count {
            reached_target = true;
            break;
        }
        previous = Some(batch);
    }
    has_more = reached_target;

    if chat_type == GROUP_CHAT_TYPE && !all_messages.is_empty() {
        match repair_group_message_sequence(
            &state.napcat,
            &peer,
            &mut all_messages,
            SequenceRepairConfig::default(),
        )
        .await
        {
            Ok(report) if report.initial_gap_count > 0 => {
                tracing::info!(
                    "[Messages] 消息序列修复完成: gaps={}, missing={}, added={}, rounds={}",
                    report.initial_gap_count,
                    report.initial_missing_positions,
                    report.repaired_messages,
                    report.rounds
                );
                state
                    .invalidate_message_cache_for_peer(chat_type, &peer_uid)
                    .await;
            }
            Ok(_) => {}
            Err(error) => {
                tracing::warn!("[Messages] 消息序列未能确认完整，继续返回已获取消息: {error}");
                state
                    .invalidate_message_cache_for_peer(chat_type, &peer_uid)
                    .await;
            }
        }
    }

    // 按时间戳倒序。
    all_messages.sort_by_key(|m| std::cmp::Reverse(msg_time_ms(m)));

    let has_next = all_messages.len() > end_index || has_more;
    let paginated = paginate_response(&all_messages, has_next, cache_hit);
    if all_messages.len() <= MAX_CACHED_MESSAGES_PER_ENTRY {
        let mut cache = state.message_cache.lock().await;
        if cache.len() >= MAX_MESSAGE_CACHE_ENTRIES && !cache.contains_key(&cache_key) {
            if let Some(oldest_key) = cache
                .iter()
                .min_by_key(|(_, entry)| entry.last_update)
                .map(|(key, _)| key.clone())
            {
                cache.remove(&oldest_key);
            }
        }
        cache.insert(
            cache_key,
            MessageCacheEntry {
                messages: all_messages,
                last_update: now_ms(),
                has_more,
            },
        );
    }

    paginated
}

#[derive(Clone, Debug)]
struct RoamingExportConfig {
    start_time: i64,
    end_time: i64,
    start_date: NaiveDate,
    end_date: NaiveDate,
    requested_days: usize,
    max_messages: usize,
    max_sequence_queries: usize,
}

#[derive(Clone, Debug)]
struct RoamingScanSummary {
    requested_days: usize,
    probed_days: usize,
    scanned_days: usize,
    calendar_queries: usize,
    calendar_errors: usize,
    anchor_days: usize,
    exact_queries: usize,
    latest_queries: usize,
    sequence_queries: usize,
    empty_sequence_queries: usize,
    gap_count: usize,
    mismatched_anchors: usize,
    unresolved_anchors: usize,
    untimestamped_messages: usize,
    raw_messages_seen: usize,
    message_count: usize,
    max_messages: usize,
    max_sequence_queries: usize,
    closing_anchor_found: bool,
    partial: bool,
    stop_reason: String,
    current_date: Option<NaiveDate>,
}

impl RoamingScanSummary {
    fn new(config: &RoamingExportConfig) -> Self {
        Self {
            requested_days: config.requested_days,
            probed_days: 0,
            scanned_days: 0,
            calendar_queries: 0,
            calendar_errors: 0,
            anchor_days: 0,
            exact_queries: 0,
            latest_queries: 0,
            sequence_queries: 0,
            empty_sequence_queries: 0,
            gap_count: 0,
            mismatched_anchors: 0,
            unresolved_anchors: 0,
            untimestamped_messages: 0,
            raw_messages_seen: 0,
            message_count: 0,
            max_messages: config.max_messages,
            max_sequence_queries: config.max_sequence_queries,
            closing_anchor_found: false,
            partial: false,
            stop_reason: "running".to_string(),
            current_date: None,
        }
    }

    fn as_value(&self) -> Value {
        json!({
            "bounded": true,
            "calendarAdvisory": true,
            "serverCompletenessProven": false,
            "requestedDays": self.requested_days,
            "probedDays": self.probed_days,
            "scannedDays": self.scanned_days,
            "calendarQueries": self.calendar_queries,
            "calendarErrors": self.calendar_errors,
            "anchorDays": self.anchor_days,
            "exactQueries": self.exact_queries,
            "latestQueries": self.latest_queries,
            "sequenceQueries": self.sequence_queries,
            "emptySequenceQueries": self.empty_sequence_queries,
            "gapCount": self.gap_count,
            "mismatchedAnchors": self.mismatched_anchors,
            "unresolvedAnchors": self.unresolved_anchors,
            "untimestampedMessages": self.untimestamped_messages,
            "rawMessagesSeen": self.raw_messages_seen,
            "messageCount": self.message_count,
            "maxMessages": self.max_messages,
            "maxSequenceQueries": self.max_sequence_queries,
            "closingAnchorFound": self.closing_anchor_found,
            "partial": self.partial,
            "stopReason": self.stop_reason,
            "currentDate": self.current_date.map(|date| date.to_string()),
        })
    }
}

#[derive(Debug)]
struct TaskFailure {
    message: String,
    code: String,
    http_status: u16,
    roaming_scan: Option<Value>,
}

impl TaskFailure {
    fn export(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
            code: "EXPORT_FAILED".to_string(),
            http_status: axum::http::StatusCode::INTERNAL_SERVER_ERROR.as_u16(),
            roaming_scan: None,
        }
    }

    fn from_api(error: ApiError) -> Self {
        Self {
            message: error.message,
            code: error.code,
            http_status: error.status.as_u16(),
            roaming_scan: None,
        }
    }

    fn roaming_stop_reason(&self) -> &'static str {
        if self.message == "任务已被用户停止" {
            return "cancelled";
        }
        match self.code.as_str() {
            "ROAMING_API_UNAVAILABLE" => "native_api_unavailable",
            "ROAMING_QUERY_FAILED" => "native_query_failed",
            "INVALID_ROAMING_RESPONSE" => "invalid_native_response",
            _ => "scan_failed",
        }
    }
}

fn required_roaming_seconds(filter: &Value, field: &str) -> Result<i64, ApiError> {
    let seconds = strict_decimal_i64(filter.get(field)).ok_or_else(|| {
        ApiError::validation(
            format!("filter.{field} 必须是 Unix 秒级整数"),
            "INVALID_ROAMING_TIME_RANGE",
        )
    })?;
    if !(1..=9_999_999_999).contains(&seconds) {
        return Err(ApiError::validation(
            format!("filter.{field} 必须是 Unix 秒级整数，不能使用毫秒时间戳"),
            "INVALID_ROAMING_TIME_RANGE",
        ));
    }
    Ok(seconds)
}

fn strict_decimal_i64(value: Option<&Value>) -> Option<i64> {
    match value {
        Some(Value::Number(number)) => number.as_i64(),
        Some(Value::String(number))
            if !number.is_empty() && number.bytes().all(|byte| byte.is_ascii_digit()) =>
        {
            number.parse().ok()
        }
        _ => None,
    }
}

fn local_date_from_seconds(seconds: i64) -> Result<NaiveDate, ApiError> {
    chrono::DateTime::from_timestamp(seconds, 0)
        .map(|value| value.with_timezone(&Local).date_naive())
        .ok_or_else(|| {
            ApiError::validation("漫游查询时间超出支持范围", "INVALID_ROAMING_TIME_RANGE")
        })
}

fn parse_positive_limit(
    value: Option<&Value>,
    field: &str,
    default: usize,
    maximum: usize,
) -> Result<usize, ApiError> {
    let Some(value) = value else {
        return Ok(default);
    };
    let Some(number) = strict_decimal_i64(Some(value)) else {
        return Err(ApiError::validation(
            format!("roaming.{field} 必须是正整数"),
            "INVALID_ROAMING_LIMIT",
        ));
    };
    let Ok(number) = usize::try_from(number) else {
        return Err(ApiError::validation(
            format!("roaming.{field} 必须是正整数"),
            "INVALID_ROAMING_LIMIT",
        ));
    };
    if number == 0 || number > maximum {
        return Err(ApiError::validation(
            format!("roaming.{field} 必须在 1..={maximum} 之间"),
            "INVALID_ROAMING_LIMIT",
        ));
    }
    Ok(number)
}

fn parse_roaming_export_config(body: &Value) -> Result<RoamingExportConfig, ApiError> {
    roaming::parse_private_peer(body)?;
    let filter = body
        .get("filter")
        .and_then(Value::as_object)
        .ok_or_else(|| {
            ApiError::validation(
                "filter.startTime 和 filter.endTime 为必填的 Unix 秒级时间范围",
                "INVALID_ROAMING_TIME_RANGE",
            )
        })?;
    let filter = Value::Object(filter.clone());
    let start_time = required_roaming_seconds(&filter, "startTime")?;
    let end_time = required_roaming_seconds(&filter, "endTime")?;
    if end_time < start_time {
        return Err(ApiError::validation(
            "filter.endTime 不能早于 filter.startTime",
            "INVALID_ROAMING_TIME_RANGE",
        ));
    }
    let start_date = local_date_from_seconds(start_time)?;
    let end_date = local_date_from_seconds(end_time)?;
    let requested_days_i64 = (end_date - start_date).num_days() + 1;
    if requested_days_i64 > MAX_ROAMING_SCAN_DAYS {
        return Err(ApiError::validation(
            format!("漫游扫描最多支持 {MAX_ROAMING_SCAN_DAYS} 个本机日历日"),
            "ROAMING_RANGE_TOO_LARGE",
        ));
    }
    let requested_days = usize::try_from(requested_days_i64)
        .map_err(|_| ApiError::validation("漫游查询日期范围无效", "INVALID_ROAMING_TIME_RANGE"))?;
    let max_messages = parse_positive_limit(
        body.pointer("/roaming/maxMessages"),
        "maxMessages",
        DEFAULT_ROAMING_MAX_MESSAGES,
        MAX_ROAMING_MESSAGES,
    )?;
    let max_sequence_queries = parse_positive_limit(
        body.pointer("/roaming/maxSequenceQueries"),
        "maxSequenceQueries",
        DEFAULT_ROAMING_MAX_SEQUENCE_QUERIES,
        MAX_ROAMING_SEQUENCE_QUERIES,
    )?;
    Ok(RoamingExportConfig {
        start_time,
        end_time,
        start_date,
        end_date,
        requested_days,
        max_messages,
        max_sequence_queries,
    })
}

/// 导出请求的公共参数。
struct ExportRequest {
    chat_type: i64,
    peer_uid: String,
    peer_identity: String,
    peer_uin: Option<String>,
    filter: Value,
    options: Value,
    session_name: String,
    custom_output_dir: String,
    output_dir: PathBuf,
    use_name_in_file_name: bool,
    use_friendly_file_name: bool,
    date_str: String,
    time_str: String,
}

async fn prepare_output_directory(
    requested_output_dir: &FsPath,
    output_roots: &[PathBuf],
) -> Result<PathBuf, ApiError> {
    let allowed_roots = output_roots
        .iter()
        .map(|root| root.display().to_string())
        .collect::<Vec<_>>()
        .join(", ");
    let output_dir =
        crate::api::path_security::resolve_for_creation_within(requested_output_dir, output_roots)
            .ok_or_else(|| {
                ApiError::validation(
                    format!(
                        "导出目录不在允许范围内: {}; 允许的根目录: {allowed_roots}",
                        requested_output_dir.display()
                    ),
                    "INVALID_PATH",
                )
            })?;
    tokio::fs::create_dir_all(&output_dir)
        .await
        .map_err(|error| {
            ApiError::new(
                ErrorType::FileSystem,
                format!("无法创建导出目录 {}: {error}", output_dir.display()),
                "CREATE_EXPORT_DIR_FAILED",
            )
        })?;
    crate::api::path_security::resolve_existing_within(&output_dir, output_roots).ok_or_else(|| {
        ApiError::validation(
            format!(
                "创建后的导出目录不在允许范围内: {}; 允许的根目录: {allowed_roots}",
                output_dir.display()
            ),
            "INVALID_PATH",
        )
    })
}

/// 解析导出请求公共部分（peer 校验 / uid 解析 / 会话名 / 输出目录）。
async fn prepare_export_request(
    state: &SharedState,
    body: &Value,
) -> Result<ExportRequest, ApiError> {
    let Some((chat_type, raw_peer_uid)) = parse_peer(body) else {
        return Err(ApiError::validation("peer参数不完整", "INVALID_PEER"));
    };
    // Issue #226 / #353：支持通过 QQ 号导出，自动转换为 uid。
    let peer_uid = resolve_peer_uid(chat_type, &raw_peer_uid, &state.napcat).await;
    let request_peer_uin = body
        .pointer("/peer/peerUin")
        .and_then(Value::as_str)
        .map(str::trim)
        .filter(|value| !value.is_empty() && value.chars().all(|ch| ch.is_ascii_digit()))
        .map(str::to_string);
    let peer_uin = if chat_type == GROUP_CHAT_TYPE {
        None
    } else {
        request_peer_uin.or_else(|| {
            raw_peer_uid
                .chars()
                .all(|ch| ch.is_ascii_digit())
                .then(|| raw_peer_uid.clone())
        })
    };
    let peer_identity = if chat_type == GROUP_CHAT_TYPE {
        raw_peer_uid.clone()
    } else {
        peer_uin.clone().unwrap_or_else(|| peer_uid.clone())
    };
    let filter = body.get("filter").cloned().unwrap_or(Value::Null);
    let options = body.get("options").cloned().unwrap_or(Value::Null);

    // Issue #192：自定义导出路径。
    let custom_output_dir = PathManager::sanitize_path(
        options
            .get("outputDir")
            .and_then(Value::as_str)
            .unwrap_or(""),
    );
    let requested_output_dir = if custom_output_dir.trim().is_empty() {
        state.path_manager.exports_dir()
    } else {
        PathBuf::from(&custom_output_dir)
    };
    let output_roots = state.path_manager.export_output_roots(
        (!custom_output_dir.trim().is_empty()).then_some(custom_output_dir.as_str()),
    );
    let output_dir = prepare_output_directory(&requested_output_dir, &output_roots).await?;

    // 会话名：优先用户输入（issue #365）。
    let user_session_name = body
        .get("sessionName")
        .and_then(Value::as_str)
        .map(str::trim)
        .filter(|s| !s.is_empty());
    let session_name = match user_session_name {
        Some(name) => name.to_string(),
        None => resolve_session_name(chat_type, &peer_uid, &state.napcat).await,
    };

    let (date_str, time_str) = local_date_time_strings();
    Ok(ExportRequest {
        chat_type,
        peer_uid,
        peer_identity,
        peer_uin,
        use_name_in_file_name: options.get("useNameInFileName").and_then(Value::as_bool)
            == Some(true),
        use_friendly_file_name: options.get("useFriendlyFileName").and_then(Value::as_bool)
            == Some(true),
        filter,
        options,
        session_name,
        custom_output_dir,
        output_dir,
        date_str,
        time_str,
    })
}

/// 创建任务记录、入表并持久化。
async fn register_task(state: &SharedState, task: &Value) -> bool {
    let task_id = task
        .get("taskId")
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string();
    let mut tasks = state.export_tasks.lock().await;
    let active_count = tasks
        .values()
        .filter(|value| {
            matches!(
                value.get("status").and_then(Value::as_str),
                Some("queued" | "pending" | "running")
            )
        })
        .count();
    if active_count >= MAX_QUEUED_TASKS {
        return false;
    }
    tasks.insert(task_id, task.clone());
    if let Err(error) = state.db.save_task(task, task, true).await {
        tracing::warn!("[ApiServer] 保存新任务到数据库失败: {error}");
    }
    true
}

/// `POST /api/messages/export` — 创建异步导出任务。
pub async fn export_messages(
    State(state): State<SharedState>,
    Extension(RequestId(request_id)): Extension<RequestId>,
    Json(body): Json<Value>,
) -> Response {
    if let Some(err) = standalone_guard_with(&state, "导出新聊天记录") {
        return response::error(&err, &request_id);
    }
    let req = match prepare_export_request(&state, &body).await {
        Ok(req) => req,
        Err(err) => return response::error(&err, &request_id),
    };
    let format = body
        .get("format")
        .and_then(Value::as_str)
        .unwrap_or("JSON")
        .to_uppercase();
    let file_ext = match format.as_str() {
        "TXT" => "txt",
        "HTML" => "html",
        "EXCEL" => "xlsx",
        _ => "json",
    };

    let task_id = generate_task_id("export");
    let prefix = chat_type_prefix(Some(req.chat_type));
    let base_file_name = build_export_file_name(
        prefix,
        &req.peer_identity,
        &req.session_name,
        &req.date_str,
        &req.time_str,
        file_ext,
        req.use_name_in_file_name,
        req.use_friendly_file_name,
    );
    let file_name = reserve_export_file_name(&req.output_dir, &base_file_name);
    let file_path = req.output_dir.join(&file_name);
    let download_url = generate_download_url(
        &file_path,
        &file_name,
        &req.custom_output_dir,
        "/downloads/",
    );

    let task = json!({
        "taskId": task_id,
        "peer": { "chatType": req.chat_type, "peerUid": req.peer_uid },
        "sessionName": req.session_name,
        "fileName": file_name,
        "downloadUrl": download_url,
        "messageCount": 0,
        "status": "queued",             // 初始状态设为 queued
        "message": "正在排队中...",      // 初始消息设为 正在排队中...
        "progress": 0,
        "createdAt": now_iso(),
        "format": format,
        "filter": req.filter,
        "options": req.options,
    });
    if !register_task(&state, &task).await {
        let err = ApiError::new(
            ErrorType::Api,
            "排队中的导出任务已达到上限",
            "EXPORT_TASK_LIMIT_REACHED",
        )
        .with_status(axum::http::StatusCode::TOO_MANY_REQUESTS);
        return response::error(&err, &request_id);
    }

    let reply = json!({
        "taskId": task_id,
        "sessionName": req.session_name,
        "fileName": file_name,
        "downloadUrl": download_url,
        "filePath": file_path.to_string_lossy(),
        "messageCount": 0,
        "status": "queued",
        "startTime": req.filter.get("startTime").cloned().unwrap_or(Value::Null),
        "endTime": req.filter.get("endTime").cloned().unwrap_or(Value::Null),
    });

    let state_bg = Arc::clone(&state);
    tokio::spawn(async move {
        run_export_task(
            state_bg,
            task_id,
            req,
            format,
            file_name,
            ExportMode::Standard,
            ExportInput::Standard,
        )
        .await;
    });

    response::success(reply, &request_id)
}

/// `POST /api/messages/export-streaming-zip` — 流式 ZIP 导出（防 OOM）。
pub async fn export_streaming_zip(
    State(state): State<SharedState>,
    Extension(RequestId(request_id)): Extension<RequestId>,
    Json(body): Json<Value>,
) -> Response {
    if let Some(err) = standalone_guard_with(&state, "导出新聊天记录") {
        return response::error(&err, &request_id);
    }
    let req = match prepare_export_request(&state, &body).await {
        Ok(req) => req,
        Err(err) => return response::error(&err, &request_id),
    };

    let task_id = generate_task_id("streaming_zip");
    let prefix = chat_type_prefix(Some(req.chat_type));
    let file_name = build_export_file_name(
        prefix,
        &req.peer_identity,
        &req.session_name,
        &req.date_str,
        &req.time_str,
        "zip",
        req.use_name_in_file_name,
        req.use_friendly_file_name,
    );
    let base_file_name = if let Some(stripped) = file_name.strip_suffix(".zip") {
        format!("{stripped}_streaming.zip")
    } else {
        file_name
    };
    let file_name = reserve_export_file_name(&req.output_dir, &base_file_name);
    let file_path = req.output_dir.join(&file_name);
    let download_url = generate_download_url(
        &file_path,
        &file_name,
        &req.custom_output_dir,
        "/downloads/",
    );

    let mut options = req.options.clone();
    if let Some(obj) = options.as_object_mut() {
        obj.insert("streamingMode".to_string(), Value::Bool(true));
    }
    let task = json!({
        "taskId": task_id,
        "peer": { "chatType": req.chat_type, "peerUid": req.peer_uid },
        "sessionName": req.session_name,
        "fileName": file_name,
        "downloadUrl": download_url,
        "messageCount": 0,
        "status": "queued",             // 初始状态设为 queued
        "message": "正在排队中...",      // 初始消息设为 正在排队中...
        "progress": 0,
        "createdAt": now_iso(),
        "format": "STREAMING_ZIP",
        "filter": req.filter,
        "options": options,
    });
    if !register_task(&state, &task).await {
        let err = ApiError::new(
            ErrorType::Api,
            "排队中的导出任务已达到上限",
            "EXPORT_TASK_LIMIT_REACHED",
        )
        .with_status(axum::http::StatusCode::TOO_MANY_REQUESTS);
        return response::error(&err, &request_id);
    }

    let reply = json!({
        "taskId": task_id,
        "sessionName": req.session_name,
        "fileName": file_name,
        "downloadUrl": download_url,
        "filePath": file_path.to_string_lossy(),
        "messageCount": 0,
        "status": "queued",
        "startTime": req.filter.get("startTime").cloned().unwrap_or(Value::Null),
        "endTime": req.filter.get("endTime").cloned().unwrap_or(Value::Null),
        "streamingMode": true,
    });

    let state_bg = Arc::clone(&state);
    tokio::spawn(async move {
        run_export_task(
            state_bg,
            task_id,
            req,
            "STREAMING_ZIP".to_string(),
            file_name,
            ExportMode::StreamingZip,
            ExportInput::Standard,
        )
        .await;
    });

    response::success(reply, &request_id)
}

/// `POST /api/messages/export-streaming-jsonl` — 流式 JSONL 导出（防 OOM）。
pub async fn export_streaming_jsonl(
    State(state): State<SharedState>,
    Extension(RequestId(request_id)): Extension<RequestId>,
    Json(body): Json<Value>,
) -> Response {
    if let Some(err) = standalone_guard_with(&state, "导出新聊天记录") {
        return response::error(&err, &request_id);
    }
    let req = match prepare_export_request(&state, &body).await {
        Ok(req) => req,
        Err(err) => return response::error(&err, &request_id),
    };

    let task_id = generate_task_id("streaming_jsonl");
    let prefix = chat_type_prefix(Some(req.chat_type));
    let dir_name = build_export_dir_name(
        prefix,
        &req.peer_identity,
        &req.session_name,
        &req.date_str,
        &req.time_str,
        "_chunked_jsonl",
        req.use_name_in_file_name,
        req.use_friendly_file_name,
    );
    let dir_name = reserve_export_file_name(&req.output_dir, &dir_name);
    let dir_path = req.output_dir.join(&dir_name);
    // JSONL 导出是目录，不支持直接下载。
    let download_url = if req.custom_output_dir.trim().is_empty() {
        format!("/downloads/{dir_name}")
    } else {
        dir_path.to_string_lossy().to_string()
    };

    let mut options = req.options.clone();
    if let Some(obj) = options.as_object_mut() {
        obj.insert("streamingMode".to_string(), Value::Bool(true));
    }
    let task = json!({
        "taskId": task_id,
        "peer": { "chatType": req.chat_type, "peerUid": req.peer_uid },
        "sessionName": req.session_name,
        "fileName": dir_name,
        "downloadUrl": download_url,
        "messageCount": 0,
        "status": "queued",             // 初始状态设为 queued
        "message": "正在排队中...",      // 初始消息设为 正在排队中...
        "progress": 0,
        "createdAt": now_iso(),
        "format": "STREAMING_JSONL",
        "filter": req.filter,
        "options": options,
    });
    if !register_task(&state, &task).await {
        let err = ApiError::new(
            ErrorType::Api,
            "排队中的导出任务已达到上限",
            "EXPORT_TASK_LIMIT_REACHED",
        )
        .with_status(axum::http::StatusCode::TOO_MANY_REQUESTS);
        return response::error(&err, &request_id);
    }

    let reply = json!({
        "taskId": task_id,
        "sessionName": req.session_name,
        "fileName": dir_name,
        "downloadUrl": download_url,
        "filePath": dir_path.to_string_lossy(),
        "messageCount": 0,
        "status": "queued",
        "startTime": req.filter.get("startTime").cloned().unwrap_or(Value::Null),
        "endTime": req.filter.get("endTime").cloned().unwrap_or(Value::Null),
        "streamingMode": true,
    });

    let state_bg = Arc::clone(&state);
    tokio::spawn(async move {
        run_export_task(
            state_bg,
            task_id,
            req,
            "STREAMING_JSONL".to_string(),
            dir_name,
            ExportMode::StreamingJsonl,
            ExportInput::Standard,
        )
        .await;
    });

    response::success(reply, &request_id)
}

/// `POST /api/messages/roaming/export` — 创建有界私聊漫游扫描与正式导出任务。
pub async fn export_roaming_messages(
    State(state): State<SharedState>,
    Extension(RequestId(request_id)): Extension<RequestId>,
    Json(body): Json<Value>,
) -> Response {
    if let Some(err) = standalone_guard_with(&state, "扫描并导出漫游聊天记录") {
        return response::error(&err, &request_id);
    }
    let scan_config = match parse_roaming_export_config(&body) {
        Ok(config) => config,
        Err(error) => return response::error(&error, &request_id),
    };
    let mut req = match prepare_export_request(&state, &body).await {
        Ok(req) => req,
        Err(error) => return response::error(&error, &request_id),
    };
    let format = body
        .get("format")
        .and_then(Value::as_str)
        .unwrap_or("JSON")
        .to_uppercase();
    let mode = match format.as_str() {
        "TXT" | "JSON" | "HTML" | "EXCEL" => ExportMode::Standard,
        "STREAMING_ZIP" => ExportMode::StreamingZip,
        "STREAMING_JSONL" => ExportMode::StreamingJsonl,
        _ => {
            let error = ApiError::validation(
                "format 必须是 TXT、JSON、HTML、EXCEL、STREAMING_ZIP 或 STREAMING_JSONL",
                "INVALID_EXPORT_FORMAT",
            );
            return response::error(&error, &request_id);
        }
    };
    if mode != ExportMode::Standard {
        if !req.options.is_object() {
            req.options = json!({});
        }
        if let Some(options) = req.options.as_object_mut() {
            options.insert("streamingMode".to_string(), Value::Bool(true));
        }
    }

    let prefix = chat_type_prefix(Some(req.chat_type));
    let (base_file_name, is_directory) = match mode {
        ExportMode::Standard => {
            let extension = match format.as_str() {
                "TXT" => "txt",
                "HTML" => "html",
                "EXCEL" => "xlsx",
                _ => "json",
            };
            (
                build_export_file_name(
                    prefix,
                    &req.peer_identity,
                    &req.session_name,
                    &req.date_str,
                    &req.time_str,
                    extension,
                    req.use_name_in_file_name,
                    req.use_friendly_file_name,
                ),
                false,
            )
        }
        ExportMode::StreamingZip => {
            let regular = build_export_file_name(
                prefix,
                &req.peer_identity,
                &req.session_name,
                &req.date_str,
                &req.time_str,
                "zip",
                req.use_name_in_file_name,
                req.use_friendly_file_name,
            );
            (
                regular
                    .strip_suffix(".zip")
                    .map_or(regular.clone(), |stem| format!("{stem}_streaming.zip")),
                false,
            )
        }
        ExportMode::StreamingJsonl => (
            build_export_dir_name(
                prefix,
                &req.peer_identity,
                &req.session_name,
                &req.date_str,
                &req.time_str,
                "_chunked_jsonl",
                req.use_name_in_file_name,
                req.use_friendly_file_name,
            ),
            true,
        ),
    };
    let file_name = reserve_export_file_name(&req.output_dir, &base_file_name);
    let file_path = req.output_dir.join(&file_name);
    let download_url = if is_directory {
        if req.custom_output_dir.trim().is_empty() {
            format!("/downloads/{file_name}")
        } else {
            file_path.to_string_lossy().to_string()
        }
    } else {
        generate_download_url(
            &file_path,
            &file_name,
            &req.custom_output_dir,
            "/downloads/",
        )
    };
    let task_id = generate_task_id("roaming_export");
    let initial_scan = RoamingScanSummary::new(&scan_config).as_value();
    let task = json!({
        "taskId": task_id,
        "taskKind": "roaming_export",
        "peer": { "chatType": req.chat_type, "peerUid": req.peer_uid },
        "sessionName": req.session_name,
        "fileName": file_name,
        "downloadUrl": download_url,
        "messageCount": 0,
        "processedMessages": 0,
        "status": "queued",
        "progress": 0,
        "message": "正在排队中...",
        "createdAt": now_iso(),
        "format": format,
        "filter": req.filter,
        "options": req.options,
        "roamingScan": initial_scan,
    });
    if !register_task(&state, &task).await {
        release_export_path(&file_path);
        let error = ApiError::new(
            ErrorType::Api,
            "排队中的导出任务已达到上限",
            "EXPORT_TASK_LIMIT_REACHED",
        )
        .with_status(axum::http::StatusCode::TOO_MANY_REQUESTS);
        return response::error(&error, &request_id);
    }

    let reply = json!({
        "taskId": task_id,
        "taskKind": "roaming_export",
        "sessionName": req.session_name,
        "fileName": file_name,
        "downloadUrl": download_url,
        "filePath": file_path.to_string_lossy(),
        "messageCount": 0,
        "status": "queued",
        "startTime": scan_config.start_time,
        "endTime": scan_config.end_time,
        "roamingScan": initial_scan,
    });

    let state_bg = Arc::clone(&state);
    tokio::spawn(async move {
        run_export_task(
            state_bg,
            task_id,
            req,
            format,
            file_name,
            mode,
            ExportInput::Roaming {
                config: scan_config,
            },
        )
        .await;
    });

    response::success(reply, &request_id)
}

/// 导出模式。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ExportMode {
    /// 普通导出（TXT / JSON / HTML / EXCEL）。
    Standard,
    /// 流式 ZIP（chunked HTML + ZIP）。
    StreamingZip,
    /// 流式 JSONL（manifest + chunks/*.jsonl）。
    StreamingJsonl,
}

enum ExportInput {
    Standard,
    Roaming { config: RoamingExportConfig },
}

/// 注册 worker 的取消信号，并与取消端以同一锁顺序封闭“先取消、后注册”竞态。
async fn register_export_cancel_flag(state: &SharedState, task_id: &str) -> Arc<AtomicBool> {
    let cancelled = state.cancelled_task_ids.lock().await;
    let cancel_flag = Arc::new(AtomicBool::new(cancelled.contains(task_id)));
    let mut flags = state.running_export_cancel_flags.lock().await;
    flags.insert(task_id.to_string(), Arc::clone(&cancel_flag));
    cancel_flag
}

/// 漫游导出在取得通用导出名额后，再以可取消方式等待历史查询门控。
async fn wait_for_export_input_history_permit(
    state: &SharedState,
    task_id: &str,
    cancel_flag: &AtomicBool,
    input: &ExportInput,
) -> Result<Option<tokio::sync::SemaphorePermit<'static>>, String> {
    if matches!(input, ExportInput::Standard) {
        return Ok(None);
    }

    let waiting_message = "已取得导出名额，正在等待历史查询...";
    let _ = update_and_broadcast_progress(
        state,
        task_id,
        json!({
            "status": "pending",
            "progress": 0,
            "message": waiting_message,
        }),
        0,
        waiting_message,
        0,
    )
    .await;
    tokio::select! {
        result = acquire_history_query_permit() => {
            result
                .map(Some)
                .map_err(|_| "历史查询门控已关闭".to_string())
        }
        () = wait_for_atomic_cancellation(cancel_flag) => {
            Err("任务已被用户停止".to_string())
        }
    }
}

/// 后台导出主流程包装：负责获取排队许可 / 取消 / 失败态与清理。
async fn run_export_task(
    state: SharedState,
    task_id: String,
    req: ExportRequest,
    format: String,
    file_name: String,
    mode: ExportMode,
    input: ExportInput,
) {
    // issue #446：注册取消 flag，使「停止任务」接口能打断本任务。
    let cancel_flag = register_export_cancel_flag(&state, &task_id).await;
    let cancelled_before_registration = cancel_flag.load(Ordering::SeqCst);

    // 收敛所有执行分支的结果：末尾统一释放路径、下发终态、清理跟踪状态。
    // 排队前 / 排队中 / 执行中的「取消」统一交给末尾的 is_cancelled 判定。
    let result: Result<(), String> = if cancelled_before_registration {
        Err("任务已被用户停止".to_string())
    } else {
        let _ = update_and_broadcast_progress(
            &state,
            &task_id,
            json!({
                "status": "queued",
                "progress": 0,
                "message": "正在排队中..."
            }),
            0,
            "正在排队中...",
            0,
        )
        .await;

        // 排队：异步获取并发名额，permit 生命周期覆盖整个导出过程。
        // 取消信号同时打断等待，避免已取消任务继续占用漫游独占许可。
        let permit = tokio::select! {
            result = state.export_semaphore.acquire() => {
                result.map_err(|_| "导出服务已关闭".to_string())
            }
            () = wait_for_atomic_cancellation(&cancel_flag) => {
                Err("任务已被用户停止".to_string())
            }
        };
        match permit {
            Ok(_permit) if !is_cancelled(&state, &task_id, &cancel_flag).await => {
                process_export_task(
                    &state,
                    &task_id,
                    &req,
                    &format,
                    &file_name,
                    mode,
                    &cancel_flag,
                    input,
                )
                .await
            }
            Ok(_) => Err("任务已被用户停止".to_string()),
            Err(error) => Err(error),
        }
    };
    release_export_path(&req.output_dir.join(&file_name));

    if let Err(error) = result {
        if is_cancelled(&state, &task_id, &cancel_flag).await {
            tracing::info!("[ApiServer] 导出任务已被用户停止: {task_id}");
            let fallback_scan = {
                let tasks = state.export_tasks.lock().await;
                tasks
                    .get(&task_id)
                    .and_then(|task| fallback_terminal_roaming_scan(task, "cancelled"))
            };
            let mut patch = json!({
                "status": "cancelled",
                "message": "任务已停止",
                "completedAt": now_iso(),
            });
            if let Some(scan) = fallback_scan {
                patch["roamingScan"] = scan;
            }
            if let Some(updated_task) = update_task(&state, &task_id, patch).await {
                state.broadcast_ws(&export_ws_event(
                    "export_progress",
                    json!({ "taskId": task_id, "status": "cancelled", "message": "任务已停止" }),
                    task_roaming_scan(&updated_task),
                ));
            }
        } else {
            tracing::error!("[ApiServer] 导出任务失败: {task_id} — {error}");
            let (error_code, error_http_status, fallback_scan) = {
                let tasks = state.export_tasks.lock().await;
                let task = tasks.get(&task_id);
                (
                    task.and_then(|value| value.get("errorCode"))
                        .and_then(Value::as_str)
                        .unwrap_or("EXPORT_FAILED")
                        .to_string(),
                    task.and_then(|value| value.get("errorHttpStatus"))
                        .and_then(Value::as_u64)
                        .unwrap_or(500),
                    task.and_then(|task| fallback_terminal_roaming_scan(task, "scan_failed")),
                )
            };
            let mut patch = json!({
                "status": "failed",
                "error": error,
                "errorCode": error_code,
                "errorHttpStatus": error_http_status,
                "completedAt": now_iso(),
            });
            if let Some(scan) = fallback_scan {
                patch["roamingScan"] = scan;
            }
            if let Some(updated_task) = update_task(&state, &task_id, patch).await {
                state.broadcast_ws(&export_ws_event(
                    "export_error",
                    json!({
                        "taskId": task_id,
                        "status": "failed",
                        "error": error,
                        "errorCode": error_code,
                        "errorHttpStatus": error_http_status,
                    }),
                    task_roaming_scan(&updated_task),
                ));
            }
        }
    }

    // issue #446：清理停止任务的跟踪状态。
    {
        let mut flags = state.running_export_cancel_flags.lock().await;
        flags.remove(&task_id);
    }
    {
        let mut cancelled = state.cancelled_task_ids.lock().await;
        cancelled.remove(&task_id);
    }
}

/// 检查任务是否已被用户停止。
async fn is_cancelled(state: &SharedState, task_id: &str, cancel_flag: &AtomicBool) -> bool {
    if cancel_flag.load(Ordering::SeqCst) {
        return true;
    }
    let cancelled = state.cancelled_task_ids.lock().await;
    cancelled.contains(task_id)
}

async fn wait_for_atomic_cancellation(cancel_flag: &AtomicBool) {
    while !cancel_flag.load(Ordering::SeqCst) {
        tokio::time::sleep(std::time::Duration::from_millis(50)).await;
    }
}

/// issue #331：拉取群成员「群头衔」，构造 (uid|uin) → title 映射。
async fn fetch_group_member_title_map(
    state: &SharedState,
    peer_uid: &str,
    chat_type: i64,
) -> Option<HashMap<String, String>> {
    if chat_type != GROUP_CHAT_TYPE {
        return None;
    }
    let mut title_map: HashMap<String, String> = HashMap::new();
    if let Ok(group_members) = state.napcat.get_group_member_all(peer_uid, false).await {
        if let Some(infos) = group_members
            .pointer("/result/infos")
            .or_else(|| group_members.get("infos"))
            .and_then(Value::as_object)
        {
            for (uid, member) in infos {
                let title = ["memberSpecialTitle", "specialTitle", "title"]
                    .iter()
                    .find_map(|key| member.get(*key).and_then(Value::as_str))
                    .map(str::trim)
                    .filter(|t| !t.is_empty());
                let Some(title) = title else { continue };
                if !uid.is_empty() {
                    title_map.insert(uid.clone(), title.to_string());
                }
                if let Some(uin) = member.get("uin").and_then(Value::as_str) {
                    if !uin.is_empty() {
                        title_map.insert(uin.to_string(), title.to_string());
                    }
                }
            }
        }
    }
    // 回退：WebApi.getGroupMembers 的 .title 字段比较稳。
    if title_map.is_empty() {
        if let Ok(web_members) = state
            .napcat
            .call("WebApi.getGroupMembers", json!([peer_uid]))
            .await
        {
            if let Some(list) = web_members.as_array() {
                for member in list {
                    let title = member
                        .get("title")
                        .and_then(Value::as_str)
                        .map(str::trim)
                        .filter(|t| !t.is_empty());
                    let Some(title) = title else { continue };
                    let uin = match member.get("uin") {
                        Some(Value::String(s)) => s.clone(),
                        Some(Value::Number(n)) => n.to_string(),
                        _ => continue,
                    };
                    if !uin.is_empty() {
                        title_map.insert(uin, title.to_string());
                    }
                }
            }
        }
    }
    if title_map.is_empty() {
        None
    } else {
        Some(title_map)
    }
}

/// 拉取群成员 infos（用于群昵称补全，只拉一次，逐块复用）。
async fn fetch_group_member_infos(state: &SharedState, peer_uid: &str) -> Option<Value> {
    let group_members = state
        .napcat
        .get_group_member_all(peer_uid, false)
        .await
        .ok()?;
    group_members
        .pointer("/result/infos")
        .or_else(|| group_members.get("infos"))
        .filter(|infos| infos.is_object())
        .cloned()
}

/// 补全群消息的群昵称（sendMemberName）。
fn apply_group_member_names(member_infos: &Value, messages: &mut [Value]) {
    let Some(infos) = member_infos.as_object() else {
        return;
    };
    for message in messages.iter_mut() {
        let needs_fill = message
            .get("sendMemberName")
            .and_then(Value::as_str)
            .is_none_or(|s| s.trim().is_empty());
        if !needs_fill {
            continue;
        }
        let Some(sender_uid) = message.get("senderUid").and_then(Value::as_str) else {
            continue;
        };
        if let Some(card_name) = infos
            .get(sender_uid)
            .and_then(|m| m.get("cardName"))
            .and_then(Value::as_str)
            .filter(|s| !s.is_empty())
        {
            if let Some(obj) = message.as_object_mut() {
                obj.insert(
                    "sendMemberName".to_string(),
                    Value::String(card_name.to_string()),
                );
            }
        }
    }
}

/// 把本块已下载资源登记到导出器的紧凑索引（按文件名去重，不按消息保存）。
fn register_downloaded_resources(
    index: &mut DownloadedResourceIndex,
    resource_map: &HashMap<String, Vec<ResourceInfo>>,
) {
    for resource in resource_map.values().flatten() {
        if let Some(local_path) = resource.local_path.as_deref() {
            index.insert(&resource.resource_type, local_path);
        }
    }
}

/// 把资源映射序列化成 `update_single_message_resource_paths` 需要的 Value 列表。
fn to_value_resource_map(
    resource_map: &HashMap<String, Vec<ResourceInfo>>,
) -> HashMap<String, Vec<Value>> {
    resource_map
        .iter()
        .map(|(msg_id, resources)| {
            let values = resources
                .iter()
                .filter_map(|r| serde_json::to_value(r).ok())
                .collect();
            (msg_id.clone(), values)
        })
        .collect()
}

/// ZIP 打包（阻塞线程执行）：HTML 文件 + resources 相对路径列表。
/// issue #634：逐文件流式复制，不把单个文件整体读入内存。
async fn create_zip_with_resources(
    base_dir: PathBuf,
    main_file: PathBuf,
    resource_rel_paths: Vec<String>,
    zip_path: PathBuf,
) -> Result<(), String> {
    tokio::task::spawn_blocking(move || -> Result<(), String> {
        let file = std::fs::File::create(&zip_path).map_err(|e| e.to_string())?;
        let mut zip = zip::ZipWriter::new(file);
        let options = zip::write::SimpleFileOptions::default()
            .compression_method(zip::CompressionMethod::Deflated);
        let main_name = main_file
            .file_name()
            .map(|n| n.to_string_lossy().to_string())
            .ok_or_else(|| "无效的主文件名".to_string())?;
        zip.start_file(&main_name, options)
            .map_err(|e| e.to_string())?;
        let mut main = std::fs::File::open(&main_file).map_err(|e| e.to_string())?;
        std::io::copy(&mut main, &mut zip).map_err(|e| e.to_string())?;
        for rel in resource_rel_paths {
            let src = base_dir.join(&rel);
            let Ok(mut src) = std::fs::File::open(&src) else {
                continue;
            };
            let entry_name = rel.replace('\\', "/");
            if zip.start_file(&entry_name, options).is_err() {
                continue;
            }
            let _ = std::io::copy(&mut src, &mut zip);
        }
        zip.finish().map_err(|e| e.to_string())?;
        Ok(())
    })
    .await
    .map_err(|e| e.to_string())?
}

/// ZIP 打包整个目录（阻塞线程执行）。
/// issue #634：逐文件流式复制，不把单个文件整体读入内存。
async fn create_zip_from_dir(dir: PathBuf, zip_path: PathBuf) -> Result<(), String> {
    tokio::task::spawn_blocking(move || -> Result<(), String> {
        let file = std::fs::File::create(&zip_path).map_err(|e| e.to_string())?;
        let mut zip = zip::ZipWriter::new(file);
        let options = zip::write::SimpleFileOptions::default()
            .compression_method(zip::CompressionMethod::Deflated);
        for entry in walkdir::WalkDir::new(&dir)
            .into_iter()
            .filter_map(Result::ok)
        {
            if !entry.file_type().is_file() {
                continue;
            }
            let rel = entry.path().strip_prefix(&dir).map_err(|e| e.to_string())?;
            zip.start_file(rel.to_string_lossy().replace('\\', "/"), options)
                .map_err(|e| e.to_string())?;
            let mut src = std::fs::File::open(entry.path()).map_err(|e| e.to_string())?;
            std::io::copy(&mut src, &mut zip).map_err(|e| e.to_string())?;
        }
        zip.finish().map_err(|e| e.to_string())?;
        Ok(())
    })
    .await
    .map_err(|e| e.to_string())?
}

/// issue #634：分块流水线的块大小（原始消息条数）。
const RAW_SPOOL_CHUNK_SIZE: usize = 20_000;

/// issue #634：抓取阶段的磁盘 spool。原始消息逐批落盘为 JSONL，避免在内存
/// 中累积超大群聊的全部原始消息；任何退出路径（Drop）都会清理文件。
struct RawMessageSpool {
    path: PathBuf,
    writer: Option<tokio::io::BufWriter<tokio::fs::File>>,
    count: usize,
}

impl RawMessageSpool {
    async fn create(path: PathBuf) -> Result<Self, String> {
        let file = tokio::fs::File::create(&path)
            .await
            .map_err(|e| format!("创建消息暂存文件失败: {e}"))?;
        Ok(Self {
            path,
            writer: Some(tokio::io::BufWriter::new(file)),
            count: 0,
        })
    }

    async fn append(&mut self, messages: &[Value]) -> Result<(), String> {
        use tokio::io::AsyncWriteExt as _;
        let writer = self
            .writer
            .as_mut()
            .ok_or_else(|| "消息暂存文件已关闭".to_string())?;
        for message in messages {
            let line = serde_json::to_vec(message).map_err(|e| e.to_string())?;
            writer
                .write_all(&line)
                .await
                .map_err(|e| format!("写入消息暂存文件失败: {e}"))?;
            writer
                .write_all(b"\n")
                .await
                .map_err(|e| format!("写入消息暂存文件失败: {e}"))?;
            self.count += 1;
        }
        Ok(())
    }

    async fn finish(&mut self) -> Result<(), String> {
        use tokio::io::AsyncWriteExt as _;
        if let Some(mut writer) = self.writer.take() {
            writer
                .flush()
                .await
                .map_err(|e| format!("写入消息暂存文件失败: {e}"))?;
        }
        Ok(())
    }

    fn path(&self) -> &FsPath {
        &self.path
    }

    fn count(&self) -> usize {
        self.count
    }
}

impl Drop for RawMessageSpool {
    fn drop(&mut self) {
        self.writer.take();
        let _ = std::fs::remove_file(&self.path);
    }
}

/// 按块读取 spool JSONL。
struct SpoolChunkReader {
    lines: tokio::io::Lines<tokio::io::BufReader<tokio::fs::File>>,
    chunk_size: usize,
}

impl SpoolChunkReader {
    async fn open(path: &FsPath, chunk_size: usize) -> Result<Self, String> {
        use tokio::io::AsyncBufReadExt as _;
        let file = tokio::fs::File::open(path)
            .await
            .map_err(|e| format!("打开消息暂存文件失败: {e}"))?;
        Ok(Self {
            lines: tokio::io::BufReader::new(file).lines(),
            chunk_size: chunk_size.max(1),
        })
    }

    async fn next_chunk(&mut self) -> Result<Option<Vec<Value>>, String> {
        let mut chunk = Vec::new();
        while chunk.len() < self.chunk_size {
            match self
                .lines
                .next_line()
                .await
                .map_err(|e| format!("读取消息暂存文件失败: {e}"))?
            {
                Some(line) if !line.trim().is_empty() => {
                    chunk.push(serde_json::from_str(&line).map_err(|e| e.to_string())?);
                }
                Some(_) => {}
                None => break,
            }
        }
        Ok(if chunk.is_empty() { None } else { Some(chunk) })
    }
}

/// issue #634：基于序列号的真实抓取进度（1–49），取代硬编码的 50% 假进度。
fn estimate_fetch_progress(max_seq: Option<i64>, min_seq: Option<i64>, batch_count: i64) -> i64 {
    if let (Some(max), Some(min)) = (max_seq, min_seq) {
        if max > 0 && max >= min {
            let done = (max - min) as f64 / max as f64;
            return (1.0 + done * 48.0).round() as i64;
        }
    }
    // 无序列号信息时按批次数渐近逼近 49。
    let asymptotic = (1.0 - 1.0 / (1.0 + batch_count.max(0) as f64 / 20.0)) * 49.0;
    (asymptotic.round() as i64).clamp(1, 49)
}

/// 导出主流程。
#[allow(clippy::too_many_arguments, clippy::too_many_lines)]
async fn process_export_task(
    state: &SharedState,
    task_id: &str,
    req: &ExportRequest,
    format: &str,
    file_name: &str,
    mode: ExportMode,
    cancel_flag: &Arc<AtomicBool>,
    input: ExportInput,
) -> Result<(), String> {
    if is_cancelled(state, task_id, cancel_flag).await {
        return Err("任务已被用户停止".to_string());
    }

    // 排队任务不能提前占住历史查询门控：普通导出可能已持有全部 export
    // permits，并在单次分页时等待同一个门控，反向持锁会形成死锁。worker 只有
    // 在取得 export permit 后才进入这里，再以可取消方式等待历史查询许可。
    let mut history_permit =
        wait_for_export_input_history_permit(state, task_id, cancel_flag, &input).await?;
    if is_cancelled(state, task_id, cancel_flag).await {
        return Err("任务已被用户停止".to_string());
    }

    let roaming_scan = match &input {
        ExportInput::Roaming { config, .. } => Some(RoamingScanSummary::new(config).as_value()),
        ExportInput::Standard => None,
    };
    let starting_message = if roaming_scan.is_some() {
        "开始有界漫游扫描..."
    } else {
        "开始获取消息..."
    };
    let _ = update_and_broadcast_progress(
        state,
        task_id,
        json!({ "status": "running", "progress": 0, "message": starting_message }),
        0,
        starting_message,
        0,
    )
    .await;
    let debug_session = if req.options.get("debugExport").and_then(Value::as_bool) == Some(true) {
        let session = ExportDebugSession::start(&req.output_dir, file_name).await?;
        session
            .trace()
            .record(json!({
                "type": "export_started",
                "taskId": task_id,
                "format": format,
                "mode": format!("{mode:?}"),
            }))
            .await;
        Some(session)
    } else {
        None
    };

    // 阶段 1：普通导出由 BatchMessageFetcher 抓取；漫游导出由有界锚点扫描与
    // 序列桥接抓取。两者都写入同一个磁盘 spool，后续解析、资源与格式管线一致。
    tokio::fs::create_dir_all(&req.output_dir)
        .await
        .map_err(|e| format!("创建输出目录失败: {e}"))?;
    let mut spool =
        RawMessageSpool::create(req.output_dir.join(format!(".qce_spool_{task_id}.jsonl"))).await?;
    match input {
        ExportInput::Standard => {
            let batch_size = loose_i64(req.options.get("batchSize")).unwrap_or(5000);
            let fetcher = BatchMessageFetcher::new(
                Arc::new(state.napcat.clone()),
                BatchFetchConfig {
                    batch_size,
                    timeout_ms: 120_000,
                    retry_count: 3,
                    ..BatchFetchConfig::default()
                },
            );
            let peer = Peer {
                chat_type: req.chat_type,
                peer_uid: req.peer_uid.clone(),
                guild_id: None,
            };
            let start_time_ms =
                normalize_to_ms(loose_i64(req.filter.get("startTime")).unwrap_or(0));
            let end_time_ms =
                normalize_to_ms(loose_i64(req.filter.get("endTime")).unwrap_or_else(now_ms));
            let fetch_filter = MessageFilter {
                start_time: Some(start_time_ms),
                end_time: Some(end_time_ms),
                ..MessageFilter::default()
            };
            let mut previous = None;
            let mut batch_count: i64 = 0;
            let mut max_seq_seen: Option<i64> = None;
            let mut min_seq_seen: Option<i64> = None;
            loop {
                if is_cancelled(state, task_id, cancel_flag).await {
                    fetcher.cancel();
                    return Err("任务已被用户停止".to_string());
                }
                let fetch_result = tokio::select! {
                    result = fetcher.fetch_next_batch(&peer, &fetch_filter, previous.as_ref()) => Some(result),
                    () = wait_for_atomic_cancellation(cancel_flag) => None,
                };
                let Some(fetch_result) = fetch_result else {
                    fetcher.cancel();
                    return Err("任务已被用户停止".to_string());
                };
                let mut batch = match fetch_result {
                    Ok(Some(batch)) => batch,
                    Ok(None) => break,
                    Err(error) => return Err(format!("获取消息失败: {error}")),
                };
                batch_count += 1;
                for message in &batch.messages {
                    let Some(seq) = loose_i64(message.get("msgSeq")) else {
                        continue;
                    };
                    max_seq_seen = Some(max_seq_seen.map_or(seq, |value| value.max(seq)));
                    min_seq_seen = Some(min_seq_seen.map_or(seq, |value| value.min(seq)));
                }
                spool.append(&batch.messages).await?;
                batch.messages = Vec::new();

                let progress = estimate_fetch_progress(max_seq_seen, min_seq_seen, batch_count);
                let message = format!("已获取 {} 条消息...", spool.count());
                let _ = update_and_broadcast_progress(
                    state,
                    task_id,
                    json!({ "progress": progress, "messageCount": spool.count(), "message": message }),
                    progress,
                    &message,
                    spool.count(),
                )
                .await;
                previous = Some(batch);
            }

            // issue #662：导出流程不再做全量序列修复。
            if req.chat_type == GROUP_CHAT_TYPE {
                if let (Some(max), Some(min)) = (max_seq_seen, min_seq_seen) {
                    tracing::info!(
                        "[Export] 群聊序列覆盖: seqRange={min}..={max}, span={}, messages={}",
                        max - min + 1,
                        spool.count()
                    );
                }
            }
        }
        ExportInput::Roaming { config } => {
            let peer = Peer {
                chat_type: 1,
                peer_uid: req.peer_uid.clone(),
                guild_id: Some(String::new()),
            };
            let result = roaming_export::scan_task_into_spool(
                state,
                task_id,
                cancel_flag,
                &peer,
                &config,
                &mut spool,
            )
            .await;
            drop(history_permit.take());
            // `getMsgByClientSeqAndTime` 可能把漫游消息回填进 QQ 本地历史；与低层
            // exact 路由保持一致，扫描结束后丢弃该私聊的短期消息缓存。
            state
                .invalidate_message_cache_for_peer(1, &req.peer_uid)
                .await;
            match result {
                Ok(summary) => {
                    let completed_scan = summary.as_value();
                    let _ = update_and_broadcast_progress(
                        state,
                        task_id,
                        json!({
                            "progress": 50,
                            "message": "漫游扫描完成，准备解析消息...",
                            "messageCount": summary.message_count,
                            "processedMessages": summary.raw_messages_seen,
                            "roamingScan": completed_scan,
                        }),
                        50,
                        "漫游扫描完成，准备解析消息...",
                        summary.message_count,
                    )
                    .await;
                }
                Err(mut error) => {
                    let cancelled = error.roaming_stop_reason() == "cancelled";
                    let mut patch = json!({});
                    if let Some(roaming_scan) = error.roaming_scan.take() {
                        patch["roamingScan"] = roaming_scan;
                    }
                    if cancelled {
                        // cancel_task 已先写入终态；显式携带相同 status，允许补写最终
                        // roamingScan，而不会把任务恢复成 running/failed。
                        patch["status"] = json!("cancelled");
                        patch["message"] = json!("任务已停止");
                    } else {
                        patch["errorCode"] = json!(error.code);
                        patch["errorHttpStatus"] = json!(error.http_status);
                    }
                    let _ = update_task(state, task_id, patch).await;
                    return Err(error.message);
                }
            }
        }
    }

    if is_cancelled(state, task_id, cancel_flag).await {
        return Err("任务已被用户停止".to_string());
    }

    // 群昵称补全 + 群头衔映射（issue #331）
    let mut title_map: Option<HashMap<String, String>> = None;
    let mut member_infos: Option<Value> = None;
    if req.chat_type == GROUP_CHAT_TYPE && spool.count() > 0 {
        member_infos = fetch_group_member_infos(state, &req.peer_uid).await;
        title_map = fetch_group_member_title_map(state, &req.peer_uid, req.chat_type).await;
    }

    spool.finish().await?;

    let _ = update_and_broadcast_progress(
        state,
        task_id,
        json!({ "progress": 55, "message": "正在解析消息...", "messageCount": spool.count() }),
        55,
        "正在解析消息...",
        spool.count(),
    )
    .await;

    let sender_title_resolver = title_map.map(|map| {
        let map = Arc::new(map);
        Arc::new(move |uid: Option<&str>, uin: Option<&str>| {
            uid.and_then(|u| map.get(u).cloned())
                .or_else(|| uin.and_then(|u| map.get(u).cloned()))
        }) as crate::parser::simple_parser::SenderTitleResolver
    });
    let mut parser = SimpleMessageParser::new(SimpleParserOptions {
        html_enabled: format == "HTML" || mode != ExportMode::Standard,
        prefer_group_member_name: req
            .options
            .get("preferGroupMemberName")
            .and_then(Value::as_bool)
            .unwrap_or(true),
        sender_title_resolver,
        forward_fetcher: Some(Arc::new(state.napcat.clone()) as Arc<dyn ForwardFetcher>),
    });
    // 阶段 2（issue #634）：磁盘分块流水线，逐块解析 + 逐块资源下载（55 → 85）。
    let filter_pure_image = req
        .options
        .get("filterPureImageMessages")
        .and_then(Value::as_bool)
        == Some(true);
    if filter_pure_image {
        tracing::info!("[ApiServer] 已启用纯多媒体消息过滤，跳过资源下载");
    }
    // ResourceHandler 的跳过类型、进度回调和 last_batch_summary 是配套的可变
    // 状态。普通与漫游导出可并发，因此从配置到最后一个 chunk 的摘要/清理必须
    // 作为同一任务级临界区；owned guard 会在取消或 `?` 提前返回时自动释放。
    let resource_session_guard = if filter_pure_image {
        None
    } else {
        state
            .resource_handler
            .acquire_export_session_with_cancel(cancel_flag)
            .await
    };
    if !filter_pure_image && resource_session_guard.is_none() {
        return Err("任务已被用户停止".to_string());
    }
    if !filter_pure_image {
        state.resource_handler.set_progress_callback(None).await;
        // Issue #341：跳过下载的资源类型（仅保留元数据）。
        let requested_skip_types: Vec<String> = req
            .options
            .get("skipDownloadResourceTypes")
            .and_then(Value::as_array)
            .map_or_else(
                || {
                    if req.options.get("skipFileDownload").and_then(Value::as_bool) == Some(true) {
                        vec!["file".to_string()]
                    } else {
                        Vec::new()
                    }
                },
                |arr| {
                    arr.iter()
                        .filter_map(Value::as_str)
                        .map(str::to_lowercase)
                        .collect()
                },
            );
        let normalized_skip_types: Vec<String> = requested_skip_types
            .into_iter()
            .filter(|t| matches!(t.as_str(), "image" | "video" | "audio" | "file"))
            .collect();
        if normalized_skip_types.is_empty() {
            state.resource_handler.set_skip_download_types(None).await;
        } else {
            tracing::info!(
                "[ApiServer] 跳过下载的资源类型: {}",
                normalized_skip_types.join(", ")
            );
            state
                .resource_handler
                .set_skip_download_types(Some(&normalized_skip_types))
                .await;
        }
    }

    let total_chunks = spool.count().div_ceil(RAW_SPOOL_CHUNK_SIZE).max(1);
    // issue #666 / #634：所有导出模式统一把解析结果落盘，导出阶段按时间归并流式
    // 产出，内存占用不再随消息总数增长；资源本地路径在本块下载完成后立即写回。
    let mut clean_spool =
        CleanMessageSpool::create(req.output_dir.join(format!(".qce_clean_{task_id}.jsonl")))
            .await?;
    let mut parsed_count: usize = 0;
    let mut downloaded_resources = DownloadedResourceIndex::new();
    let mut resource_message_count: usize = 0;
    let mut resource_summary_total = ResourceBatchSummary::default();
    let mut parsed_message_ids: HashSet<String> = HashSet::new();
    let mut resource_message_ids: HashSet<String> = HashSet::new();
    let mut reader = SpoolChunkReader::open(spool.path(), RAW_SPOOL_CHUNK_SIZE).await?;
    let mut chunk_index: usize = 0;
    while let Some(chunk) = reader.next_chunk().await? {
        if is_cancelled(state, task_id, cancel_flag).await {
            return Err("任务已被用户停止".to_string());
        }
        // 按 includeUserUins / excludeUserUins 过滤（issue #369）。
        let mut chunk = apply_sender_filter(chunk, &req.filter);
        // 跨块去重（保持原先单次 parse 的全局去重语义）。
        chunk.retain(
            |message| match message.get("msgId").and_then(Value::as_str) {
                Some(id) if !id.is_empty() && id != "0" => {
                    parsed_message_ids.insert(id.to_string())
                }
                _ => true,
            },
        );
        if let Some(infos) = &member_infos {
            apply_group_member_names(infos, &mut chunk);
        }
        chunk.sort_by_key(msg_time_ms);
        if let Some(debug) = &debug_session {
            debug.append_jsonl("01-raw-messages.jsonl", &chunk).await?;
        }

        let mut parsed = parser.parse_messages(&chunk).await;
        if let Some(debug) = &debug_session {
            debug
                .append_jsonl("02-parsed-messages.jsonl", &parsed)
                .await?;
        }
        parsed_count += parsed.len();

        let progress_base = (55 + 30 * chunk_index / total_chunks) as i64;
        let progress_next = (55 + 30 * (chunk_index + 1) / total_chunks) as i64;
        if !filter_pure_image {
            let mut resource_chunk = chunk;
            resource_chunk.extend(parser.take_forward_raw_messages());
            resource_chunk.retain(|message| {
                let Some(message_id) = message.get("msgId").and_then(Value::as_str) else {
                    return true;
                };
                message_id == "0" || resource_message_ids.insert(message_id.to_string())
            });

            // 资源下载进度回调：映射到本块的进度区间。
            let state_cb = Arc::clone(state);
            let task_id_cb = task_id.to_string();
            let count_cb = parsed_count;
            let cancel_flag_cb = Arc::clone(cancel_flag);
            let span = (progress_next - progress_base).max(0) as f64;
            state
                .resource_handler
                .set_progress_callback(Some(Arc::new(move |progress| {
                    if cancel_flag_cb.load(Ordering::SeqCst) {
                        return;
                    }
                    let percent = progress_base
                        + ((progress.completed as f64 / progress.total.max(1) as f64) * span)
                            .round() as i64;
                    let _ = try_broadcast_live_progress(
                        &state_cb,
                        &task_id_cb,
                        percent,
                        &progress.message,
                        count_cb,
                    );
                })))
                .await;
            let chunk_map = state
                .resource_handler
                .process_message_resources_with_cancel_and_trace(
                    &resource_chunk,
                    Arc::clone(cancel_flag),
                    debug_session.as_ref().map(ExportDebugSession::trace),
                )
                .await;
            resource_summary_total.merge(&state.resource_handler.last_batch_summary().await);
            // issue #277：把本块已下载资源的本地路径写回消息（含嵌套转发）。
            resource_message_count += chunk_map.len();
            let value_resource_map = to_value_resource_map(&chunk_map);
            for message in &mut parsed {
                SimpleMessageParser::update_message_resource_paths_recursive(
                    message,
                    &value_resource_map,
                );
            }
            register_downloaded_resources(&mut downloaded_resources, &chunk_map);
        }

        // 段内按时间排序，段间由归并读取负责（等价于原先的全量排序）。
        parsed.sort_by_key(|message| message.timestamp);
        clean_spool.append_sorted_segment(&parsed).await?;
        drop(parsed);

        chunk_index += 1;
        let message = format!("正在解析消息与下载资源... ({chunk_index}/{total_chunks})");
        let _ = update_and_broadcast_progress(
            state,
            task_id,
            json!({ "progress": progress_next, "message": message, "messageCount": parsed_count }),
            progress_next,
            &message,
            parsed_count,
        )
        .await;
    }
    drop(reader);
    drop(spool);
    clean_spool.finish().await?;
    drop(parsed_message_ids);
    drop(resource_message_ids);
    if !filter_pure_image {
        state.resource_handler.set_progress_callback(None).await;
        state.resource_handler.set_skip_download_types(None).await;
    }
    drop(resource_session_guard);

    let resource_summary: Option<ResourceBatchSummary> = if filter_pure_image {
        None
    } else {
        tracing::info!(
            "[ApiServer] 处理了 {} 个消息的资源（attempted={}, downloaded={}, alreadyAvailable={}, failed={}, skipped={}）",
            resource_message_count,
            resource_summary_total.attempted,
            resource_summary_total.downloaded,
            resource_summary_total.already_available,
            resource_summary_total.failed,
            resource_summary_total.skipped,
        );
        Some(resource_summary_total)
    };

    if is_cancelled(state, task_id, cancel_flag).await {
        return Err("任务已被用户停止".to_string());
    }

    // 阶段 3：生成文件（85 →）
    let _ = update_and_broadcast_progress(
        state,
        task_id,
        json!({ "progress": 85, "message": "正在生成文件...", "messageCount": parsed_count }),
        85,
        "正在生成文件...",
        parsed_count,
    )
    .await;

    // Issue #30 / #192：确保输出目录存在。
    tokio::fs::create_dir_all(&req.output_dir)
        .await
        .map_err(|e| format!("创建输出目录失败: {e}"))?;
    let file_path = req.output_dir.join(file_name);

    let message_count = parsed_count;
    let self_info = state.napcat.self_info().await.unwrap_or(Value::Null);
    let self_uid = self_info
        .get("uid")
        .and_then(Value::as_str)
        .map(str::to_string);
    let self_uin = self_info
        .get("uin")
        .and_then(Value::as_str)
        .map(str::to_string);
    let self_name = self_info
        .get("nick")
        .and_then(Value::as_str)
        .map(str::to_string);
    // issue #666：全局后处理是对解析 spool 的两遍顺序扫描，而不是在内存里持有全部消息：
    //   第一遍：收集被 reply 引用的消息 ID + 解析对端 QQ 号；
    //   第二遍：只为这些被引用的消息建立图片索引（规模与 reply 数量相关）。
    let mut streaming_reply_index = ReplyImageIndex::default();
    let streaming_peer_uin: Option<String>;
    {
        let mut referenced: HashSet<String> = HashSet::new();
        let mut peer_uin_resolver = PeerUinResolver::new(&req.peer_uid, self_uin.as_deref());
        let mut scan = clean_spool.reader().await?;
        while let Some(batch) = scan.next_batch().await? {
            if is_cancelled(state, task_id, cancel_flag).await {
                return Err("任务已被用户停止".to_string());
            }
            SimpleMessageParser::collect_reply_referenced_ids(&batch, &mut referenced);
            peer_uin_resolver.consume(&batch);
        }
        streaming_peer_uin = peer_uin_resolver.finish();
        if !referenced.is_empty() {
            scan.reset().await?;
            while let Some(batch) = scan.next_batch().await? {
                if is_cancelled(state, task_id, cancel_flag).await {
                    return Err("任务已被用户停止".to_string());
                }
                SimpleMessageParser::collect_reply_preview_images(
                    &batch,
                    &referenced,
                    &mut streaming_reply_index,
                );
            }
        }
    }

    let peer_uin = if req.chat_type == GROUP_CHAT_TYPE {
        None
    } else {
        req.peer_uin.clone().or(streaming_peer_uin)
    };
    let normalized_chat_type = classify_chat_type_binary(Some(req.chat_type)).to_string();
    let chat_info = ChatInfo {
        name: req.session_name.clone(),
        chat_type: normalized_chat_type.clone(),
        avatar: chat_avatar_url(&normalized_chat_type, &req.peer_uid, peer_uin.as_deref()),
        participant_count: None,
        self_uid,
        self_uin,
        self_name,
        peer_uid: Some(req.peer_uid.clone()),
        peer_uin,
    };

    let export_options = ExportOptions {
        output_path: file_path.clone(),
        include_resource_links: req
            .options
            .get("includeResourceLinks")
            .and_then(Value::as_bool)
            .unwrap_or(true),
        include_system_messages: req
            .options
            .get("includeSystemMessages")
            .and_then(Value::as_bool)
            .unwrap_or(true),
        filter_pure_image_messages: filter_pure_image,
        pretty_format: req
            .options
            .get("prettyFormat")
            .and_then(Value::as_bool)
            .unwrap_or(true),
        prefer_group_member_name: req
            .options
            .get("preferGroupMemberName")
            .and_then(Value::as_bool)
            .unwrap_or(true),
        downloaded_resources,
        ..ExportOptions::default()
    };

    // 导出前的最终加工：自己的昵称补全 + reply 预览缩略图补全（资源本地路径已在
    // 解析阶段逐块写回）。所有格式都从解析 spool 按时间归并逐批读取。
    let finalize = |message: &mut CleanMessage| {
        backfill_self_sender_names(
            std::slice::from_mut(message),
            chat_info.self_uid.as_deref(),
            chat_info.self_uin.as_deref(),
            chat_info.self_name.as_deref(),
        );
        SimpleMessageParser::apply_reply_preview_local_paths(message, &streaming_reply_index);
    };
    if let Some(debug) = &debug_session {
        let mut scan = clean_spool.reader().await?;
        while let Some(mut batch) = scan.next_batch().await? {
            for message in &mut batch {
                finalize(message);
            }
            debug
                .append_jsonl("03-final-messages.jsonl", &batch)
                .await?;
        }
    }
    let mut source = SpooledCleanMessageSource::new(clean_spool.reader().await?, finalize);

    let mut final_file_path = file_path.clone();
    let mut final_file_name = file_name.to_string();
    let mut is_zip_export = false;
    let mut original_file_path: Option<PathBuf> = None;

    match mode {
        ExportMode::Standard => {
            let mut copied_resource_paths: Vec<String> = Vec::new();
            match format {
                "TXT" => {
                    let exporter = TextExporter::new(export_options, TextFormatOptions::default());
                    exporter
                        .export_source(&mut source, &chat_info, message_count)
                        .await
                        .map_err(|e| e.to_string())?;
                }
                "JSON" => {
                    let json_options = JsonFormatOptions {
                        embed_avatars_as_base64: req
                            .options
                            .get("embedAvatarsAsBase64")
                            .and_then(Value::as_bool)
                            == Some(true),
                        ..JsonFormatOptions::default()
                    };
                    let _ = update_and_broadcast_progress(
                        state,
                        task_id,
                        json!({ "progress": 90, "message": "正在写入JSON文件..." }),
                        90,
                        "正在写入JSON文件...",
                        message_count,
                    )
                    .await;
                    let exporter = JsonExporter::new(export_options, json_options);
                    exporter
                        .export_source(&mut source, &chat_info, message_count)
                        .await
                        .map_err(|e| e.to_string())?;
                    let _ = update_and_broadcast_progress(
                        state,
                        task_id,
                        json!({ "progress": 95, "message": "JSON文件写入完成" }),
                        95,
                        "JSON文件写入完成",
                        message_count,
                    )
                    .await;
                }
                "EXCEL" => {
                    let exporter =
                        ExcelExporter::new(export_options, ExcelFormatOptions::default());
                    exporter
                        .export_source(&mut source, &chat_info, message_count)
                        .await
                        .map_err(|e| e.to_string())?;
                }
                "HTML" => {
                    let mut html_exporter = ModernHtmlExporter::new(HtmlExportOptions {
                        output_path: file_path.clone(),
                        include_resource_links: export_options.include_resource_links,
                        include_system_messages: export_options.include_system_messages,
                        // Issue #311：自包含 HTML（资源以 base64 内联）。
                        embed_resources_as_data_uri: req
                            .options
                            .get("embedResourcesAsDataUri")
                            .and_then(Value::as_bool)
                            == Some(true),
                        max_embed_file_size_bytes: loose_i64(
                            req.options.get("maxEmbedFileSizeBytes"),
                        )
                        .and_then(|v| u64::try_from(v).ok())
                        .unwrap_or(50 * 1024 * 1024),
                        // Issue #467：打印 / PDF 友好开关，默认开启。
                        show_search_bar: req.options.get("showSearchBar").and_then(Value::as_bool)
                            != Some(false),
                        enable_virtual_scroll: req
                            .options
                            .get("enableVirtualScroll")
                            .and_then(Value::as_bool)
                            != Some(false),
                        resource_dir_name: None,
                        exporter_version: Some(crate::version::VERSION.get().to_string()),
                    });
                    copied_resource_paths = html_exporter
                        .export_single_inline_source(&mut source, &chat_info)
                        .await
                        .map_err(|e| e.to_string())?;
                }
                _ => return Err("不支持的导出格式".to_string()),
            }

            // HTML + exportAsZip（95 → 打包）。
            if format == "HTML"
                && req.options.get("exportAsZip").and_then(Value::as_bool) == Some(true)
            {
                let _ = update_and_broadcast_progress(
                    state,
                    task_id,
                    json!({ "progress": 95, "message": "正在打包ZIP文件..." }),
                    95,
                    "正在打包ZIP文件...",
                    message_count,
                )
                .await;

                let base_zip_file_name = if let Some(stripped) = file_name
                    .strip_suffix(".html")
                    .or_else(|| file_name.strip_suffix(".HTML"))
                {
                    format!("{stripped}.zip")
                } else {
                    format!("{file_name}.zip")
                };
                let zip_file_name = reserve_export_file_name(&req.output_dir, &base_zip_file_name);
                let zip_file_path = req.output_dir.join(&zip_file_name);
                let zip_result = create_zip_with_resources(
                    req.output_dir.clone(),
                    file_path.clone(),
                    copied_resource_paths,
                    zip_file_path.clone(),
                )
                .await;
                release_export_path(&zip_file_path);
                match zip_result {
                    Ok(()) => {
                        original_file_path = Some(file_path.clone());
                        final_file_path = zip_file_path;
                        final_file_name = zip_file_name;
                        is_zip_export = true;
                    }
                    Err(error) => {
                        tracing::error!("[ApiServer] 创建ZIP压缩包失败: {error}");
                        tracing::warn!("[ApiServer] 将使用原始HTML文件作为导出结果");
                    }
                }
            }
        }
        ExportMode::StreamingZip => {
            // chunked HTML 导出到临时目录，再整体打包成 ZIP。
            let temp_dir_name = format!(".{}", file_name.trim_end_matches(".zip"));
            let temp_dir = req.output_dir.join(&temp_dir_name);
            tokio::fs::create_dir_all(&temp_dir)
                .await
                .map_err(|e| format!("创建临时目录失败: {e}"))?;

            let mut html_exporter = ModernHtmlExporter::new(HtmlExportOptions {
                output_path: temp_dir.join("index.html"),
                include_resource_links: export_options.include_resource_links,
                include_system_messages: export_options.include_system_messages,
                resource_dir_name: None,
                exporter_version: Some(crate::version::VERSION.get().to_string()),
                ..HtmlExportOptions::default()
            });
            html_exporter
                .export_chunked_source(
                    &mut source,
                    &chat_info,
                    &ChunkedHtmlExportOptions::default(),
                )
                .await
                .map_err(|e| e.to_string())?;

            let _ = update_and_broadcast_progress(
                state,
                task_id,
                json!({ "progress": 95, "message": "正在打包ZIP文件..." }),
                95,
                "正在打包ZIP文件...",
                message_count,
            )
            .await;
            create_zip_from_dir(temp_dir.clone(), file_path.clone()).await?;
            let _ = tokio::fs::remove_dir_all(&temp_dir).await;
        }
        ExportMode::StreamingJsonl => {
            // manifest + chunks/*.jsonl 目录导出；头像写入同目录 avatars.json。
            let json_options = JsonFormatOptions {
                export_mode: JsonExportMode::ChunkedJsonl,
                embed_avatars_as_base64: req
                    .options
                    .get("embedAvatarsAsBase64")
                    .and_then(Value::as_bool)
                    == Some(true),
                chunked_jsonl: ChunkedJsonlExportOptions {
                    output_dir: Some(file_path.clone()),
                    ..ChunkedJsonlExportOptions::default()
                },
                ..JsonFormatOptions::default()
            };
            let mut export_options = export_options;
            export_options.output_path = file_path.join("export.json");
            let exporter = JsonExporter::new(export_options, json_options);
            exporter
                .export_chunked_jsonl_source(
                    &mut source,
                    &chat_info,
                    ChunkedJsonlExportOptions {
                        output_dir: Some(file_path.clone()),
                        ..ChunkedJsonlExportOptions::default()
                    },
                    message_count,
                )
                .await
                .map_err(|e| e.to_string())?;
        }
    }

    // 完成（100）
    if is_cancelled(state, task_id, cancel_flag).await {
        return Err("任务已被用户停止".to_string());
    }
    let file_size = dir_or_file_size(&final_file_path).await;
    let resource_summary_value = resource_summary
        .as_ref()
        .and_then(|s| serde_json::to_value(s).ok());
    let summary_message = build_resource_summary_message(resource_summary.as_ref());
    let completion_message =
        summary_message.map_or_else(|| "导出完成".to_string(), |s| format!("导出完成 · {s}"));
    let debug_path = if let Some(debug) = debug_session {
        debug
            .write_json(
                "summary.json",
                &json!({
                    "taskId": task_id,
                    "format": format,
                    "mode": format!("{mode:?}"),
                    "messageCount": message_count,
                    "resourceSummary": resource_summary,
                    "finalFileName": final_file_name,
                    "finalFileSize": file_size,
                }),
            )
            .await?;
        Some(debug.finish().await?)
    } else {
        None
    };

    // HTML + exportAsZip 会把创建时的 .html 目标替换为最终 .zip；终态任务必须
    // 持久化同一个最终 URL，避免 GET/重启恢复时用旧 URL 覆盖 WS 完成事件。
    let final_download_url = generate_download_url(
        &final_file_path,
        &final_file_name,
        &req.custom_output_dir,
        "/downloads/",
    );

    let completed_task = update_task(
        state,
        task_id,
        json!({
            "status": "completed",
            "progress": 100,
            "message": completion_message,
            "messageCount": message_count,
            "filePath": final_file_path.to_string_lossy(),
            "downloadUrl": final_download_url,
            "fileSize": file_size,
            "completedAt": now_iso(),
            "fileName": final_file_name,
            "isZipExport": is_zip_export,
            "originalFilePath": original_file_path
                .as_ref()
                .map_or(Value::Null, |p| Value::String(p.to_string_lossy().to_string())),
            "resourceSummary": resource_summary_value.clone().unwrap_or(Value::Null),
            "debugPath": debug_path
                .as_ref()
                .map_or(Value::Null, |path| Value::String(path.to_string_lossy().to_string())),
        }),
    )
    .await;

    if let Some(completed_task) = completed_task {
        state.broadcast_ws(&export_ws_event(
            "export_complete",
            json!({
                "taskId": task_id,
                "status": "completed",
                "progress": 100,
                "message": completion_message,
                "messageCount": message_count,
                "fileName": final_file_name,
                "filePath": final_file_path.to_string_lossy(),
                "fileSize": file_size,
                "downloadUrl": final_download_url,
                "isZipExport": is_zip_export,
                "originalFilePath": original_file_path
                    .as_ref()
                    .map_or(Value::Null, |p| Value::String(p.to_string_lossy().to_string())),
                "resourceSummary": resource_summary_value.unwrap_or(Value::Null),
                "debugPath": debug_path
                    .as_ref()
                    .map_or(Value::Null, |path| Value::String(path.to_string_lossy().to_string())),
            }),
            task_roaming_scan(&completed_task),
        ));
    }

    // 立即刷新数据库，确保任务状态持久化。
    if let Err(error) = state.db.flush_write_queue().await {
        tracing::warn!("[ApiServer] 刷新数据库写队列失败: {error}");
    }
    // 清除资源缓存，确保新下载的资源能被访问。
    {
        let mut cache = state.resource_file_cache.lock().await;
        cache.clear();
    }
    Ok(())
}

/// 文件大小；目录时递归求和。
async fn dir_or_file_size(path: &FsPath) -> u64 {
    match tokio::fs::metadata(path).await {
        Ok(meta) if meta.is_file() => meta.len(),
        Ok(meta) if meta.is_dir() => {
            let dir = path.to_path_buf();
            tokio::task::spawn_blocking(move || {
                walkdir::WalkDir::new(&dir)
                    .into_iter()
                    .filter_map(Result::ok)
                    .filter(|e| e.file_type().is_file())
                    .filter_map(|e| e.metadata().ok())
                    .map(|m| m.len())
                    .sum()
            })
            .await
            .unwrap_or(0)
        }
        _ => 0,
    }
}

#[cfg(test)]
mod file_name_tests {
    use super::{
        apply_live_progress_patch, apply_task_patch, build_export_dir_name, build_export_file_name,
        export_ws_event, fallback_terminal_roaming_scan, generate_download_url,
        prepare_output_directory, publish_live_task_progress, release_export_path,
        reserve_export_file_name, sanitize_chat_name, should_apply_task_patch, task_roaming_scan,
    };
    use serde_json::{json, Value};

    #[tokio::test]
    async fn creates_missing_allowed_output_directory_before_task_registration() {
        let root = std::env::temp_dir().join(format!(
            "qce-export-request-path-{}",
            uuid::Uuid::new_v4().simple()
        ));
        let allowed = root.join("QQChatExporter/exports");
        let outside = root.join("outside");
        std::fs::create_dir_all(&root).expect("create test root");

        let resolved = prepare_output_directory(&allowed, std::slice::from_ref(&allowed))
            .await
            .expect("create allowed output directory");
        assert!(allowed.is_dir());
        assert_eq!(
            resolved,
            allowed.canonicalize().expect("canonicalize allowed")
        );

        let error = prepare_output_directory(&outside, std::slice::from_ref(&allowed))
            .await
            .expect_err("reject output directory outside allowed root");
        assert!(error.message.contains(&outside.display().to_string()));
        assert!(error.message.contains(&allowed.display().to_string()));
        assert!(!outside.exists());

        std::fs::remove_dir_all(root).expect("remove test root");
    }

    #[test]
    fn cancelled_task_rejects_late_non_cancelled_updates() {
        let task = json!({ "status": "cancelled", "progress": 42 });
        assert!(!should_apply_task_patch(
            &task,
            &json!({ "status": "running", "progress": 60 })
        ));
        assert!(!should_apply_task_patch(
            &task,
            &json!({ "status": "completed", "progress": 100 })
        ));
        assert!(should_apply_task_patch(
            &task,
            &json!({ "status": "cancelled", "message": "任务已停止" })
        ));
        assert!(should_apply_task_patch(
            &task,
            &json!({
                "status": "cancelled",
                "roamingScan": {"stopReason": "cancelled", "currentDate": null}
            })
        ));
    }

    #[test]
    fn terminal_task_cannot_accept_a_running_progress_patch() {
        let mut task = json!({ "status": "cancelled", "progress": 42 });
        let updated = apply_live_progress_patch(
            Some(&mut task),
            &json!({ "status": "running", "progress": 60 }),
        );

        assert!(updated.is_none());
        assert_eq!(task["status"], "cancelled");
        assert_eq!(task["progress"], 42);

        for status in ["completed", "failed"] {
            let mut task = json!({ "status": status, "progress": 100 });
            assert!(apply_live_progress_patch(
                Some(&mut task),
                &json!({ "status": "running", "progress": 60 }),
            )
            .is_none());
            assert_eq!(task["status"], status);
            assert_eq!(task["progress"], 100);
        }
    }

    #[test]
    fn queued_task_accepts_the_running_transition() {
        let mut task = json!({ "status": "queued", "progress": 0 });
        let updated = apply_live_progress_patch(
            Some(&mut task),
            &json!({ "status": "running", "progress": 1 }),
        )
        .expect("queued task should become running after acquiring a permit");

        assert_eq!(updated["status"], "running");
        assert_eq!(updated["progress"], 1);
    }

    #[test]
    fn synchronous_progress_callback_only_publishes_for_live_tasks() {
        for status in ["completed", "failed", "cancelled"] {
            let task = json!({ "status": status });
            assert!(!publish_live_task_progress(Some(&task), |_| {
                panic!("terminal task must not publish running progress")
            }));
        }

        for status in ["queued", "pending", "running"] {
            let task = json!({ "status": status });
            let mut published = false;
            assert!(publish_live_task_progress(Some(&task), |_| published = true));
            assert!(published);
        }
        assert!(!publish_live_task_progress(None, |_| {
            panic!("deleted task must not publish running progress")
        }));
    }

    #[test]
    fn terminal_patch_requires_a_live_task_before_websocket_broadcast() {
        let patch = json!({"status": "cancelled", "message": "任务已停止"});
        assert!(apply_task_patch(None, &patch).is_none());

        let mut task = json!({"taskId": "export_fixture", "status": "running"});
        let updated = apply_task_patch(Some(&mut task), &patch)
            .expect("a live task accepts its terminal patch");
        assert_eq!(updated["status"], "cancelled");
        assert_eq!(updated["message"], "任务已停止");

        let late_completion = json!({"status": "completed", "progress": 100});
        let completion_applied = apply_task_patch(Some(&mut task), &late_completion).is_some();
        assert!(
            !completion_applied,
            "a worker cancelled mid-export must not qualify for export_complete broadcast"
        );
        assert_eq!(task["status"], "cancelled");
    }

    #[test]
    fn roaming_terminal_fallback_marks_fast_cancel_and_pre_scan_failure() {
        let task = json!({
            "taskKind": "roaming_export",
            "roamingScan": {
                "requestedDays": 30,
                "probedDays": 0,
                "partial": false,
                "stopReason": "running",
                "currentDate": "2023-01-01"
            }
        });

        let cancelled =
            fallback_terminal_roaming_scan(&task, "cancelled").expect("fast cancel fallback");
        assert_eq!(cancelled["requestedDays"], 30);
        assert_eq!(cancelled["probedDays"], 0);
        assert_eq!(cancelled["partial"], true);
        assert_eq!(cancelled["stopReason"], "cancelled");
        assert_eq!(cancelled["currentDate"], Value::Null);

        let failed =
            fallback_terminal_roaming_scan(&task, "scan_failed").expect("pre-scan fallback");
        assert_eq!(failed["partial"], true);
        assert_eq!(failed["stopReason"], "scan_failed");
        assert_eq!(failed["currentDate"], Value::Null);

        let completed_scan = json!({
            "taskKind": "roaming_export",
            "roamingScan": {"partial": true, "stopReason": "native_query_failed"}
        });
        assert!(fallback_terminal_roaming_scan(&completed_scan, "scan_failed").is_none());
        assert!(fallback_terminal_roaming_scan(
            &json!({"taskKind": "standard", "roamingScan": task["roamingScan"]}),
            "scan_failed"
        )
        .is_none());
    }

    #[test]
    fn websocket_export_events_include_roaming_metadata_only_for_roaming_tasks() {
        let scan = json!({
            "partial": true,
            "stopReason": "unresolved_anchors",
            "messageCount": 42,
        });
        let roaming_task = json!({
            "taskKind": "roaming_export",
            "roamingScan": scan,
        });

        for event_type in ["export_progress", "export_complete", "export_error"] {
            let event = export_ws_event(
                event_type,
                json!({"taskId": "roaming_fixture"}),
                task_roaming_scan(&roaming_task),
            );
            assert_eq!(event["type"], event_type);
            assert_eq!(event["data"]["taskKind"], "roaming_export");
            assert_eq!(event["data"]["roamingScan"], roaming_task["roamingScan"]);

            let standard = export_ws_event(event_type, json!({"taskId": "standard_fixture"}), None);
            let data = standard["data"].as_object().expect("event data object");
            assert!(!data.contains_key("taskKind"));
            assert!(!data.contains_key("roamingScan"));
        }
    }

    #[test]
    fn sanitizes_windows_unsafe_and_reserved_components() {
        assert_eq!(
            sanitize_chat_name(" AxT<>:\"/\\|?* 鸽子窝. ", 64),
            "AxT_鸽子窝"
        );
        assert_eq!(sanitize_chat_name("CON.", 64), "_CON");
        assert_eq!(sanitize_chat_name("Lpt9", 64), "_Lpt9");
        assert_eq!(sanitize_chat_name("你好世界", 3), "你好世");
    }

    #[test]
    fn builds_readable_friend_group_and_streaming_names() {
        assert_eq!(
            build_export_file_name(
                "friend",
                "1687657986",
                "笨蛋Darf v2",
                "20260712",
                "163632123",
                "html",
                false,
                false,
            ),
            "friend_笨蛋Darf_v2_1687657986_20260712_163632123.html"
        );
        assert_eq!(
            build_export_dir_name(
                "group",
                "960420904",
                "AxT 鸽子窝",
                "20260712",
                "163632123",
                "_chunked_jsonl",
                false,
                false,
            ),
            "group_AxT_鸽子窝_960420904_20260712_163632123_chunked_jsonl"
        );
    }

    #[test]
    fn completed_zip_uses_the_registered_download_route() {
        let path = std::path::PathBuf::from("/tmp/friend_fixture.zip");
        assert_eq!(
            generate_download_url(&path, "friend_fixture.zip", "", "/downloads/"),
            "/downloads/friend_fixture.zip"
        );
        assert!(
            generate_download_url(&path, "friend_fixture.zip", "/tmp", "/downloads/")
                .starts_with("/api/download-file?path=")
        );
    }

    #[test]
    fn disambiguates_existing_files_and_directories_without_overwriting() {
        let base =
            std::env::temp_dir().join(format!("qce-export-name-{}", uuid::Uuid::new_v4().simple()));
        std::fs::create_dir_all(&base).unwrap();
        std::fs::write(base.join("friend_name_1_20260712_163632123.html"), b"old").unwrap();
        let file_collision =
            reserve_export_file_name(&base, "friend_name_1_20260712_163632123.html");
        assert_eq!(file_collision, "friend_name_1_20260712_163632123_2.html");
        release_export_path(&base.join(file_collision));

        std::fs::create_dir(base.join("group_name_2_20260712_163632123_chunked_jsonl")).unwrap();
        let dir_collision =
            reserve_export_file_name(&base, "group_name_2_20260712_163632123_chunked_jsonl");
        assert_eq!(
            dir_collision,
            "group_name_2_20260712_163632123_chunked_jsonl_2"
        );
        release_export_path(&base.join(dir_collision));
        let concurrent =
            reserve_export_file_name(&base, "friend_concurrent_1_20260712_163632123.html");
        let concurrent_2 =
            reserve_export_file_name(&base, "friend_concurrent_1_20260712_163632123.html");
        assert_eq!(
            concurrent_2,
            "friend_concurrent_1_20260712_163632123_2.html"
        );
        release_export_path(&base.join(concurrent));
        release_export_path(&base.join(concurrent_2));
        std::fs::remove_dir_all(base).unwrap();
    }
}

#[cfg(test)]
mod task_queue_tests {
    use super::*;
    use serde_json::json;
    use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
    use std::sync::Arc;
    use std::time::Duration;

    struct DummyExecutor;
    #[async_trait::async_trait]
    impl crate::scheduler::manager::ScheduledExportExecutor for DummyExecutor {
        async fn execute(
            &self,
            _task: &Value,
            _start_time_sec: i64,
            _end_time_sec: i64,
        ) -> Result<crate::scheduler::manager::ExecutionOutcome, String> {
            Ok(crate::scheduler::manager::ExecutionOutcome {
                message_count: 0,
                file_path: None,
                file_size: None,
                resource_summary: None,
                note: None,
            })
        }
    }

    async fn create_test_state() -> (crate::api::state::SharedState, std::path::PathBuf) {
        let temp =
            std::env::temp_dir().join(format!("qce-test-queue-{}", uuid::Uuid::new_v4().simple()));
        std::fs::create_dir_all(&temp).expect("create temp dir");
        let db = Arc::new(crate::storage::DatabaseManager::new(&temp.join("qce.db")));
        db.initialize().await.expect("init db");
        let (ws_tx, _) = tokio::sync::broadcast::channel(16);
        let path_manager = Arc::new(crate::paths::PathManager::new());
        let napcat =
            crate::napcat::NapCatBridgeClient::new("http://127.0.0.1:40654", 10_000).unwrap();
        let resource_handler = Arc::new(
            crate::resource::ResourceHandler::new(
                Arc::new(napcat.clone()),
                None,
                Arc::clone(&db),
                crate::resource::ResourceHandlerConfig {
                    storage_root: temp.join("resources"),
                    ..crate::resource::ResourceHandlerConfig::default()
                },
            )
            .await,
        );
        let progress_tracker = Arc::new(crate::progress::ProgressTracker::new(Arc::clone(&db)));
        let security_manager = Arc::new(crate::security::SecurityManager::new().unwrap());
        let scheduled_export_manager = Arc::new(crate::scheduler::ScheduledExportManager::new(
            Arc::clone(&db),
            Arc::new(DummyExecutor),
        ));
        let state = Arc::new(crate::api::state::AppState {
            napcat,
            run_mode: crate::api::state::RunMode::Plugin,
            db,
            resource_handler,
            progress_tracker,
            scheduled_export_manager,
            security_manager,
            path_manager,
            ws_tx,
            export_tasks: tokio::sync::Mutex::new(std::collections::HashMap::new()),
            export_semaphore: Arc::new(tokio::sync::Semaphore::new(
                crate::api::state::MAX_ACTIVE_EXPORT_TASKS,
            )),
            cancelled_task_ids: tokio::sync::Mutex::new(std::collections::HashSet::new()),
            running_export_cancel_flags: tokio::sync::Mutex::new(std::collections::HashMap::new()),
            resource_file_cache: tokio::sync::Mutex::new(std::collections::HashMap::new()),
            message_cache: tokio::sync::Mutex::new(std::collections::HashMap::new()),
            started_at: std::time::Instant::now(),
            static_dir: temp.clone(),
            port: 0,
        });
        (state, temp)
    }

    #[tokio::test]
    async fn queue_handles_hundreds_of_tasks_without_dropping_requests() {
        let (state, temp) = create_test_state().await;

        // 旧版本上限为 MAX_ACTIVE_EXPORT_TASKS (32)，只要活跃任务达到 32，后续请求就会被忽略。
        // 新版本上限为 MAX_QUEUED_TASKS (1000)，能够容纳数百个导出任务排队。
        const BATCH_SIZE: usize = 300;
        let mut registered_ids = Vec::with_capacity(BATCH_SIZE);

        for i in 0..BATCH_SIZE {
            let task_id = format!("test-task-{i}");
            let task = json!({
                "taskId": task_id,
                "peer": { "chatType": 1, "peerUid": format!("user_{i}") },
                "sessionName": format!("会话_{i}"),
                "status": "queued",
                "message": "正在排队中...",
                "progress": 0,
                "createdAt": now_iso(),
            });
            let success = register_task(&state, &task).await;
            assert!(success, "任务 {i} 应该成功进入队列");
            registered_ids.push(task_id);
        }

        // 验证任务总数达到 300 个，全部状态为 queued
        let tasks = state.export_tasks.lock().await;
        assert_eq!(tasks.len(), BATCH_SIZE);
        for id in &registered_ids {
            assert_eq!(
                tasks
                    .get(id)
                    .and_then(|t| t.get("status"))
                    .and_then(Value::as_str),
                Some("queued")
            );
        }
        drop(tasks);

        let _ = std::fs::remove_dir_all(temp);
    }

    #[tokio::test]
    async fn semaphore_limits_concurrent_running_tasks_while_draining_queue() {
        let (state, temp) = create_test_state().await;

        const TOTAL_TASKS: usize = 100;
        let currently_running = Arc::new(AtomicUsize::new(0));
        let peak_running = Arc::new(AtomicUsize::new(0));
        let completed_count = Arc::new(AtomicUsize::new(0));

        let mut handles = Vec::with_capacity(TOTAL_TASKS);

        for _ in 0..TOTAL_TASKS {
            let state_clone = Arc::clone(&state);
            let currently_running_clone = Arc::clone(&currently_running);
            let peak_running_clone = Arc::clone(&peak_running);
            let completed_count_clone = Arc::clone(&completed_count);

            let handle = tokio::spawn(async move {
                // 模拟 run_export_task 中的信号量排队获取
                let _permit = state_clone.export_semaphore.acquire().await.unwrap();

                // 模拟获取到许可，任务开始执行
                let cur = currently_running_clone.fetch_add(1, Ordering::SeqCst) + 1;
                peak_running_clone.fetch_max(cur, Ordering::SeqCst);

                // 确保任何时刻并发运行的任务数均不超过 MAX_ACTIVE_EXPORT_TASKS (32)
                assert!(
                    cur <= crate::api::state::MAX_ACTIVE_EXPORT_TASKS,
                    "并发任务数 {cur} 超过了上限 32"
                );

                // 模拟耗时任务
                tokio::time::sleep(Duration::from_millis(5)).await;

                currently_running_clone.fetch_sub(1, Ordering::SeqCst);
                completed_count_clone.fetch_add(1, Ordering::SeqCst);
            });
            handles.push(handle);
        }

        for handle in handles {
            handle.await.unwrap();
        }

        assert_eq!(
            completed_count.load(Ordering::SeqCst),
            TOTAL_TASKS,
            "所有100个任务均应顺利完成"
        );
        assert_eq!(
            currently_running.load(Ordering::SeqCst),
            0,
            "全部完成后运行中任务数应为0"
        );
        let peak = peak_running.load(Ordering::SeqCst);
        assert!(
            peak <= crate::api::state::MAX_ACTIVE_EXPORT_TASKS,
            "峰值并发 {peak} 不得超出 32"
        );
        assert_eq!(
            state.export_semaphore.available_permits(),
            crate::api::state::MAX_ACTIVE_EXPORT_TASKS,
            "全部完成后信号量许可应全数归还"
        );

        let _ = std::fs::remove_dir_all(temp);
    }

    #[tokio::test]
    async fn queued_task_cancelled_before_acquire_does_not_execute() {
        let (state, temp) = create_test_state().await;

        let task_id = "test-cancel-in-queue";
        let task = json!({
            "taskId": task_id,
            "status": "queued",
            "progress": 0,
        });
        register_task(&state, &task).await;

        let cancel_flag = Arc::new(AtomicBool::new(false));
        {
            let mut flags = state.running_export_cancel_flags.lock().await;
            flags.insert(task_id.to_string(), Arc::clone(&cancel_flag));
        }

        // 用户在排队期间取消了任务
        cancel_flag.store(true, Ordering::SeqCst);
        {
            let mut cancelled = state.cancelled_task_ids.lock().await;
            cancelled.insert(task_id.to_string());
        }

        // 模拟 run_export_task 的许可获取与取消检查逻辑
        let mut executed_export = false;
        if let Ok(_permit) = state.export_semaphore.acquire().await {
            if is_cancelled(&state, task_id, &cancel_flag).await {
                // 正确识别取消，不执行实际导出
            } else {
                executed_export = true;
            }
        }

        assert!(
            !executed_export,
            "排队中被取消的任务获取到许可后不应执行导出操作"
        );
        assert_eq!(
            state.export_semaphore.available_permits(),
            crate::api::state::MAX_ACTIVE_EXPORT_TASKS,
            "许可必须立刻归还"
        );

        let _ = std::fs::remove_dir_all(temp);
    }

    #[tokio::test]
    async fn roaming_history_gate_wait_is_pending_and_cancellable() {
        let (state, temp) = create_test_state().await;
        let task_id = "test-roaming-history-wait";
        let task = json!({
            "taskId": task_id,
            "taskKind": "roaming_export",
            "status": "queued",
            "progress": 0,
        });
        assert!(register_task(&state, &task).await);

        let history_blocker = acquire_history_query_permit()
            .await
            .expect("acquire history gate blocker");
        let cancel_flag = Arc::new(AtomicBool::new(false));
        let observer_flag = Arc::clone(&cancel_flag);
        let observer_state = Arc::clone(&state);
        let input = ExportInput::Roaming {
            config: RoamingExportConfig {
                start_time: 1_672_531_200,
                end_time: 1_672_617_599,
                start_date: NaiveDate::from_ymd_opt(2023, 1, 1).unwrap(),
                end_date: NaiveDate::from_ymd_opt(2023, 1, 1).unwrap(),
                requested_days: 1,
                max_messages: 1,
                max_sequence_queries: 1,
            },
        };

        let wait =
            wait_for_export_input_history_permit(&state, task_id, cancel_flag.as_ref(), &input);
        let observe_and_cancel = async move {
            let mut observed_pending = false;
            for _ in 0..100 {
                observed_pending = observer_state
                    .export_tasks
                    .lock()
                    .await
                    .get(task_id)
                    .and_then(|task| task.get("status"))
                    .and_then(Value::as_str)
                    == Some("pending");
                if observed_pending {
                    break;
                }
                tokio::time::sleep(Duration::from_millis(10)).await;
            }
            observer_flag.store(true, Ordering::SeqCst);
            observed_pending
        };
        let (wait_result, observed_pending) = tokio::time::timeout(Duration::from_secs(2), async {
            tokio::join!(wait, observe_and_cancel)
        })
        .await
        .expect("cancellation must stop the history gate wait");

        assert!(observed_pending, "等待 history gate 时任务应进入 pending");
        assert!(matches!(wait_result, Err(error) if error == "任务已被用户停止"));
        assert!(crate::fetcher::try_history_query_permit().is_err());

        drop(history_blocker);
        let _ = std::fs::remove_dir_all(temp);
    }

    #[tokio::test]
    async fn worker_registration_observes_an_existing_cancel_marker() {
        let (state, temp) = create_test_state().await;
        let task_id = "test-cancel-before-worker-registration";
        {
            let mut cancelled = state.cancelled_task_ids.lock().await;
            cancelled.insert(task_id.to_string());
        }

        let cancel_flag = register_export_cancel_flag(&state, task_id).await;

        assert!(cancel_flag.load(Ordering::SeqCst));
        assert!(state
            .running_export_cancel_flags
            .lock()
            .await
            .get(task_id)
            .is_some_and(|registered| registered.load(Ordering::SeqCst)));

        let _ = std::fs::remove_dir_all(temp);
    }
}
