use std::collections::{HashMap, HashSet};
use std::path::PathBuf;
use std::sync::atomic::AtomicBool;
use std::sync::{Arc, Mutex, OnceLock};

use async_trait::async_trait;
use serde_json::Value;

use qce_exporter::json_exporter::{JsonExporter, JsonFormatOptions};
use qce_exporter::modern_html_exporter::{HtmlExportOptions, ModernHtmlExporter};
use qce_exporter::text_exporter::{TextExporter, TextFormatOptions};
use qce_exporter::{ChatInfo, CleanMessage, DownloadedResourceIndex, ExportOptions};

use qce_server::api::helpers::{backfill_self_sender_names, chat_avatar_url, PeerUinResolver};
use qce_server::api::path_security::resolve_for_creation_within;
use qce_server::clean_message_spool::{CleanMessageSpool, SpooledCleanMessageSource};
use qce_server::export_debug::ExportDebugSession;
use qce_server::fetcher::{
    classify_chat_type_binary, BatchFetchConfig, BatchMessageFetcher, MessageFilter, Peer,
};
use qce_server::napcat::NapCatBridgeClient;
use qce_server::parser::simple_parser::ReplyImageIndex;
use qce_server::parser::{ForwardFetcher, SimpleMessageParser, SimpleParserOptions};
use qce_server::paths::{sanitize_task_name, PathManager};
use qce_server::resource::{ResourceBatchSummary, ResourceHandler};
use qce_server::scheduler::{ExecutionOutcome, ScheduledExportExecutor};
use qce_server::storage::ResourceInfo;

/// 基于 NapCat bridge 的定时导出执行器。
pub struct ApiScheduledExportExecutor {
    napcat: NapCatBridgeClient,
    resource_handler: Arc<ResourceHandler>,
    path_manager: Arc<PathManager>,
}

impl ApiScheduledExportExecutor {
    /// 创建执行器。
    pub fn new(
        napcat: NapCatBridgeClient,
        resource_handler: Arc<ResourceHandler>,
        path_manager: Arc<PathManager>,
    ) -> Self {
        Self {
            napcat,
            resource_handler,
            path_manager,
        }
    }
}

#[async_trait]
impl ScheduledExportExecutor for ApiScheduledExportExecutor {
    async fn execute(
        &self,
        task: &Value,
        start_time_sec: i64,
        end_time_sec: i64,
    ) -> Result<ExecutionOutcome, String> {
        let peer_value = task.get("peer").ok_or("任务缺少 peer 配置")?;
        let chat_type = loose_i64(peer_value.get("chatType")).ok_or("peer.chatType 无效")?;
        let peer_uid = peer_value
            .get("peerUid")
            .and_then(Value::as_str)
            .filter(|s| !s.is_empty())
            .ok_or("peer.peerUid 无效")?
            .to_string();
        let peer_uin = peer_value
            .get("peerUin")
            .and_then(Value::as_str)
            .map(str::trim)
            .filter(|value| !value.is_empty())
            .map(str::to_string);
        let task_name = task
            .get("name")
            .and_then(Value::as_str)
            .unwrap_or("scheduled_export")
            .to_string();
        let session_name = task
            .get("sessionName")
            .and_then(Value::as_str)
            .map(str::trim)
            .filter(|value| !value.is_empty())
            .unwrap_or(&task_name)
            .to_string();
        let format = task
            .get("format")
            .and_then(Value::as_str)
            .unwrap_or("HTML")
            .to_uppercase();
        let options = task.get("options").cloned().unwrap_or(Value::Null);
        // Issue #644：任务自带的输出目录可以指向默认导出根之外的位置（例如另一个盘），
        // 由 `PathManager` 统一做安全校验后加入允许的根集合。
        let output_dir = resolve_scheduled_output_dir(
            &self.path_manager,
            task.get("outputDir").and_then(Value::as_str),
        )?;
        let debug_session = if options.get("debugExport").and_then(Value::as_bool) == Some(true) {
            let export_name = format!(
                "scheduled-{}-{}",
                sanitize_task_name(&task_name, 40),
                chrono::Local::now().format("%Y%m%d_%H%M%S%3f")
            );
            let session = ExportDebugSession::start(&output_dir, &export_name).await?;
            session
                .trace()
                .record(serde_json::json!({
                    "type": "scheduled_export_started",
                    "format": format,
                }))
                .await;
            Some(session)
        } else {
            None
        };

        // 阶段 1：抓取消息
        let fetcher = BatchMessageFetcher::new(
            Arc::new(self.napcat.clone()),
            BatchFetchConfig {
                batch_size: 1000,
                timeout_ms: 30_000,
                retry_count: 3,
                ..BatchFetchConfig::default()
            },
        );
        let peer = Peer {
            chat_type,
            peer_uid: peer_uid.clone(),
            guild_id: None,
        };
        let fetch_filter = MessageFilter {
            start_time: Some(start_time_sec * 1000),
            end_time: Some(end_time_sec * 1000),
            ..MessageFilter::default()
        };

        // 阶段 2 准备：资源下载（issue #341 跳过类型）
        // 与交互式普通/漫游导出共享 ResourceHandler；其配置、回调与摘要必须在
        // 完整任务级资源阶段内保持一致。guard 在任何错误/提前返回时自动释放。
        let resource_session_guard = self.resource_handler.acquire_export_session().await;
        self.resource_handler.set_progress_callback(None).await;
        let requested_skip_types: Vec<String> = options
            .get("skipDownloadResourceTypes")
            .and_then(Value::as_array)
            .map_or_else(
                || {
                    if options.get("skipFileDownload").and_then(Value::as_bool) == Some(true) {
                        vec!["file".to_string()]
                    } else {
                        Vec::new()
                    }
                },
                |arr| {
                    arr.iter()
                        .filter_map(Value::as_str)
                        .map(str::to_lowercase)
                        .collect()
                },
            );
        let normalized_skip_types: Vec<String> = requested_skip_types
            .into_iter()
            .filter(|t| matches!(t.as_str(), "image" | "video" | "audio" | "file"))
            .collect();
        if normalized_skip_types.is_empty() {
            self.resource_handler.set_skip_download_types(None).await;
        } else {
            self.resource_handler
                .set_skip_download_types(Some(&normalized_skip_types))
                .await;
        }

        let mut parser = SimpleMessageParser::new(SimpleParserOptions {
            html_enabled: format == "HTML",
            prefer_group_member_name: options
                .get("preferGroupMemberName")
                .and_then(Value::as_bool)
                .unwrap_or(true),
            sender_title_resolver: None,
            forward_fetcher: Some(Arc::new(self.napcat.clone()) as Arc<dyn ForwardFetcher>),
        });

        // 阶段 1+2：逐批抓取 → 下载资源 → 解析 → 写回本地路径 → 落盘（issue #666）。
        // 全程只持有一批消息；批间顺序由 CleanMessageSpool 的归并读取保证。
        tokio::fs::create_dir_all(&output_dir)
            .await
            .map_err(|e| format!("创建输出目录失败: {e}"))?;
        let spool_name = format!(".qce_sched_{}.jsonl", uuid::Uuid::new_v4().simple());
        let mut clean_spool = CleanMessageSpool::create(output_dir.join(spool_name)).await?;
        let mut downloaded_resources = DownloadedResourceIndex::new();
        let mut seen_message_ids: HashSet<String> = HashSet::new();
        let mut resource_summary_total = ResourceBatchSummary::default();
        let mut message_count: i64 = 0;
        let mut previous = None;
        loop {
            let batch = match fetcher
                .fetch_next_batch(&peer, &fetch_filter, previous.as_ref())
                .await
            {
                Ok(Some(batch)) => batch,
                Ok(None) => break,
                Err(error) => return Err(format!("获取消息失败: {error}")),
            };
            let mut chunk: Vec<Value> = batch
                .messages
                .iter()
                .filter(
                    |message| match message.get("msgId").and_then(Value::as_str) {
                        Some(id) if !id.is_empty() && id != "0" => {
                            seen_message_ids.insert(id.to_string())
                        }
                        _ => true,
                    },
                )
                .cloned()
                .collect();
            previous = Some(batch);
            if chunk.is_empty() {
                continue;
            }
            // 按时间升序排序（抓取返回的是倒序）。
            chunk.sort_by_key(msg_time_ms);
            if let Some(debug) = &debug_session {
                debug.append_jsonl("01-raw-messages.jsonl", &chunk).await?;
            }

            let mut parsed: Vec<CleanMessage> = parser.parse_messages(&chunk).await;
            if let Some(debug) = &debug_session {
                debug
                    .append_jsonl("02-parsed-messages.jsonl", &parsed)
                    .await?;
            }
            message_count += parsed.len() as i64;

            chunk.extend(parser.take_forward_raw_messages());
            let chunk_map = self
                .resource_handler
                .process_message_resources_with_cancel_and_trace(
                    &chunk,
                    Arc::new(AtomicBool::new(false)),
                    debug_session.as_ref().map(ExportDebugSession::trace),
                )
                .await;
            drop(chunk);
            resource_summary_total.merge(&self.resource_handler.last_batch_summary().await);
            // issue #277：把已下载资源的本地路径写回消息。
            let value_resource_map = to_value_resource_map(&chunk_map);
            for message in &mut parsed {
                SimpleMessageParser::update_message_resource_paths_recursive(
                    message,
                    &value_resource_map,
                );
            }
            for resource in chunk_map.values().flatten() {
                if let Some(local_path) = resource.local_path.as_deref() {
                    downloaded_resources.insert(&resource.resource_type, local_path);
                }
            }

            parsed.sort_by_key(|message| message.timestamp);
            clean_spool.append_sorted_segment(&parsed).await?;
        }
        drop(seen_message_ids);
        // issue #363：资源下载摘要。
        let resource_summary = serde_json::to_value(&resource_summary_total).ok();
        // 重置共享 ResourceHandler 的状态，避免影响后续任务。
        self.resource_handler.set_progress_callback(None).await;
        self.resource_handler.set_skip_download_types(None).await;
        drop(resource_session_guard);

        if message_count == 0 {
            return Ok(ExecutionOutcome {
                message_count: 0,
                note: Some("指定时间范围内没有消息".to_string()),
                ..ExecutionOutcome::default()
            });
        }
        clean_spool.finish().await?;

        // 阶段 3：文件名 / 输出目录
        let timestamp = chrono::Local::now().format("%Y%m%d_%H%M%S%3f");
        let chat_type_name = if chat_type == 2 { "group" } else { "friend" };
        let peer_identity = if chat_type == 2 {
            peer_uid.as_str()
        } else {
            peer_uin.as_deref().unwrap_or(&peer_uid)
        };
        let base_file_name = scheduled_export_file_name(
            chat_type_name,
            &session_name,
            peer_identity,
            &timestamp.to_string(),
            &format.to_lowercase(),
        );
        let (file_name, _reservation) = reserve_scheduled_file_name(&output_dir, &base_file_name);
        let file_path = output_dir.join(&file_name);

        // 阶段 4：两遍顺序扫描做全局后处理（reply 预览索引 + 对端 QQ 号），再导出。
        let self_info = self.napcat.self_info().await.unwrap_or(Value::Null);
        let self_uid = self_info
            .get("uid")
            .and_then(Value::as_str)
            .map(str::to_string);
        let self_uin = self_info
            .get("uin")
            .and_then(Value::as_str)
            .map(str::to_string);
        let self_name = self_info
            .get("nick")
            .and_then(Value::as_str)
            .map(str::to_string);
        let mut reply_index = ReplyImageIndex::default();
        let resolved_peer_uin: Option<String>;
        {
            let mut referenced: HashSet<String> = HashSet::new();
            let mut peer_uin_resolver = PeerUinResolver::new(&peer_uid, self_uin.as_deref());
            let mut scan = clean_spool.reader().await?;
            while let Some(batch) = scan.next_batch().await? {
                SimpleMessageParser::collect_reply_referenced_ids(&batch, &mut referenced);
                peer_uin_resolver.consume(&batch);
            }
            resolved_peer_uin = peer_uin_resolver.finish();
            if !referenced.is_empty() {
                scan.reset().await?;
                while let Some(batch) = scan.next_batch().await? {
                    SimpleMessageParser::collect_reply_preview_images(
                        &batch,
                        &referenced,
                        &mut reply_index,
                    );
                }
            }
        }

        let peer_uin = (chat_type != 2)
            .then(|| peer_uin.clone().or(resolved_peer_uin))
            .flatten();
        let normalized_chat_type = classify_chat_type_binary(Some(chat_type)).to_string();
        let chat_info = ChatInfo {
            name: session_name,
            chat_type: normalized_chat_type.clone(),
            avatar: chat_avatar_url(&normalized_chat_type, &peer_uid, peer_uin.as_deref()),
            participant_count: None,
            self_uid,
            self_uin,
            self_name,
            peer_uid: Some(peer_uid.clone()),
            peer_uin,
        };

        let finalize = |message: &mut CleanMessage| {
            backfill_self_sender_names(
                std::slice::from_mut(message),
                chat_info.self_uid.as_deref(),
                chat_info.self_uin.as_deref(),
                chat_info.self_name.as_deref(),
            );
            SimpleMessageParser::apply_reply_preview_local_paths(message, &reply_index);
        };
        if let Some(debug) = &debug_session {
            let mut scan = clean_spool.reader().await?;
            while let Some(mut batch) = scan.next_batch().await? {
                for message in &mut batch {
                    finalize(message);
                }
                debug
                    .append_jsonl("03-final-messages.jsonl", &batch)
                    .await?;
            }
        }
        let mut source = SpooledCleanMessageSource::new(clean_spool.reader().await?, finalize);
        let total_hint = usize::try_from(message_count).unwrap_or(0);

        let include_resource_links = options
            .get("includeResourceLinks")
            .and_then(Value::as_bool)
            .unwrap_or(true);
        let include_system_messages = options
            .get("includeSystemMessages")
            .and_then(Value::as_bool)
            .unwrap_or(true);
        let export_options = ExportOptions {
            output_path: file_path.clone(),
            include_resource_links,
            include_system_messages,
            filter_pure_image_messages: options
                .get("filterPureImageMessages")
                .and_then(Value::as_bool)
                == Some(true),
            pretty_format: options
                .get("prettyFormat")
                .and_then(Value::as_bool)
                .unwrap_or(true),
            prefer_group_member_name: options
                .get("preferGroupMemberName")
                .and_then(Value::as_bool)
                .unwrap_or(true),
            downloaded_resources,
            ..ExportOptions::default()
        };

        match format.as_str() {
            "HTML" => {
                let mut exporter = ModernHtmlExporter::new(HtmlExportOptions {
                    output_path: file_path.clone(),
                    include_resource_links,
                    include_system_messages,
                    // Issue #311：自包含 HTML（资源以 base64 内联）。
                    embed_resources_as_data_uri: options
                        .get("embedResourcesAsDataUri")
                        .and_then(Value::as_bool)
                        == Some(true),
                    max_embed_file_size_bytes: loose_i64(options.get("maxEmbedFileSizeBytes"))
                        .and_then(|v| u64::try_from(v).ok())
                        .unwrap_or(50 * 1024 * 1024),
                    // Issue #467：打印 / PDF 友好开关，默认开启。
                    show_search_bar: options.get("showSearchBar").and_then(Value::as_bool)
                        != Some(false),
                    enable_virtual_scroll: options
                        .get("enableVirtualScroll")
                        .and_then(Value::as_bool)
                        != Some(false),
                    resource_dir_name: None,
                    exporter_version: Some(qce_server::version::VERSION.get().to_string()),
                });
                exporter
                    .export_single_inline_source(&mut source, &chat_info)
                    .await
                    .map_err(|e| e.to_string())?;
            }
            "JSON" => {
                let exporter = JsonExporter::new(export_options, JsonFormatOptions::default());
                exporter
                    .export_source(&mut source, &chat_info, total_hint)
                    .await
                    .map_err(|e| e.to_string())?;
            }
            "TXT" => {
                let exporter = TextExporter::new(export_options, TextFormatOptions::default());
                exporter
                    .export_source(&mut source, &chat_info, total_hint)
                    .await
                    .map_err(|e| e.to_string())?;
            }
            other => return Err(format!("不支持的定时导出格式: {other}")),
        }
        drop(source);
        drop(clean_spool);

        let file_size = tokio::fs::metadata(&file_path)
            .await
            .ok()
            .and_then(|meta| i64::try_from(meta.len()).ok());
        if let Some(debug) = debug_session {
            debug
                .write_json(
                    "summary.json",
                    &serde_json::json!({
                        "format": format,
                        "messageCount": message_count,
                        "resourceSummary": resource_summary,
                        "finalFileName": file_name,
                        "finalFileSize": file_size,
                    }),
                )
                .await?;
            debug.finish().await?;
        }

        Ok(ExecutionOutcome {
            message_count,
            file_path: Some(file_path.to_string_lossy().into_owned()),
            file_size,
            resource_summary,
            note: None,
        })
    }
}

fn scheduled_export_file_name(
    chat_type: &str,
    session_name: &str,
    peer_identity: &str,
    timestamp: &str,
    extension: &str,
) -> String {
    format!(
        "{chat_type}_{}_{}_{timestamp}.{extension}",
        sanitize_task_name(session_name, 40),
        sanitize_task_name(peer_identity, 32),
    )
}

fn collision_name(file_name: &str, suffix: u32) -> String {
    let (base, extension) = file_name
        .rsplit_once('.')
        .map_or((file_name, String::new()), |(base, extension)| {
            (base, format!(".{extension}"))
        });
    format!("{base}_{suffix}{extension}")
}

fn reserved_scheduled_paths() -> &'static Mutex<HashSet<PathBuf>> {
    static RESERVED: OnceLock<Mutex<HashSet<PathBuf>>> = OnceLock::new();
    RESERVED.get_or_init(|| Mutex::new(HashSet::new()))
}

struct ScheduledPathReservation(PathBuf);

impl Drop for ScheduledPathReservation {
    fn drop(&mut self) {
        reserved_scheduled_paths()
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .remove(&self.0);
    }
}

fn reserve_scheduled_file_name(
    output_dir: &std::path::Path,
    file_name: &str,
) -> (String, ScheduledPathReservation) {
    let mut reserved = reserved_scheduled_paths()
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner);
    for suffix in 1_u32.. {
        let candidate = if suffix == 1 {
            file_name.to_string()
        } else {
            collision_name(file_name, suffix)
        };
        let path = output_dir.join(&candidate);
        if !path.exists() && !reserved.contains(&path) {
            reserved.insert(path.clone());
            return (candidate, ScheduledPathReservation(path));
        }
    }
    unreachable!("u32 filename suffix space exhausted")
}

/// 从 JSON 里宽松取 i64（数字或数字字符串）。
fn loose_i64(value: Option<&Value>) -> Option<i64> {
    match value {
        Some(Value::Number(n)) => n.as_i64().or_else(|| n.as_f64().map(|f| f as i64)),
        Some(Value::String(s)) => s.trim().parse::<i64>().ok(),
        _ => None,
    }
}

/// 消息 msgTime → 毫秒（10 位秒级自动 ×1000）。
fn msg_time_ms(message: &Value) -> i64 {
    let ts = loose_i64(message.get("msgTime")).unwrap_or(0);
    if ts > 1_000_000_000 && ts < 10_000_000_000 {
        ts * 1000
    } else {
        ts
    }
}

/// 资源映射 → `update_single_message_resource_paths` 需要的 Value 列表。
fn to_value_resource_map(
    resource_map: &HashMap<String, Vec<ResourceInfo>>,
) -> HashMap<String, Vec<Value>> {
    resource_map
        .iter()
        .map(|(msg_id, resources)| {
            let values = resources
                .iter()
                .filter_map(|r| serde_json::to_value(r).ok())
                .collect();
            (msg_id.clone(), values)
        })
        .collect()
}

/// 解析定时导出的输出目录。
///
/// Issue #644：任务自带的输出目录可以指向默认导出根之外的位置（例如另一个盘），
/// 由 `PathManager` 统一做安全校验后加入允许的根集合；非法路径按越界拒绝。
fn resolve_scheduled_output_dir(
    path_manager: &PathManager,
    raw_output_dir: Option<&str>,
) -> Result<PathBuf, String> {
    let configured = raw_output_dir
        .map(str::trim)
        .filter(|s| !s.is_empty())
        .map(PathManager::sanitize_path)
        .filter(|s| !s.is_empty());
    let requested = configured
        .as_deref()
        .map_or_else(|| path_manager.scheduled_exports_dir(), PathBuf::from);
    let roots = path_manager.export_output_roots(configured.as_deref());
    resolve_for_creation_within(&requested, &roots)
        .ok_or_else(|| "定时导出目录不在允许的导出目录内".to_string())
}

#[cfg(test)]
mod tests {
    use super::{
        reserve_scheduled_file_name, resolve_for_creation_within, resolve_scheduled_output_dir,
        scheduled_export_file_name, PathBuf, PathManager,
    };
    use qce_server::paths::sanitize_task_name;

    #[test]
    fn scheduled_output_dir_accepts_configured_dirs_outside_default_roots() {
        let path_manager = PathManager::new();

        // 默认导出根在 Windows 上会被 canonicalize 成 \\?\ 前缀形式，期望值同步规范化。
        let default_dir = resolve_for_creation_within(
            &path_manager.scheduled_exports_dir(),
            &path_manager.export_output_roots(None),
        )
        .unwrap();
        assert_eq!(
            resolve_scheduled_output_dir(&path_manager, None).unwrap(),
            default_dir
        );
        assert_eq!(
            resolve_scheduled_output_dir(&path_manager, Some("   ")).unwrap(),
            default_dir
        );

        let custom = if cfg!(windows) {
            "D:\\stampBOT\\data"
        } else {
            "/data/stampbot"
        };
        // 自定义目录若已存在会被 canonicalize，统一按规范化结果比较。
        let custom_expected = resolve_for_creation_within(
            &PathBuf::from(custom),
            &path_manager.export_output_roots(Some(custom)),
        )
        .unwrap();
        assert_eq!(
            resolve_scheduled_output_dir(&path_manager, Some(custom)).unwrap(),
            custom_expected
        );
        // 引号包裹的粘贴路径同样可用。
        assert_eq!(
            resolve_scheduled_output_dir(&path_manager, Some(&format!("\"{custom}\""))).unwrap(),
            custom_expected
        );

        // 相对路径、系统关键目录与父目录穿越都不会成为允许的根。
        for rejected in ["relative/dir", "/etc/cron.d", "/data/../etc"] {
            assert!(resolve_scheduled_output_dir(&path_manager, Some(rejected)).is_err());
        }
    }

    #[test]
    fn scheduled_names_are_readable_safe_and_reserved_concurrently() {
        assert_eq!(sanitize_task_name("CON.", 40), "_CON");
        let file_name = scheduled_export_file_name(
            "friend",
            "笨蛋 Darf/v2",
            "1687657986",
            "20260713_002703456",
            "html",
        );
        assert_eq!(
            file_name,
            "friend_笨蛋_Darf_v2_1687657986_20260713_002703456.html"
        );

        let base = std::env::temp_dir().join(format!(
            "qce-scheduled-export-name-{}",
            uuid::Uuid::new_v4().simple()
        ));
        std::fs::create_dir_all(&base).unwrap();
        let (first, _first_reservation) = reserve_scheduled_file_name(&base, &file_name);
        let (second, _second_reservation) = reserve_scheduled_file_name(&base, &file_name);
        assert_eq!(first, file_name);
        assert_eq!(
            second,
            "friend_笨蛋_Darf_v2_1687657986_20260713_002703456_2.html"
        );
        std::fs::remove_dir_all(base).unwrap();
    }
}
