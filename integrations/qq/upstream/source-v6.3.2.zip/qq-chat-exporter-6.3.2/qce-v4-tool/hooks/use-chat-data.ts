import { useState, useCallback } from "react"
import type { Group, Friend, GroupsResponse, FriendsResponse, RecentContactsResponse } from "@/types/api"
import { useApi } from "./use-api"
import { buildSpecialFriends } from "@/lib/special-contacts"
import { dedupeFriends, dedupeGroups } from "@/lib/session-dedupe"

export interface AvatarExportResult {
  success: boolean
  groupCode: string
  groupName: string
  totalMembers: number
  successCount: number
  failCount: number
  fileName: string
  filePath: string
  fileSize: number
  downloadUrl: string
}

export function useChatData() {
  const [groups, setGroups] = useState<Group[]>([])
  const [friends, setFriends] = useState<Friend[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [loadProgress, setLoadProgress] = useState<{ current: number; total: number } | null>(null)
  const [avatarExportLoading, setAvatarExportLoading] = useState<string | null>(null)
  /**
   * Issue #344: peerUid (group.groupCode / friend.uid) → 最近一条消息 ISO 时间。
   * 从 `/api/recent-contacts` 与 `/api/groups` 返回的 `lastMsgTime` 合并而成，
   * 供会话列表「按最近活跃」排序 / 显示「N 天前」徽标。
   */
  const [recentActivityMap, setRecentActivityMap] = useState<Record<string, string>>({})
  const { apiCall } = useApi()

  // 自动分页加载所有群组
  const loadGroups = useCallback(async (page = 1, limit = 1000) => {
    try {
      setLoading(true)
      setError(null)

      const allGroups: Group[] = []
      let currentPage = page
      let hasMore = true

      while (hasMore) {
        const response = await apiCall<GroupsResponse>(`/api/groups?page=${currentPage}&limit=${limit}`)

        if (response.success && response.data) {
          const pageGroups = response.data.groups || []
          allGroups.push(...pageGroups)

          const totalCount = response.data.totalCount ?? allGroups.length
          setLoadProgress({ current: allGroups.length, total: totalCount })

          hasMore = response.data.hasNext === true

          if (hasMore) {
            currentPage++
            setGroups(dedupeGroups(allGroups))
          } else {
            break
          }
        } else {
          break
        }
      }

      // Issue #649：分页结果可能重复包含同一个群，去重后再进入 UI。
      setGroups(dedupeGroups(allGroups))
      setLoadProgress(null)
      console.log(`[QCE] 已加载 ${allGroups.length} 个群组`)

    } catch (err) {
      const errorMessage = `加载群组失败: ${err instanceof Error ? err.message : "未知错误"}`
      setError(errorMessage)
      console.error("[QCE] Groups load error:", err)
      setLoadProgress(null)
    } finally {
      setLoading(false)
    }
  }, [apiCall])

  // 自动分页加载所有好友
  const loadFriends = useCallback(async (page = 1, limit = 1000) => {
    try {
      setLoading(true)
      setError(null)

      const allFriends: Friend[] = []
      let currentPage = page
      let hasMore = true

      while (hasMore) {
        const response = await apiCall<FriendsResponse>(`/api/friends?page=${currentPage}&limit=${limit}`)

        if (response.success && response.data) {
          const pageFriends = response.data.friends || []
          allFriends.push(...pageFriends)

          const totalCount = response.data.totalCount ?? allFriends.length
          setLoadProgress({ current: allFriends.length, total: totalCount })

          hasMore = response.data.hasNext === true

          if (hasMore) {
            currentPage++
            setFriends(dedupeFriends(allFriends))
          } else {
            break
          }
        } else {
          break
        }
      }

      // Issue #364: 把最近联系人中既不在好友列表也不在群组列表的会话（QQ Bot、
      // 服务号、临时会话等）合并到 friends 数组里。这些会话保留原始 chatType，
      // 上层导出 / 定时任务在选中时会把 chatType 透传给后端，避免被强制归为
      // 普通好友（chatType=1）。失败时静默跳过，不影响普通好友加载。
      try {
        const recentResp = await apiCall<RecentContactsResponse>("/api/recent-contacts?limit=500&includeAll=true")
        if (recentResp.success && recentResp.data) {
          // Issue #344: 根据 peerUid 记下最近一条消息时间，供会话列表「按最近
          // 活跃」排序 以及小徽标显示。
          const activityMap: Record<string, string> = {}
          for (const c of recentResp.data.contacts) {
            if (c.peerUid && c.lastMsgTime) {
              activityMap[c.peerUid] = c.lastMsgTime
            }
          }
          setRecentActivityMap(activityMap)

          // Issue #649：同时用 uid 和 uin 判断是否已存在，避免同一会话被特殊会话
          // 合并逻辑再插一遍。
          const existingUids = new Set(
            allFriends.flatMap((f) => [f.uid, f.uin ? String(f.uin) : ""]).filter(Boolean),
          )
          const specialFriends = buildSpecialFriends(recentResp.data.contacts, existingUids)

          if (specialFriends.length > 0) {
            allFriends.push(...specialFriends)
            console.log(`[QCE] 合并 ${specialFriends.length} 个特殊会话（Bot / 服务号 / 临时会话 / 我的设备）`)
          }
        }
      } catch (recentErr) {
        console.warn("[QCE] 加载最近联系人失败，跳过特殊会话合并:", recentErr)
      }

      setFriends(dedupeFriends(allFriends))
      setLoadProgress(null)
      console.log(`[QCE] 已加载 ${allFriends.length} 个好友`)

    } catch (err) {
      const errorMessage = `加载好友失败: ${err instanceof Error ? err.message : "未知错误"}`
      setError(errorMessage)
      console.error("[QCE] Friends load error:", err)
      setLoadProgress(null)
    } finally {
      setLoading(false)
    }
  }, [apiCall])

  const loadAll = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      await Promise.all([loadGroups(), loadFriends()])
    } catch (err) {
      const errorMessage = `加载数据失败: ${err instanceof Error ? err.message : "未知错误"}`
      setError(errorMessage)
    } finally {
      setLoading(false)
    }
  }, [loadGroups, loadFriends])

  // 导出群成员头像
  const exportGroupAvatars = useCallback(async (groupCode: string): Promise<AvatarExportResult | null> => {
    try {
      setAvatarExportLoading(groupCode)
      setError(null)

      const response = await apiCall<AvatarExportResult>(`/api/groups/${groupCode}/avatars/export`, {
        method: 'POST'
      })

      if (response.success && response.data) {
        console.log(`[QCE] 群头像导出成功: ${response.data.fileName}`)
        return response.data
      } else {
        throw new Error(response.error?.message || '导出失败')
      }
    } catch (err) {
      const errorMessage = `导出群头像失败: ${err instanceof Error ? err.message : "未知错误"}`
      setError(errorMessage)
      console.error("[QCE] Avatar export error:", err)
      return null
    } finally {
      setAvatarExportLoading(null)
    }
  }, [apiCall])

  return {
    groups,
    friends,
    loading,
    error,
    loadProgress,
    loadGroups,
    loadFriends,
    loadAll,
    exportGroupAvatars,
    avatarExportLoading,
    recentActivityMap,
  }
}