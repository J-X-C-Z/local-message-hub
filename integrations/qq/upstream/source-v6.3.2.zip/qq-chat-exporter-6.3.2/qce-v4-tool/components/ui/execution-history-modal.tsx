"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  AlertCircle,
  RefreshCw,
  FileText,
  ChevronRight,
  HelpCircle
} from "lucide-react"
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Loader } from "@/components/ui/loader"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"
import type { ScheduledExportHistory } from "@/types/api"

interface ExecutionHistoryModalProps {
  isOpen: boolean
  onClose: () => void
  scheduledExportId: string
  taskName: string
  onGetHistory: (id: string, limit?: number) => Promise<ScheduledExportHistory[]>
}

export function ExecutionHistoryModal({ 
  isOpen, 
  onClose, 
  scheduledExportId, 
  taskName,
  onGetHistory 
}: ExecutionHistoryModalProps) {
  const [history, setHistory] = useState<ScheduledExportHistory[]>([])
  const [loading, setLoading] = useState(false)
  const [expandedId, setExpandedId] = useState<string | null>(null)

  useEffect(() => {
    if (isOpen && scheduledExportId) {
      loadHistory()
    }
  }, [isOpen, scheduledExportId])

  const loadHistory = async () => {
    setLoading(true)
    try {
      const historyData = await onGetHistory(scheduledExportId, 50)
      setHistory(historyData)
    } catch (error) {
      console.error('Failed to load execution history:', error)
      setHistory([])
    } finally {
      setLoading(false)
    }
  }

  const formatDuration = (ms: number) => {
    if (ms < 1000) return `${ms}ms`
    if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`
    return `${(ms / 60000).toFixed(1)}min`
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes}B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)}MB`
  }

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent
        fullScreen
        overlayClassName="bg-background/80 dark:bg-background/80"
        className="inset-4 w-auto h-auto rounded-[24px] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.14)] dark:shadow-[0_24px_80px_rgba(0,0,0,0.5)] overflow-hidden flex flex-col p-0"
      >
        <DialogTitle className="sr-only">执行历史</DialogTitle>

        <div className="flex-1 flex flex-col min-h-0 w-full max-w-[880px] mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between px-10 pt-12 pb-6 flex-shrink-0">
              <div>
                <h1 className="text-[20px] font-semibold text-foreground">执行历史</h1>
                <p className="text-[13px] text-muted-foreground mt-1.5">{taskName}</p>
              </div>
              <button
                onClick={loadHistory}
                disabled={loading}
                className="p-2 rounded-full text-muted-foreground/60 hover:text-muted-foreground hover:bg-black/[0.04] dark:hover:bg-white/[0.06] transition-colors disabled:opacity-50"
              >
                {loading ? <Loader size={16} /> : <RefreshCw className="w-4 h-4" />}
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto px-10 pb-4">
              {loading ? (
                <div className="flex items-center justify-center py-16">
                  <Loader size={24} className="text-muted-foreground/60" />
                </div>
              ) : history.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16">
                  <FileText className="w-10 h-10 text-muted-foreground/30 mb-3" />
                  <p className="text-muted-foreground">暂无执行记录</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {history.map((item) => (
                    <motion.div
                      key={item.id}
                      className="rounded-xl bg-muted/30 overflow-hidden"
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                    >
                      {/* Main Row */}
                      <button
                        className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-muted/50 transition-colors"
                        onClick={() => setExpandedId(expandedId === item.id ? null : item.id)}
                      >
                        {/* Status Indicator */}
                        <div className={`w-2 h-2 rounded-full flex-shrink-0 ${
                          item.status === 'success' ? 'bg-muted-foreground/60' :
                          item.status === 'failed' ? 'bg-foreground' :
                          'bg-muted-foreground/40'
                        }`} />
                        
                        {/* Info */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 text-sm">
                            <span className="text-foreground font-medium">
                              {new Date(item.executedAt).toLocaleDateString('zh-CN', {
                                month: 'numeric',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </span>
                            <span aria-hidden className="h-2.5 w-px bg-current opacity-20" />
                            <span className="text-muted-foreground">{formatDuration(item.duration)}</span>
                            {item.messageCount !== undefined && item.messageCount > 0 && (
                              <>
                                <span aria-hidden className="h-2.5 w-px bg-current opacity-20" />
                                <span className="text-muted-foreground">{item.messageCount.toLocaleString()} 条</span>
                              </>
                            )}
                          </div>
                        </div>

                        {/* Status Text */}
                        <div className="flex items-center gap-1.5">
                          <span className={`text-xs px-2 py-0.5 rounded-full ${
                            item.status === 'success' ? 'bg-black/[0.04] dark:bg-white/[0.06] text-muted-foreground' :
                            item.status === 'failed' ? 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400' :
                            'bg-black/[0.04] dark:bg-white/[0.06] text-muted-foreground'
                          }`}>
                            {item.status === 'success' ? '成功' : item.status === 'failed' ? '失败' : '部分'}
                          </span>
                          {item.status === 'partial' && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span aria-label="查看部分完成说明">
                                  <HelpCircle className="w-[14px] h-[14px] text-muted-foreground/60 hover:text-muted-foreground transition-colors outline-none cursor-pointer" />
                                </span>
                              </TooltipTrigger>
                              <TooltipContent side="top" sideOffset={6} className="max-w-[260px]">
                                {item.resourceSummary?.failed && item.resourceSummary.failed > 0
                                  ? `消息已全部导出，但有 ${item.resourceSummary.failed} 个图片、视频等资源下载失败，文字内容不受影响。`
                                  : '消息已全部导出，但有部分图片、视频等资源下载失败，文字内容不受影响。'}
                              </TooltipContent>
                            </Tooltip>
                          )}
                        </div>

                        <ChevronRight className={`w-4 h-4 text-muted-foreground/40 transition-transform ${
                          expandedId === item.id ? 'rotate-90' : ''
                        }`} />
                      </button>

                      {/* Expanded Details */}
                      <AnimatePresence>
                        {expandedId === item.id && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="overflow-hidden"
                          >
                            <div className="px-4 pb-3 pt-1 space-y-2 text-sm border-t border-black/[0.06] dark:border-white/[0.06]">
                              {item.fileSize && (
                                <div className="flex justify-between text-muted-foreground">
                                  <span>文件大小</span>
                                  <span>{formatFileSize(item.fileSize)}</span>
                                </div>
                              )}
                              {item.resourceSummary && item.resourceSummary.attempted > 0 && (
                                <div className="flex justify-between text-muted-foreground">
                                  <span>资源</span>
                                  <span>
                                    {item.resourceSummary.alreadyAvailable + item.resourceSummary.downloaded}/{item.resourceSummary.attempted}
                                    {item.resourceSummary.failed > 0 && `，失败 ${item.resourceSummary.failed}`}
                                    {item.resourceSummary.skipped > 0 && `，跳过 ${item.resourceSummary.skipped}`}
                                  </span>
                                </div>
                              )}
                              {item.filePath && (
                                <div className="text-muted-foreground">
                                  <span className="block mb-1">文件路径</span>
                                  <code className="block text-xs bg-muted px-2 py-1.5 rounded font-mono break-all select-all">
                                    {item.filePath}
                                  </code>
                                </div>
                              )}
                              {item.error && (
                                <div className="text-foreground/80 bg-muted px-3 py-2 rounded">
                                  <div className="flex items-start gap-2">
                                    <AlertCircle className="w-4 h-4 text-muted-foreground flex-shrink-0 mt-0.5" />
                                    <span className="break-all text-xs">{item.error}</span>
                                  </div>
                                </div>
                              )}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>

        </div>

        {/* Footer */}
        <div className="h-[72px] flex items-center justify-between px-10 flex-shrink-0">
          <span className="text-[13px] font-medium text-muted-foreground">
            共 {history.length} 条记录
          </span>
          <Button variant="outline" onClick={onClose} className="rounded-full text-[13px] h-8">
            关闭
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
