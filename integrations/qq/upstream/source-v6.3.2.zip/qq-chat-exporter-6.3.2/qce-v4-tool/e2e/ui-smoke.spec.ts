/**
 * UI smoke test - boots the auth page, drops a token and makes sure we land
 * on the main app shell. Skipped automatically when the frontend isn't
 * reachable so this can run in environments where only the API is up.
 *
 * To run these locally:
 *   1. `cd qce-v4-tool && pnpm build`
 *   2. `mkdir -p ../static && rm -rf ../static/qce && cp -r out ../static/qce`
 *   3. `cd ../plugins/qq-chat-exporter && pnpm mock:server`
 *   4. `cd ../../qce-v4-tool && E2E_FRONTEND_URL=http://localhost:40653 pnpm exec playwright test e2e/ui-smoke.spec.ts`
 *
 * The mock server serves the built frontend under `/qce/...` plus the
 * REST API on the same origin, which matches production routing far more
 * closely than `next dev` does.
 */

import { test, expect } from '@playwright/test';
import { isNewerVersion } from '../lib/version';

const TOKEN = process.env.QCE_MOCK_TOKEN ?? 'qce_mock_token_for_tests';
const FRONTEND_BASE = process.env.E2E_FRONTEND_URL ?? 'http://localhost:40653';
// Production URL has the frontend living under `/qce/`.
const BASE_PATH = process.env.QCE_E2E_BASE_PATH ?? '/qce';
const AUTH_PATH = `${BASE_PATH}/auth`;
const SHELL_PATH = BASE_PATH || '/';

async function clearLocalStorage(page: import('@playwright/test').Page) {
    // We can't use addInitScript here – that runs on EVERY navigation in the
    // page, so it would also wipe a token the auth flow just persisted.
    await page.goto(`${FRONTEND_BASE}${SHELL_PATH}`).catch(() => null);
    await page.evaluate(() => localStorage.clear()).catch(() => null);
}

test.describe('Auth flow', () => {

    test('home page loads', async ({ page }) => {
        const response = await page.goto(`${FRONTEND_BASE}${SHELL_PATH}`).catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );
        const title = await page.title();
        expect(title.length).toBeGreaterThan(0);
    });

    /**
     * Issue #287: the server prints a one-click login URL like
     * `…/qce/auth?token=<accessToken>`. The auth page should detect
     * that token, strip it from the URL bar (so history doesn't keep a copy),
     * verify it against the API, persist it to localStorage and forward the
     * user out of `/auth`.
     */
    test('one-click ?token=... strips the query string and persists the token', async ({ page }) => {
        await clearLocalStorage(page);
        const response = await page
            .goto(`${FRONTEND_BASE}${AUTH_PATH}?token=${TOKEN}`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        // `replaceState` should clear the `?token=` param before verification
        // resolves, so it never hangs around in browser history.
        await page.waitForFunction(() => !window.location.search.includes('token='), {
            timeout: 15_000
        });

        // Wait for the auth redirect to settle before reading storage so navigation does not replace the page context.
        await page.waitForURL(
            (url) => !url.pathname.endsWith('/auth') && !url.pathname.endsWith('/auth/'),
            { timeout: 15_000 }
        );

        const stored = await page.evaluate(() => localStorage.getItem('qce_access_token'));
        expect(stored).toBe(TOKEN);
    });

    /**
     * Bad URL token: mock API rejects, we fall back to the manual form so the
     * user can paste a fresh token from `security.json`. We must NOT redirect
     * and must NOT keep the bogus token in localStorage.
     */
    test('one-click flow falls back to manual form when token is rejected', async ({ page }) => {
        await clearLocalStorage(page);
        const response = await page
            .goto(`${FRONTEND_BASE}${AUTH_PATH}?token=definitely-wrong-token`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        // Query string still gets stripped immediately on mount.
        await page.waitForFunction(() => !window.location.search.includes('token='), {
            timeout: 15_000
        });

        // Wait for the verification round-trip to finish; the page should
        // settle on the manual form without a redirect.
        await page.waitForTimeout(1500);
        const stored = await page.evaluate(() => localStorage.getItem('qce_access_token'));
        expect(stored).toBeNull();
        expect(new URL(page.url()).pathname).toMatch(/\/auth\/?$/);
    });

    /**
     * Codex P2 on PR #401: even when the user is already authenticated, the
     * auth page must scrub `?token=` from the URL before redirecting.
     * Otherwise the token-bearing URL stays in history / address bar
     * navigation when the user hits "back".
     */
    test('already-authenticated visit still strips ?token= from history', async ({ page }) => {
        // Pre-seed a valid token so the auth page hits the
        // `authManager.isAuthenticated()` branch.
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
        }, TOKEN);

        const response = await page
            .goto(`${FRONTEND_BASE}${AUTH_PATH}?token=${TOKEN}`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        // The auth page's effect should run `replaceState` to strip the
        // ?token= query before kicking off the redirect.
        await page.waitForFunction(() => !window.location.search.includes('token='), {
            timeout: 15_000
        });

        // The URL the browser would record in history (after replaceState)
        // must no longer contain the token.
        expect(page.url()).not.toContain('token=');
    });
});

test.describe('Version updates', () => {
    test('compares prerelease and stable versions in release order', () => {
        expect(isNewerVersion('v6.0.0-beta.65', '6.0.0-beta.64')).toBe(true);
        expect(isNewerVersion('v6.0.0', '6.0.0-rc.2')).toBe(true);
        expect(isNewerVersion('v6.0.0-beta.66', '6.0.0')).toBe(false);
        expect(isNewerVersion('v6.0.1-beta.1', '6.0.0')).toBe(true);
        expect(isNewerVersion('latest', '6.0.0')).toBe(false);
    });

    test('shows a red help indicator and update entry for a newer release', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
        }, TOKEN);
        await page.route(
            'https://api.github.com/repos/shuakami/qq-chat-exporter/releases?**',
            async (route) => {
                await route.fulfill({
                    status: 200,
                    contentType: 'application/json',
                    body: JSON.stringify([{
                        tag_name: 'v6.0.0',
                        html_url: 'https://github.com/shuakami/qq-chat-exporter/releases/tag/v6.0.0',
                    }]),
                });
            }
        );

        const response = await page
            .goto(`${FRONTEND_BASE}${SHELL_PATH}`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        const helpButton = page.getByRole('button', { name: '帮助，有新版本 v6.0.0' });
        await expect(helpButton).toBeVisible({ timeout: 15_000 });
        const skipBtn = page.getByRole('button', { name: '跳过' }).first();
        if (await skipBtn.isVisible({ timeout: 1500 }).catch(() => false)) {
            await skipBtn.click();
        }
        await helpButton.click();
        await expect(page.getByText('发现新版本', { exact: true })).toBeVisible();
        await expect(page.getByText('v6.0.0', { exact: true })).toBeVisible();
        await expect(page.getByText('查看更新内容', { exact: true })).toBeVisible();
    });
});

/**
 * Issue #204: 在搜索框里直接输入一个 4-12 位的 QQ 号，如果好友 / 群 / 最近联系人
 * 都搜不到，会话列表的空态会渲染「按 QQ 号反查」卡片，调用
 * `/api/users/lookup?uin=...`。Mock 服务器特地放了一条 uin=77777 的「已注销好友」
 * 会话，让这条链路完整跑起来。
 */
/**
 * 把主页带到「会话」标签页，并等到会话搜索框出现。
 *
 * 主页默认会打开 onboarding 弹窗（"欢迎使用…"）和 overview tab，会盖住测试要点
 * 的搜索框。这里统一处理：先把欢迎弹窗扫掉，再点侧栏的「会话」按钮，最后等真正
 * 的会话搜索 input 出现。
 */
async function openSessionsTab(page: import('@playwright/test').Page) {
    // 欢迎弹窗里的「跳过」按钮可见就关掉；不在则跳过。
    const skipBtn = page.getByRole('button', { name: '跳过' }).first();
    if (await skipBtn.isVisible({ timeout: 1500 }).catch(() => false)) {
        await skipBtn.click().catch(() => null);
    }
    // 侧栏的「会话」按钮（id=sessions）。用 role+name 精准定位避免和概览里的
    // 「浏览会话」按钮混淆。
    const sessionsTab = page.getByRole('button', { name: '会话', exact: true });
    await expect(sessionsTab).toBeVisible({ timeout: 15_000 });
    await sessionsTab.click();

    const searchBox = page.locator('input[placeholder*="搜索会话"]').first();
    await expect(searchBox).toBeVisible({ timeout: 15_000 });
    return searchBox;
}

async function mockSessionSources(
    page: import('@playwright/test').Page,
    {
        groups = [],
        friends = [],
        contacts = [],
    }: {
        groups?: Array<Record<string, unknown>>;
        friends?: Array<Record<string, unknown>>;
        contacts?: Array<Record<string, unknown>>;
    } = {},
) {
    await page.route('**/api/groups?**', async (route) => {
        await route.fulfill({
            status: 200,
            contentType: 'application/json',
            body: JSON.stringify({
                success: true,
                data: {
                    groups,
                    totalCount: groups.length,
                    currentPage: 1,
                    totalPages: 1,
                    hasNext: false,
                    hasPrev: false,
                },
            }),
        });
    });
    await page.route('**/api/friends?**', async (route) => {
        await route.fulfill({
            status: 200,
            contentType: 'application/json',
            body: JSON.stringify({
                success: true,
                data: {
                    friends,
                    totalCount: friends.length,
                    currentPage: 1,
                    totalPages: 1,
                    hasNext: false,
                    hasPrev: false,
                },
            }),
        });
    });
    await page.route('**/api/recent-contacts?**', async (route) => {
        await route.fulfill({
            status: 200,
            contentType: 'application/json',
            body: JSON.stringify({
                success: true,
                data: {
                    contacts,
                    totalCount: contacts.length,
                    rawCount: contacts.length,
                },
            }),
        });
    });
}

test.describe('Session list — batch toolbar and pagination', () => {
    test('keeps the selected sessions while pagination remains visible and clickable', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
        }, TOKEN);

        const groups = Array.from({ length: 313 }, (_, index) => ({
            groupCode: String(900000000 + index),
            groupName: `分页测试群 ${String(index + 1).padStart(3, '0')}`,
            memberCount: 10 + index,
            maxMember: 2000,
        }));

        await page.route('**/auth', async (route) => {
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify({ success: true }),
            });
        });
        await page.route('**/api/**', async (route) => {
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify({ success: true, data: {} }),
            });
        });
        await page.route('**/api/tasks**', async (route) => {
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify({ success: true, data: { tasks: [] } }),
            });
        });

        await page.route('**/api/system/info**', async (route) => {
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify({
                    success: true,
                    data: {
                        name: 'QQ Chat Exporter',
                        version: '5.5.80',
                        mode: 'plugin',
                        napcat: {
                            version: 'mock',
                            online: true,
                            selfInfo: { uid: 'mock-user', uin: '10001', nick: '分页测试账号' },
                        },
                        runtime: { nodeVersion: 'mock', platform: 'win32', uptime: 1 },
                    },
                }),
            });
        });

        await page.route('**/api/security/ip-whitelist**', async (route) => {
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify({
                    success: true,
                    data: { allowedIPs: ['127.0.0.1'], disabled: false, isDocker: false, currentClientIP: '127.0.0.1' },
                }),
            });
        });

        await page.route('**/api/groups?**', async (route) => {
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify({
                    success: true,
                    data: {
                        groups,
                        totalCount: groups.length,
                        currentPage: 1,
                        totalPages: 1,
                        hasNext: false,
                        hasPrev: false,
                    },
                }),
            });
        });
        await page.route('**/api/friends?**', async (route) => {
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify({
                    success: true,
                    data: { friends: [], totalCount: 0, currentPage: 1, totalPages: 1, hasNext: false, hasPrev: false },
                }),
            });
        });
        await page.route('**/api/recent-contacts?**', async (route) => {
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify({ success: true, data: { contacts: [] } }),
            });
        });
        const response = await page.goto(`${FRONTEND_BASE}${SHELL_PATH}`).catch(() => null);
        test.skip(!response || response.status() >= 500, `frontend not reachable at ${FRONTEND_BASE}`);

        await openSessionsTab(page);
        await expect(page.getByText('分页测试群 001', { exact: true })).toBeVisible({ timeout: 15_000 });

        const batchButton = page.getByRole('button', { name: '批量选择', exact: true }).filter({ visible: true }).first();
        await batchButton.click();
        await page.getByRole('checkbox', { name: '选择会话 分页测试群 001' }).click();

        const toolbar = page.getByTestId('batch-selection-toolbar');
        const pagination = page.getByTestId('session-pagination');
        await expect(toolbar).toContainText('已选择 1 项');
        await pagination.scrollIntoViewIfNeeded();

        const [toolbarBox, paginationBox] = await Promise.all([
            toolbar.boundingBox(),
            pagination.boundingBox(),
        ]);
        expect(toolbarBox).not.toBeNull();
        expect(paginationBox).not.toBeNull();
        expect(toolbarBox!.y + toolbarBox!.height).toBeLessThanOrEqual(paginationBox!.y);

        await page.getByRole('button', { name: '下一页' }).click();
        await expect(pagination).toContainText(/2\s*\/\s*7/);
        await expect(toolbar).toContainText('已选择 1 项');
    });
});

test.describe('Session list — QQ lookup (issue #204)', () => {
    test('regular private sessions expose roaming export in the export menu', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
            localStorage.setItem(
                'qce.taskWizard.advancedPreferences.v1',
                JSON.stringify({ streamingZipMode: true }),
            );
        }, TOKEN);

        const response = await page
            .goto(`${FRONTEND_BASE}${SHELL_PATH}`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        const searchBox = await openSessionsTab(page);
        await searchBox.fill('Alice');

        const moreExportMethods = page.getByRole('button', {
            name: /更多导出方式：Alice/,
        });
        await expect(moreExportMethods).toBeVisible({ timeout: 10_000 });
        await moreExportMethods.click();
        await page.getByRole('menuitem', { name: '漫游导出', exact: true }).click();

        await expect(page.getByTestId('roaming-export-notice')).toBeVisible();
        const startRoamingExport = page.getByRole('button', { name: '开始漫游导出', exact: true });
        await expect(startRoamingExport).toBeEnabled();

        const rangeHelp = page.getByRole('button', { name: '查看漫游日期范围说明' });
        await rangeHelp.hover();
        await expect(page.getByRole('tooltip')).toContainText('开始和结束日期均为必填');
        await expect(page.getByRole('tooltip')).not.toContainText('全部消息');

        const rangeButton = page.getByRole('button', {
            name: /\d{4}\/\d{2}\/\d{2}\s*-\s*\d{4}\/\d{2}\/\d{2}/,
        });
        await rangeButton.click();
        await page.getByRole('button', { name: '清除', exact: true }).click();
        await page.getByRole('button', { name: '应用', exact: true }).click();
        await expect(page.getByRole('button', { name: '选择漫游日期范围（必填）' })).toBeVisible();
        await expect(page.getByText('漫游导出必须选择开始和结束时间', { exact: true }).first()).toBeVisible();
        await expect(startRoamingExport).toBeDisabled();

        await page.waitForTimeout(350); // allow the preferences debounce to run
        await page.getByRole('button', { name: '取消', exact: true }).click();
        const streamingPreference = await page.evaluate(() => {
            const raw = localStorage.getItem('qce.taskWizard.advancedPreferences.v1');
            return raw ? JSON.parse(raw).streamingZipMode : undefined;
        });
        expect(streamingPreference).toBe(true);
    });

    test('a non-friend recent private session still exposes roaming export', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
        }, TOKEN);
        await mockSessionSources(page, {
            contacts: [{
                chatType: 1,
                peerUid: 'u_removed_private_fixture',
                peerUin: '24680',
                name: '已删除联系人',
                classification: 'special',
            }],
        });

        const response = await page
            .goto(`${FRONTEND_BASE}${SHELL_PATH}`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        const searchBox = await openSessionsTab(page);
        await searchBox.fill('24680');
        await expect(page.getByText('已删除联系人', { exact: true })).toBeVisible({ timeout: 10_000 });
        await expect(page.getByText('按 QQ 号反查会话')).toHaveCount(0);

        const moreExportMethods = page.getByRole('button', {
            name: '更多导出方式：已删除联系人',
        });
        await expect(moreExportMethods).toBeVisible();
        await moreExportMethods.click();
        await page.getByRole('menuitem', { name: '漫游导出', exact: true }).click();
        await expect(page.getByTestId('roaming-export-notice')).toBeVisible();
    });

    test('an empty session list still exposes QQ lookup', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
        }, TOKEN);
        await mockSessionSources(page);

        const response = await page
            .goto(`${FRONTEND_BASE}${SHELL_PATH}`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        const searchBox = await openSessionsTab(page);
        await searchBox.fill('24680');
        await expect(page.getByText('暂无会话数据', { exact: true })).toBeVisible();
        await expect(page.getByText('按 QQ 号反查会话')).toBeVisible({ timeout: 10_000 });
        await expect(page.getByRole('button', { name: /查询/ })).toBeVisible();
    });

    test('a substring session match does not hide exact QQ lookup', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
        }, TOKEN);
        await mockSessionSources(page, {
            friends: [{
                uid: 'u_substring_match_fixture',
                uin: 124680,
                nick: '联系人 24680 备注',
                chatType: 1,
            }],
        });

        const response = await page
            .goto(`${FRONTEND_BASE}${SHELL_PATH}`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        const searchBox = await openSessionsTab(page);
        await searchBox.fill('24680');
        await expect(page.getByText('联系人 24680 备注', { exact: true })).toBeVisible();
        await expect(page.getByText('按 QQ 号反查会话')).toBeVisible({ timeout: 10_000 });
    });

    test('searching by deactivated QQ number reveals the lookup card', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
        }, TOKEN);

        const response = await page
            .goto(`${FRONTEND_BASE}${SHELL_PATH}`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        const searchBox = await openSessionsTab(page);

        // 输入一个 fixture 里没有任何文字 / id 命中、但 mock 后端能反查到的 uin。
        await searchBox.fill('77777');

        // 空态里应该出现 lookup 卡片标题。
        await expect(page.getByText('按 QQ 号反查会话')).toBeVisible({ timeout: 10_000 });

        // 卡片里有自己的输入框（已经被 initialUin 填上），点查询按钮触发后端调用。
        await page.getByRole('button', { name: /查询/ }).click();

        // 反查到 u_deactivated_77777，按钮区出现「导出」、徽章里写「非好友 / 已注销」。
        await expect(page.getByText('非好友 / 已注销')).toBeVisible({ timeout: 10_000 });

        // 卡片在主搜索从一个无结果号码切到另一个时仍保持挂载；输入值和旧结果
        // 必须一起更新，避免用户看到新搜索词却误导出旧会话。
        const lookupInput = page.locator('input[placeholder^="QQ 号"]').first();
        await expect(lookupInput).toHaveValue('77777');
        await lookupInput.fill('77778');
        await expect(page.getByText('非好友 / 已注销')).toHaveCount(0);
        await expect(page.getByRole('button', { name: '漫游导出', exact: true })).toHaveCount(0);

        await searchBox.fill('88888888');
        await expect(lookupInput).toHaveValue('88888888');
        await expect(page.getByText('非好友 / 已注销')).toHaveCount(0);
        await expect(page.getByRole('button', { name: '漫游导出', exact: true })).toHaveCount(0);
    });

    test('resolved QQ session can start a bounded roaming export', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
        }, TOKEN);

        type RoamingExportRequest = {
            peer?: {
                chatType?: unknown;
                peerUid?: unknown;
                peerUin?: unknown;
                guildId?: unknown;
            };
            filter?: {
                startTime?: unknown;
                endTime?: unknown;
            };
            roaming?: {
                maxMessages?: unknown;
                maxSequenceQueries?: unknown;
            };
        };

        let resolveExportRequest!: (body: RoamingExportRequest) => void;
        let taskCreated = false;
        const exportRequest = new Promise<RoamingExportRequest>((resolve) => {
            resolveExportRequest = resolve;
        });

        await page.route('**/api/tasks', async (route, request) => {
            if (request.method() !== 'GET') {
                await route.continue();
                return;
            }
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify({
                    success: true,
                    data: {
                        tasks: taskCreated ? [{
                            id: 'roaming-export-fixture-task',
                            peer: { chatType: 1, peerUid: 'u_deactivated_77777', peerUin: '77777', guildId: '' },
                            sessionName: '已注销联系人',
                            status: 'completed',
                            progress: 100,
                            format: 'JSON',
                            startTime: 1_753_987_200,
                            endTime: 1_756_665_599,
                            messageCount: 0,
                            createdAt: '2025-08-01T00:00:00.000Z',
                            completedAt: '2025-08-01T00:05:00.000Z',
                            taskKind: 'roaming_export',
                            roamingScan: {
                                bounded: true,
                                calendarAdvisory: true,
                                requestedDays: 31,
                                probedDays: 32,
                                scannedDays: 31,
                                calendarQueries: 1,
                                anchorDays: 0,
                                exactQueries: 0,
                                latestQueries: 1,
                                sequenceQueries: 0,
                                emptySequenceQueries: 0,
                                gapCount: 1,
                                mismatchedAnchors: 0,
                                unresolvedAnchors: 0,
                                untimestampedMessages: 0,
                                rawMessagesSeen: 0,
                                messageCount: 0,
                                maxMessages: 50_000,
                                maxSequenceQueries: 50_000,
                                closingAnchorFound: false,
                                partial: true,
                                stopReason: 'closing_anchor_not_found',
                                currentDate: null,
                                serverCompletenessProven: false,
                            },
                        }] : [],
                    },
                }),
            });
        });

        await page.route('**/api/messages/roaming/export', async (route, request) => {
            if (request.method() !== 'POST') {
                await route.continue();
                return;
            }

            resolveExportRequest(request.postDataJSON() as RoamingExportRequest);
            taskCreated = true;
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify({
                    success: true,
                    data: { taskId: 'roaming-export-fixture-task' },
                }),
            });
        });

        const response = await page
            .goto(`${FRONTEND_BASE}${SHELL_PATH}`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        const searchBox = await openSessionsTab(page);
        await searchBox.fill('77777');
        await expect(page.getByText('按 QQ 号反查会话')).toBeVisible({ timeout: 10_000 });
        await page.getByRole('button', { name: /查询/ }).click();
        await expect(page.getByText('非好友 / 已注销')).toBeVisible({ timeout: 10_000 });

        await page.getByRole('button', { name: '漫游导出', exact: true }).click();

        const notice = page.getByTestId('roaming-export-notice');
        await expect(notice).toBeVisible();
        await expect(notice).toContainText('实验性私聊漫游导出');
        await expect(page.getByText('漫游日期范围（必填）', { exact: true })).toBeVisible();
        await expect(page.getByRole('button', {
            name: /\d{4}\/\d{2}\/\d{2}\s*-\s*\d{4}\/\d{2}\/\d{2}/,
        })).toBeVisible();

        const startExport = page.getByRole('button', { name: '开始漫游导出', exact: true });
        await expect(startExport).toBeEnabled();
        await startExport.click();

        const body = await exportRequest;
        expect(body.peer).toEqual({
            chatType: 1,
            peerUid: 'u_deactivated_77777',
            peerUin: '77777',
            guildId: '',
        });

        const startTime = body.filter?.startTime;
        const endTime = body.filter?.endTime;
        expect(typeof startTime).toBe('number');
        expect(typeof endTime).toBe('number');
        if (typeof startTime !== 'number' || typeof endTime !== 'number') {
            throw new Error('roaming export dates must be Unix timestamps');
        }
        expect(Number.isInteger(startTime)).toBe(true);
        expect(Number.isInteger(endTime)).toBe(true);
        expect(startTime).toBeGreaterThan(0);
        expect(endTime).toBeGreaterThan(0);
        expect(startTime).toBeLessThanOrEqual(endTime);
        expect(endTime).toBeLessThan(10_000_000_000);
        expect(body.roaming).toEqual({
            maxMessages: 50_000,
            maxSequenceQueries: 50_000,
        });

        // Refresh the task list to emulate the terminal state arriving after
        // creation. A bounded partial result must not look like a fully complete
        // export, and zero recovered messages must be explicit.
        await page.getByRole('button', { name: '任务', exact: true }).click();
        await page.locator('button:has(svg.lucide-refresh-cw)').filter({ visible: true }).first().click();
        await expect(page.getByText('0 条消息', { exact: true })).toBeVisible({ timeout: 10_000 });
        await expect(page.getByText('导出完成（结果可能不完整）', { exact: true })).toBeVisible();
        await expect(page.getByText(/漫游扫描已完成，但结果可能不完整/)).toBeVisible();
    });

    /**
     * Issue #363: 当本次导出有资源下载失败时，资源统计和 Rkey 降级说明
     * 都收进消息数旁的帮助 tooltip，不额外占用任务卡片空间。
     */
    test('completed task with failed resources shows summary details only in the tooltip (issue #363)', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
        }, TOKEN);

        // 拦截 /api/tasks，让前端看到一条 issue #363 场景的完成任务。
        await page.route('**/api/tasks', async (route, request) => {
            // 只拦 GET，POST 走真接口（不影响其它流程）。
            if (request.method() !== 'GET') {
                await route.continue();
                return;
            }
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify({
                    success: true,
                    data: {
                        tasks: [
                            {
                                id: 'rkey-fallback-task',
                                peer: { peerUid: '12345', chatType: 1 },
                                sessionName: 'Rkey 降级测试会话',
                                status: 'completed',
                                progress: 100,
                                format: 'HTML',
                                messageCount: 200,
                                fileName: 'rkey_test.html',
                                filePath: '/tmp/rkey_test.html',
                                fileSize: 12345,
                                createdAt: new Date(Date.now() - 3 * 60 * 1000).toISOString(),
                                completedAt: new Date(Date.now() - 1 * 60 * 1000).toISOString(),
                                resourceSummary: {
                                    attempted: 12,
                                    alreadyAvailable: 3,
                                    downloaded: 5,
                                    failed: 4,
                                    skipped: 0,
                                    failedSamples: ['photo-1.jpg', 'photo-2.jpg', 'photo-3.jpg', 'photo-4.jpg'],
                                },
                            },
                        ],
                    },
                }),
            });
        });

        const response = await page
            .goto(`${FRONTEND_BASE}${SHELL_PATH}`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        // 关掉欢迎弹窗（如有），切到任务标签页。
        const skipBtn = page.getByRole('button', { name: '跳过' }).first();
        if (await skipBtn.isVisible({ timeout: 1500 }).catch(() => false)) {
            await skipBtn.click().catch(() => null);
        }

        const tasksTab = page.getByRole('button', { name: '任务', exact: true });
        await expect(tasksTab).toBeVisible({ timeout: 15_000 });
        await tasksTab.click();

        // 任务行出现
        await expect(page.getByText('Rkey 降级测试会话')).toBeVisible({ timeout: 10_000 });
        await expect(page.getByText(/资源 8\/12，失败 4/)).toHaveCount(0);
        await expect(page.getByText(/Rkey 服务临时降级|重新打开相关消息/)).toHaveCount(0);
        const resourceHelp = page.getByRole('button', { name: '查看资源下载统计' });
        await expect(resourceHelp).toBeVisible();
        await resourceHelp.hover();
        const tooltip = page.getByRole('tooltip');
        await expect(tooltip).toContainText('资源 8/12，失败 4');
        await expect(tooltip).toContainText('QQ Rkey 服务临时不可用');
        const textWrap = await tooltip.evaluate((element) => getComputedStyle(element).textWrap);
        expect(textWrap).not.toContain('balance');
    });

    test('searching for a non-existent QQ shows a friendly not-found message', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
        }, TOKEN);

        const response = await page
            .goto(`${FRONTEND_BASE}${SHELL_PATH}`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        const searchBox = await openSessionsTab(page);
        await searchBox.fill('88888888');

        await expect(page.getByText('按 QQ 号反查会话')).toBeVisible({ timeout: 10_000 });
        await page.getByRole('button', { name: /查询/ }).click();

        // mock 的 getUidByUinV2 对未登记 uin 返 undefined，落到 found=false。
        await expect(page.getByText(/未在本机 NTQQ 数据中找到/)).toBeVisible({ timeout: 10_000 });
    });
});

test.describe('Queued export tasks', () => {
    test('queued task is active, cancellable, and not deletable before cancellation', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
        }, TOKEN);

        const queuedTask = {
            id: 'queued-fixture-task',
            peer: { chatType: 1, peerUid: 'u_queued_fixture', guildId: '' },
            sessionName: '排队测试会话',
            status: 'queued',
            progress: 0,
            progressMessage: '正在排队中...',
            format: 'JSON',
            messageCount: 0,
            createdAt: '2026-09-02T00:00:00.000Z',
        };
        let cancelRequested = false;

        await page.route('**/api/tasks', async (route, request) => {
            if (request.method() !== 'GET') {
                await route.continue();
                return;
            }
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify({
                    success: true,
                    data: { tasks: [queuedTask], totalCount: 1 },
                }),
            });
        });
        await page.route('**/api/tasks/queued-fixture-task/cancel', async (route) => {
            cancelRequested = true;
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify({
                    success: true,
                    data: {
                        ...queuedTask,
                        status: 'cancelled',
                        progressMessage: '任务已停止',
                        completedAt: '2026-09-02T00:00:01.000Z',
                    },
                }),
            });
        });

        const response = await page.goto(`${FRONTEND_BASE}${SHELL_PATH}`).catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        const skipBtn = page.getByRole('button', { name: '跳过' }).first();
        if (await skipBtn.isVisible({ timeout: 1500 }).catch(() => false)) {
            await skipBtn.click().catch(() => null);
        }
        await page.getByRole('button', { name: '任务', exact: true }).click();

        const taskRow = page.getByText('排队测试会话', { exact: true }).locator('xpath=../../..');
        await expect(taskRow.getByText('排队中', { exact: true })).toBeVisible({ timeout: 10_000 });
        await expect(taskRow.getByText('正在排队中...', { exact: true })).toBeVisible();
        await expect(taskRow.getByTitle('停止')).toBeVisible();
        await expect(taskRow.getByTitle('删除')).toHaveCount(0);

        await taskRow.getByTitle('停止').click();
        await page.getByRole('button', { name: '确认删除', exact: true }).click();
        await expect.poll(() => cancelRequested).toBe(true);
        await expect(taskRow.getByText('已停止', { exact: true })).toBeVisible();
        await expect(taskRow.getByTitle('停止')).toHaveCount(0);
        await expect(taskRow.getByTitle('删除')).toBeVisible();
    });
});

test.describe('Roaming export tasks', () => {
    test('task list shows bounded scan progress and completeness disclaimer', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
        }, TOKEN);

        let resolveDownloadRequest!: (request: import('@playwright/test').Request) => void;
        const downloadRequest = new Promise<import('@playwright/test').Request>((resolve) => {
            resolveDownloadRequest = resolve;
        });
        let resolveOpenRequest!: (request: import('@playwright/test').Request) => void;
        const openRequest = new Promise<import('@playwright/test').Request>((resolve) => {
            resolveOpenRequest = resolve;
        });
        await page.route('**/api/download-file?**', async (route, request) => {
            resolveDownloadRequest(request);
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: '{}',
            });
        });
        await page.route('**/api/open-file-location', async (route, request) => {
            resolveOpenRequest(request);
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify({ success: true, data: { message: '已打开文件位置' } }),
            });
        });

        await page.route('**/api/tasks', async (route, request) => {
            if (request.method() !== 'GET') {
                await route.continue();
                return;
            }
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify({
                    success: true,
                    data: {
                        tasks: [
                            {
                                id: 'roaming-fixture-task',
                                peer: { chatType: 1, peerUid: 'u_roaming_fixture', guildId: '' },
                                sessionName: '漫游测试会话',
                                status: 'completed',
                                progress: 100,
                                format: 'JSON',
                                startTime: 1_753_987_200,
                                endTime: 1_756_665_599,
                                messageCount: 42,
                                fileName: 'roaming_fixture.json',
                                filePath: '/tmp/roaming_fixture.json',
                                downloadUrl: '/api/download-file?path=%2Ftmp%2Froaming_fixture.json',
                                createdAt: '2025-08-01T00:00:00.000Z',
                                completedAt: '2025-08-01T00:05:00.000Z',
                                taskKind: 'roaming_export',
                                roamingScan: {
                                    bounded: true,
                                    calendarAdvisory: true,
                                    requestedDays: 31,
                                    probedDays: 32,
                                    scannedDays: 31,
                                    calendarQueries: 1,
                                    anchorDays: 7,
                                    exactQueries: 7,
                                    latestQueries: 1,
                                    sequenceQueries: 4,
                                    emptySequenceQueries: 1,
                                    gapCount: 1,
                                    mismatchedAnchors: 0,
                                    unresolvedAnchors: 0,
                                    untimestampedMessages: 0,
                                    rawMessagesSeen: 45,
                                    messageCount: 42,
                                    maxMessages: 50_000,
                                    maxSequenceQueries: 128,
                                    closingAnchorFound: true,
                                    partial: true,
                                    stopReason: 'sequence_gaps_encountered',
                                    currentDate: null,
                                    serverCompletenessProven: false,
                                },
                            },
                        ],
                    },
                }),
            });
        });

        const response = await page
            .goto(`${FRONTEND_BASE}${SHELL_PATH}`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        const skipBtn = page.getByRole('button', { name: '跳过' }).first();
        if (await skipBtn.isVisible({ timeout: 1500 }).catch(() => false)) {
            await skipBtn.click().catch(() => null);
        }

        // The overview offers direct download/open actions, so it must expose
        // the same completeness warning before the user enters task details.
        await expect(page.getByText('漫游测试会话', { exact: true })).toBeVisible({ timeout: 10_000 });
        await expect(page.getByText('漫游', { exact: true })).toBeVisible();
        await expect(page.getByText('结果可能不完整', { exact: true })).toBeVisible();

        const tasksTab = page.getByRole('button', { name: '任务', exact: true });
        await expect(tasksTab).toBeVisible({ timeout: 15_000 });
        await tasksTab.click();

        await expect(page.getByText('漫游测试会话', { exact: true })).toBeVisible({ timeout: 10_000 });
        await expect(page.getByText('漫游', { exact: true })).toBeVisible();
        await expect(page.getByText('结果可能不完整', { exact: true })).toBeVisible();
        await expect(page.getByText('已扫描 31/31 天', { exact: true })).toBeVisible();

        const scanHelp = page.getByRole('button', { name: '查看漫游扫描说明' });
        await expect(scanHelp).toBeVisible();
        await scanHelp.hover();
        const tooltip = page.getByRole('tooltip');
        await expect(tooltip).toContainText('日期锚点 7 个，逐序号核对 4 次');
        await expect(tooltip).toContainText('其中 1 个序号没有可读取消息，扫描已继续。');
        await expect(tooltip).toContainText('腾讯接口不会证明服务端记录完整');

        await page.getByRole('button', { name: '下载', exact: true }).click();
        const request = await downloadRequest;
        expect(new URL(request.url()).pathname).toBe('/api/download-file');
        expect(request.headers().authorization).toBe(`Bearer ${TOKEN}`);
        expect(request.headers()['x-access-token']).toBe(TOKEN);

        await page.getByRole('button', { name: '打开文件位置', exact: true }).click();
        const openLocationRequest = await openRequest;
        expect(openLocationRequest.headers().authorization).toBe(`Bearer ${TOKEN}`);
        expect(openLocationRequest.headers()['x-access-token']).toBe(TOKEN);
        expect(openLocationRequest.postDataJSON()).toEqual({ filePath: '/tmp/roaming_fixture.json' });
    });
});

test.describe('Sticker exports', () => {
    test('exporting keeps the loaded sticker list visible', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
        }, TOKEN);

        let releaseExport!: () => void;
        const exportGate = new Promise<void>((resolve) => {
            releaseExport = resolve;
        });
        let markExportStarted!: () => void;
        const exportStarted = new Promise<void>((resolve) => {
            markExportStarted = resolve;
        });

        await page.route('**/api/sticker-packs**', async (route, request) => {
            const url = new URL(request.url());
            if (request.method() === 'GET' && url.pathname.endsWith('/export-records')) {
                await route.fulfill({
                    status: 200,
                    contentType: 'application/json',
                    body: JSON.stringify({
                        success: true,
                        data: { records: [], totalCount: 0 },
                    }),
                });
                return;
            }
            if (request.method() === 'GET') {
                await route.fulfill({
                    status: 200,
                    contentType: 'application/json',
                    body: JSON.stringify({
                        success: true,
                        data: {
                            packs: [{
                                packId: 'regression-pack',
                                packName: '回归测试表情包',
                                packType: 'favorite_emoji',
                                stickerCount: 1,
                                stickers: [],
                            }],
                            stats: {
                                favorite_emoji: 1,
                                market_pack: 0,
                                system_pack: 0,
                            },
                            totalCount: 1,
                            totalStickers: 1,
                        },
                    }),
                });
                return;
            }
            if (request.method() === 'POST' && url.pathname.endsWith('/export')) {
                markExportStarted();
                await exportGate;
                await route.fulfill({
                    status: 200,
                    contentType: 'application/json',
                    body: JSON.stringify({
                        success: true,
                        data: {
                            success: true,
                            packCount: 1,
                            stickerCount: 1,
                            exportPath: '/tmp/sticker-export',
                        },
                    }),
                });
                return;
            }
            await route.continue();
        });

        const response = await page
            .goto(`${FRONTEND_BASE}/qce/stickers`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        const packName = page.getByText('回归测试表情包', { exact: true });
        await expect(packName).toBeVisible({ timeout: 15_000 });
        const skipBtn = page.getByRole('button', { name: '跳过' }).first();
        if (await skipBtn.isVisible({ timeout: 1500 }).catch(() => false)) {
            await skipBtn.click();
        }
        const packRow = packName.locator('xpath=ancestor::div[contains(@class,"group")]');
        await packRow.hover();
        await packRow.getByRole('button', { name: '导出', exact: true }).click();
        await exportStarted;

        await expect(packName).toBeVisible();
        await expect(page.getByText('正在加载表情包...')).toBeHidden();

        releaseExport();
        await expect(page.getByText('表情包“回归测试表情包”已导出')).toBeVisible({
            timeout: 15_000,
        });
    });
});

/**
 * Issue #346: 网络抽风 / 中间代理篡改时，POST /auth 可能短暂返回 5xx 或被
 * 改写成 success=false。老 AuthProvider 只要 success 不为 truthy 就清掉本地
 * token + 跳回 /auth，把已经登录的用户踢出。新版只有 401 / 403 才会清 token，
 * 其它一律放行。这里通过 page.route 模拟两种场景：
 *   1. POST /auth 返回 502 → 用户保留 token，停留在主界面
 *   2. POST /auth 返回 200 + `{ success: false }` 但状态码不是 401/403 → 同上
 */
test.describe('Auth validation resilience (issue #346)', () => {
    test('transient 502 on /auth keeps the user inside the app', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
        }, TOKEN);

        // 用 page.route 拦 POST /auth，在第一次校验请求上返回 502；后续别的
        // /auth 流程都走真接口。
        let blocked = false;
        await page.route('**/auth', async (route, request) => {
            if (!blocked && request.method() === 'POST') {
                blocked = true;
                await route.fulfill({
                    status: 502,
                    contentType: 'text/html',
                    body: '<html><body>Bad Gateway</body></html>',
                });
                return;
            }
            await route.continue();
        });

        const response = await page
            .goto(`${FRONTEND_BASE}${SHELL_PATH}`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        // 等到 AuthProvider 走完 / 渲染主界面：侧栏一定有「会话」入口。
        await expect(page.getByRole('button', { name: '会话', exact: true }))
            .toBeVisible({ timeout: 15_000 });

        // 用户没有被踢回 /auth。
        expect(new URL(page.url()).pathname).not.toMatch(/\/auth\/?$/);

        // localStorage 里的 token 也没被清掉。
        const stored = await page.evaluate(() => localStorage.getItem('qce_access_token'));
        expect(stored).toBe(TOKEN);
    });

    test('non-401/403 with success:false body still keeps the user inside the app', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
        }, TOKEN);

        let blocked = false;
        await page.route('**/auth', async (route, request) => {
            if (!blocked && request.method() === 'POST') {
                blocked = true;
                await route.fulfill({
                    status: 200,
                    contentType: 'application/json',
                    body: JSON.stringify({
                        success: false,
                        error: { type: 'PROXY_TAMPERING', message: 'reverse proxy ate the body' },
                    }),
                });
                return;
            }
            await route.continue();
        });

        const response = await page
            .goto(`${FRONTEND_BASE}${SHELL_PATH}`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        await expect(page.getByRole('button', { name: '会话', exact: true }))
            .toBeVisible({ timeout: 15_000 });
        expect(new URL(page.url()).pathname).not.toMatch(/\/auth\/?$/);
        const stored = await page.evaluate(() => localStorage.getItem('qce_access_token'));
        expect(stored).toBe(TOKEN);
    });

    test('explicit 403 still clears token and redirects to /auth', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
        }, TOKEN);

        await page.route('**/auth', async (route, request) => {
            if (request.method() === 'POST') {
                await route.fulfill({
                    status: 403,
                    contentType: 'application/json',
                    body: JSON.stringify({
                        success: false,
                        error: { type: 'AUTH_ERROR', message: 'invalid token', context: { code: 'INVALID_TOKEN' } },
                    }),
                });
                return;
            }
            await route.continue();
        });

        const response = await page
            .goto(`${FRONTEND_BASE}${SHELL_PATH}`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        // 真 token 失效，前端应当踢回 /auth 并清掉 localStorage。
        await page.waitForURL(/\/auth\/?$/, { timeout: 15_000 });
        const stored = await page.evaluate(() => localStorage.getItem('qce_access_token'));
        expect(stored).toBeNull();
    });
});

/**
 * Issue #340: 独立模式（start-standalone.bat）下没有 NapCat / QQ 登录态。
 * 老版本进入 sessions 标签页会立刻发起 /api/friends + /api/groups，两个端点
 * 都回 503 STANDALONE_MODE，前端在右上角连弹两次红色 toast，且 SessionList
 * 卡在「加载中」。这里通过路由拦截把 /api/system/info 的 mode 改成 'standalone'，
 * 验证前端会换成专门的引导卡片，并不再发出 friends / groups 请求。
 */
test.describe('Standalone mode (issue #340)', () => {
    test('sessions tab shows a standalone banner instead of loading friends/groups', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
        }, TOKEN);

        // 拦 /api/system/info：把 mode 改成 standalone，napcat.online 改成 false。
        await page.route('**/api/system/info', async (route, request) => {
            if (request.method() !== 'GET') {
                await route.continue();
                return;
            }
            const original = await route.fetch();
            const json = await original.json();
            if (json?.success && json.data) {
                json.data.mode = 'standalone';
                if (json.data.napcat) {
                    json.data.napcat.online = false;
                }
            }
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify(json),
            });
        });

        // 监控 friends / groups，应当一次都不被请求。
        const friendsRequests: string[] = [];
        const groupsRequests: string[] = [];
        page.on('request', (req) => {
            const url = req.url();
            if (url.includes('/api/friends')) friendsRequests.push(url);
            if (url.includes('/api/groups')) groupsRequests.push(url);
        });

        const response = await page
            .goto(`${FRONTEND_BASE}${SHELL_PATH}`)
            .catch(() => null);
        test.skip(
            !response || response.status() >= 500,
            `frontend not reachable at ${FRONTEND_BASE}`
        );

        // 跳过欢迎弹窗（如有）。
        const skipBtn = page.getByRole('button', { name: '跳过' }).first();
        if (await skipBtn.isVisible({ timeout: 1500 }).catch(() => false)) {
            await skipBtn.click().catch(() => null);
        }

        const sessionsTab = page.getByRole('button', { name: '会话', exact: true });
        await expect(sessionsTab).toBeVisible({ timeout: 15_000 });
        await sessionsTab.click();

        // 引导卡片可见。
        const banner = page.getByTestId('sessions-standalone-banner');
        await expect(banner).toBeVisible({ timeout: 10_000 });
        await expect(banner.getByText('独立模式：仅可浏览已导出的内容')).toBeVisible();
        await expect(banner.getByRole('button', { name: /浏览聊天记录/ })).toBeVisible();

        // 给一点时间确保前端没有偷偷发请求。
        await page.waitForTimeout(800);
        expect(friendsRequests, 'standalone mode must skip /api/friends').toEqual([]);
        expect(groupsRequests, 'standalone mode must skip /api/groups').toEqual([]);

        // 点击「浏览聊天记录」直接跳到 history 标签页。history 标签页的内容区
        // 一定带「记录列表」这个 segment 切换按钮，用它来确认跳转成功。
        await banner.getByRole('button', { name: /浏览聊天记录/ }).click();
        await expect(
            page.getByRole('button', { name: '记录列表', exact: true })
        ).toBeVisible({ timeout: 10_000 });
    });
});

test.describe('Scheduled exports (issue #624)', () => {
    test('edits an existing task and triggers the selected tasks in one batch', async ({ page }) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => localStorage.setItem('qce_access_token', value), TOKEN);

        let tasks = [
            {
                id: 'task-a', name: '任务 A', peer: { chatType: 2, peerUid: 'group-a', guildId: '' },
                sessionName: '群 A', scheduleType: 'daily', executeTime: '02:00',
                timeRangeType: 'yesterday', format: 'JSON', enabled: true,
                options: { filterPureImageMessages: false },
            },
            {
                id: 'task-b', name: '任务 B', peer: { chatType: 1, peerUid: 'friend-b', guildId: '' },
                sessionName: '好友 B', scheduleType: 'weekly', executeTime: '03:00',
                timeRangeType: 'last-week', format: 'JSON', enabled: false, options: {},
            },
        ];
        let updateBody: Record<string, unknown> | null = null;
        let batchBody: { ids?: string[] } | null = null;

        await page.route('**/api/scheduled-exports**', async (route, request) => {
            const url = new URL(request.url());
            if (request.method() === 'GET' && url.pathname.endsWith('/api/scheduled-exports')) {
                await route.fulfill({
                    status: 200, contentType: 'application/json',
                    body: JSON.stringify({ success: true, data: { scheduledExports: tasks } }),
                });
                return;
            }
            if (request.method() === 'PUT' && url.pathname.endsWith('/api/scheduled-exports/task-a')) {
                updateBody = request.postDataJSON();
                tasks = tasks.map(task => task.id === 'task-a' ? { ...task, ...updateBody } : task);
                await route.fulfill({
                    status: 200, contentType: 'application/json',
                    body: JSON.stringify({ success: true, data: { ...tasks[0], id: 'task-a' } }),
                });
                return;
            }
            if (request.method() === 'POST' && url.pathname.endsWith('/api/scheduled-exports/trigger-batch')) {
                batchBody = request.postDataJSON();
                await route.fulfill({
                    status: 200, contentType: 'application/json',
                    body: JSON.stringify({
                        success: true,
                        data: { triggeredCount: batchBody?.ids?.length ?? 0, triggered: [], missingIds: [] },
                    }),
                });
                return;
            }
            await route.continue();
        });

        const response = await page.goto(`${FRONTEND_BASE}${SHELL_PATH}/scheduled`).catch(() => null);
        test.skip(!response || response.status() >= 500, `frontend not reachable at ${FRONTEND_BASE}`);
        const skipBtn = page.getByRole('button', { name: '跳过' }).first();
        if (await skipBtn.isVisible({ timeout: 1500 }).catch(() => false)) await skipBtn.click();

        await expect(page.getByText('任务 A', { exact: true })).toBeVisible({ timeout: 15_000 });
        await page.getByRole('button', { name: '编辑', exact: true }).first().click();
        await expect(page.getByRole('dialog', { name: '编辑定时导出任务' })).toBeVisible();
        await page.locator('#namePrefix').fill('任务 A 已编辑');
        await page.getByRole('button', { name: '保存更改', exact: true }).click();
        await expect.poll(() => updateBody?.name).toBe('任务 A 已编辑');
        await expect.poll(() => (updateBody?.options as Record<string, unknown> | undefined)?.filterPureImageMessages).toBe(false);

        await page.getByRole('button', { name: '批量选择', exact: true }).click();
        await page.getByRole('checkbox', { name: '选择定时任务 任务 A 已编辑' }).click();
        await page.getByRole('checkbox', { name: '选择定时任务 任务 B' }).click();
        await page.getByRole('button', { name: '执行', exact: true }).click();
        await expect.poll(() => batchBody?.ids).toEqual(['task-a', 'task-b']);
    });

    test('partial execution history explains failed resources (issue #698)', async ({ page }, testInfo) => {
        await clearLocalStorage(page);
        await page.evaluate((value) => {
            localStorage.setItem('qce_access_token', value);
            localStorage.setItem('qce-onboarding-completed', 'true');
        }, TOKEN);

        const tasks = [
            {
                id: 'task-history',
                name: '资源失败历史',
                peer: { chatType: 1, peerUid: 'friend-history', guildId: '' },
                sessionName: '资源失败会话',
                scheduleType: 'daily',
                executeTime: '02:00',
                timeRangeType: 'yesterday',
                format: 'HTML',
                enabled: true,
                options: {},
            },
        ];

        await page.route('**/api/system/info**', async route => {
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify({ success: true, data: null }),
            });
        });
        await page.route('**/api/scheduled-exports**', async (route, request) => {
            const url = new URL(request.url());
            if (request.method() === 'GET' && url.pathname.endsWith('/api/scheduled-exports')) {
                await route.fulfill({
                    status: 200,
                    contentType: 'application/json',
                    body: JSON.stringify({ success: true, data: { scheduledExports: tasks } }),
                });
                return;
            }
            if (request.method() === 'GET' && url.pathname.endsWith('/api/scheduled-exports/task-history/history')) {
                await route.fulfill({
                    status: 200,
                    contentType: 'application/json',
                    body: JSON.stringify({
                        success: true,
                        data: {
                            history: [{
                                id: 'history-partial-resources',
                                scheduledExportId: 'task-history',
                                executedAt: '2025-08-01T00:00:00.000Z',
                                status: 'partial',
                                messageCount: 20,
                                duration: 5000,
                                resourceSummary: {
                                    attempted: 10,
                                    alreadyAvailable: 2,
                                    downloaded: 5,
                                    failed: 3,
                                    skipped: 0,
                                    failedSamples: [],
                                },
                            }],
                        },
                    }),
                });
                return;
            }
            await route.continue();
        });

        const response = await page.goto(`${FRONTEND_BASE}${SHELL_PATH}/scheduled`).catch(() => null);
        test.skip(!response || response.status() >= 500, `frontend not reachable at ${FRONTEND_BASE}`);
        await page.addStyleTag({ content: 'nextjs-portal { display: none !important; }' });
        await expect(page.getByText('资源失败历史', { exact: true })).toBeVisible({ timeout: 15_000 });
        const closeUpdate = page.getByRole('button', { name: '关闭更新提示' });
        if (await closeUpdate.isVisible()) await closeUpdate.click();
        await page.getByRole('button', { name: '历史', exact: true }).click();
        const historyDialog = page.getByRole('dialog', { name: '执行历史' });
        await expect(historyDialog).toBeVisible();
        await expect(historyDialog.getByText('部分', { exact: true })).toBeVisible();

        await page.locator('[aria-label="查看部分完成说明"]').hover();
        const tooltip = page.getByRole('tooltip');
        await expect(tooltip).toContainText('3 个图片、视频等资源下载失败');
        await page.screenshot({
            path: testInfo.outputPath('698-desktop-tooltip.png'),
            animations: 'disabled',
        });

        await page.setViewportSize({ width: 390, height: 844 });
        await page.mouse.move(0, 0);
        await historyDialog.locator('button').filter({ hasText: '部分' }).click({ position: { x: 50, y: 24 } });
        await expect(historyDialog.getByText('7/10，失败 3', { exact: true })).toBeVisible();
        await page.waitForTimeout(250);
        await page.screenshot({
            path: testInfo.outputPath('698-mobile-expanded.png'),
            animations: 'disabled',
        });
    });
});
