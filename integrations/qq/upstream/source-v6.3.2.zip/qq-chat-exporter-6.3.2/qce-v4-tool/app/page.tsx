"use client"

import { useState, useEffect, useRef, useMemo, useCallback, lazy, Suspense } from "react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { toast } from "@/components/ui/toast"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"
import type { BatchExportItem, BatchExportConfig } from "@/components/ui/batch-export-dialog"
import { SessionList } from "@/components/ui/session-list"
import { BatchSelectionCheckbox } from "@/components/ui/batch-selection-checkbox"
import { ExportHelpDialog, type ExportHelpFormat } from "@/components/ui/export-help-dialog"
import {
  sessionTaskStatsKey,
  type SessionTaskStats,
} from "@/lib/session-sort"
import { isActiveExportTaskStatus } from "@/lib/export-task-state"

const TaskWizard = lazy(() => import("@/components/ui/task-wizard").then(m => ({ default: m.TaskWizard })))
const ScheduledExportWizard = lazy(() => import("@/components/ui/scheduled-export-wizard").then(m => ({ default: m.ScheduledExportWizard })))
const ExecutionHistoryModal = lazy(() => import("@/components/ui/execution-history-modal").then(m => ({ default: m.ExecutionHistoryModal })))
const MessagePreviewModal = lazy(() => import("@/components/ui/message-preview-modal").then(m => ({ default: m.MessagePreviewModal })))
const BatchExportDialog = lazy(() => import("@/components/ui/batch-export-dialog").then(m => ({ default: m.BatchExportDialog })))
const ScheduledBackupMergeDialog = lazy(() => import("@/components/ui/scheduled-backup-merge-dialog").then(m => ({ default: m.ScheduledBackupMergeDialog })))
const GroupEssenceModal = lazy(() => import("@/components/ui/group-essence-modal").then(m => ({ default: m.GroupEssenceModal })))
const GroupFilesModal = lazy(() => import("@/components/ui/group-files-modal").then(m => ({ default: m.GroupFilesModal })))
const ExportTaskPlansPanel = lazy(() => import("@/components/export-plans/plans-panel").then(m => ({ default: m.ExportTaskPlansPanel })))
const SettingsPanel = lazy(() => import("@/components/ui/settings-panel").then(m => ({ default: m.SettingsPanel })))
const AboutPanel = lazy(() => import("@/components/ui/about-panel").then(m => ({ default: m.AboutPanel })))
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import {
  Download,
  Trash2,
  RefreshCw,
  X,
  Star,
  ExternalLink,
  ToggleLeft,
  ToggleRight,
  Zap,
  History,
  MessageCircle,
  Users,
  User,
  CalendarDays,
  FileText,
  Clock,
  Filter,
  SortAsc,
  SortDesc,
  Copy,
  CheckCircle,
  Smile,
  Package,
  Sticker,
  Layers,
  Combine,
  FolderOpen,
  Image,
  Video,
  Music,
  File,
  HardDrive,
  Database,
  HelpCircle,
  Activity,
  Settings,
  PanelLeftClose,
  PanelLeftOpen,
  ChevronRight,
  Search,
  Square,
} from "lucide-react"
import type { CreateTaskForm, CreateScheduledExportForm } from "@/types/api"
import { useQCE } from "@/hooks/use-qce"
import { BUILD_VERSION, isNewerVersion, isMajorUpdate, extractReleaseImage } from "@/lib/version"
import { UpdatePopover, type UpdateBannerInfo } from "@/components/ui/update-banner"
import { SecurityExposureBanner } from "@/components/ui/security-exposure-banner"
import AuthManager from "@/lib/auth"
import { classifySpecialChatType, specialKindLabel } from "@/lib/special-contacts"
import {
  scheduledExportConfigToForm,
  scheduledExportFormToConfig,
  useScheduledExports,
  type ScheduledExportConfig,
} from "@/hooks/use-scheduled-exports"
import { useChatHistory } from "@/hooks/use-chat-history"
import { useStickerPacks } from "@/hooks/use-sticker-packs"
import { useResourceIndex } from "@/hooks/use-resource-index"

import { ThemeToggle } from "@/components/qce-dashboard/theme-toggle"
import { AccountMenu, WindowControls, WindowDragRegion, useExternalLinksInBrowser } from "@/components/ui/window-controls"
import { Loader } from "@/components/ui/loader"

import { motion, AnimatePresence, useReducedMotion } from "framer-motion"
import { DUR, EASE, makeStagger } from "@/components/qce-dashboard/animations"

function TaskFormatLabel({ format, className }: { format: string; className?: string }) {
  if (format === "STREAMING_ZIP" || format === "STREAMING_JSONL") {
    const suffix = format === "STREAMING_ZIP" ? "ZIP" : "JSONL"
    return (
      <span className={`inline-flex items-center gap-1 ${className ?? ""}`}>
        <Tooltip>
          <TooltipTrigger asChild>
            <span
              className="inline-flex items-center justify-center w-[15px] h-[15px] rounded-[4px] bg-neutral-200 dark:bg-neutral-700 text-neutral-600 dark:text-neutral-200 text-[9px] font-bold leading-none cursor-help outline-none"
              aria-label="流式导出"
              tabIndex={0}
            >
              S
            </span>
          </TooltipTrigger>
          <TooltipContent side="top" sideOffset={6}>
            流式导出（Streaming）
          </TooltipContent>
        </Tooltip>
        <span className="font-medium tracking-wide">{suffix}</span>
      </span>
    )
  }
  return <span className={className}>{format}</span>
}

/**
 * 任务行的会话标识：优先显示 QQ 号；设备 / 临时会话等无 QQ 号时用友好名称，
 * 避免暴露 `u_...` 这类内部 uid 或裸露的 0。
 */
function formatTaskPeerLabel(peer?: { chatType?: number; peerUid?: string; peerUin?: string }): string {
  const uin = peer?.peerUin
  if (uin && /^\d{4,12}$/.test(uin)) {
    return uin
  }
  const kind = classifySpecialChatType(peer?.chatType ?? 0)
  if (kind !== "other") {
    return specialKindLabel(kind)
  }
  // 无有效 QQ 号且非特殊会话：不暴露 `u_...` 内部 uid（任务名已在标题处展示）。
  return ""
}

function formatRoamingStopReason(reason: string): string {
  const labels: Record<string, string> = {
    message_limit_reached: "达到消息数量上限",
    sequence_query_limit_reached: "达到逐序号查询上限",
    closing_anchor_not_found: "结束边界后未找到锚点",
    sequence_gaps_encountered: "部分消息序号不可读取",
    unresolved_anchors: "部分日期锚点无法解析",
    untimestamped_messages: "部分消息缺少有效时间",
    non_monotonic_anchor_sequence: "锚点序列顺序异常",
    sequence_cursor_stalled: "消息序号游标未推进",
    bounded_partial_result: "仅获得有界部分结果",
    requested_range_scanned: "已扫描所选日期范围",
    running: "扫描中",
    cancelled: "任务已取消",
    scan_failed: "扫描失败",
    native_api_unavailable: "当前 QQ/NapCat 不支持所需接口",
    native_query_failed: "QQ 原生查询失败",
    invalid_native_response: "QQ 原生响应结构异常",
  }
  return labels[reason] ?? reason
}

/** 元信息之间的细分隔线（取代旧的中点分隔符）。 */
const INLINE_DIVIDER = (
  <span aria-hidden className="mx-0.5 inline-block h-3 w-px translate-y-[2px] bg-current opacity-20" />
)

const VALID_TABS = ["overview", "sessions", "tasks", "plans", "scheduled", "history", "stickers", "settings", "about"] as const
type TabId = typeof VALID_TABS[number]

const TAB_PATH_MAP: Record<string, TabId> = {
  "": "overview",
  "overview": "overview",
  "sessions": "sessions",
  "tasks": "tasks",
  "plans": "plans",
  "scheduled": "scheduled",
  "history": "history",
  "stickers": "stickers",
  "settings": "settings",
  "about": "about",
}

function getTabFromPath(): TabId {
  if (typeof window === "undefined") return "overview"
  const path = window.location.pathname.replace(/\/+$/, "")
  const segments = path.split("/")
  const last = segments[segments.length - 1] || ""
  return TAB_PATH_MAP[last] || "overview"
}

export default function QCEDashboard({ initialTab }: { initialTab?: string } = {}) {
  const [activeTab, setActiveTabState] = useState<TabId>(() => {
    if (typeof window !== "undefined") return getTabFromPath()
    return (initialTab as TabId) || "overview"
  })
  const [isTaskWizardOpen, setIsTaskWizardOpen] = useState(false)
  const [selectedPreset, setSelectedPreset] = useState<Partial<CreateTaskForm> | undefined>()
  const [isScheduledExportWizardOpen, setIsScheduledExportWizardOpen] = useState(false)
  const [selectedScheduledPreset, setSelectedScheduledPreset] = useState<Partial<CreateScheduledExportForm> | undefined>()
  const [editingScheduledExportId, setEditingScheduledExportId] = useState<string | null>(null)
  const [selectedScheduledExportIds, setSelectedScheduledExportIds] = useState<Set<string>>(new Set())
  const [scheduledBatchMode, setScheduledBatchMode] = useState(false)
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false)
  const [selectedHistoryTask, setSelectedHistoryTask] = useState<{id: string, name: string} | null>(null)
  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false)
  const [previewingChat, setPreviewingChat] = useState<{
    type: 'group' | 'friend',
    id: string,
    name: string,
    peer: { chatType: number, peerUid: string }
  } | null>(null)
  const [isFilePathModalOpen, setIsFilePathModalOpen] = useState(false)
  const [selectedFile, setSelectedFile] = useState<{ filePath: string; sessionName: string; fileName: string; size?: number } | null>(null)
  
  // 群精华消息模态框状态
  const [isEssenceModalOpen, setIsEssenceModalOpen] = useState(false)
  const [essenceGroup, setEssenceGroup] = useState<{ groupCode: string; groupName: string } | null>(null)
  
  // 群文件/群相册模态框状态
  const [isGroupFilesModalOpen, setIsGroupFilesModalOpen] = useState(false)
  const [groupFilesTarget, setGroupFilesTarget] = useState<{ groupCode: string; groupName: string } | null>(null)
  
  // 批量导出模式状态
  const [batchMode, setBatchMode] = useState(false)
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set())
  const [isBatchExportDialogOpen, setIsBatchExportDialogOpen] = useState(false)
  
  // 定时备份合并状态
  const [isScheduledMergeDialogOpen, setIsScheduledMergeDialogOpen] = useState(false)
  const [scheduledTasks, setScheduledTasks] = useState<Array<any>>([])
  // Issue #163: 同一对话框里也展示手动导出，按会话聚合后允许混合合并。
  const [manualTasks, setManualTasks] = useState<Array<any>>([])
  const [loadingScheduledTasks, setLoadingScheduledTasks] = useState(false)
  
  // 聊天记录筛选状态
  const [historyFilter, setHistoryFilter] = useState<'all' | 'group' | 'friend'>('all')
  const [historyFormatFilter, setHistoryFormatFilter] = useState<'all' | 'html' | 'json' | 'zip' | 'jsonl'>('all')
  const [historyViewMode, setHistoryViewMode] = useState<'list' | 'gallery'>('list')
  const [previewResource, setPreviewResource] = useState<{ type: string; url: string; name: string } | null>(null)
  
  // 大规模导出帮助模态框状态
  const [exportHelpOpen, setExportHelpOpen] = useState(false)
  const [exportHelpFormat, setExportHelpFormat] = useState<ExportHelpFormat>('html')
  const [helpFilePath, setHelpFilePath] = useState<string>('')
  
  // GitHub stars
  const [githubStars, setGithubStars] = useState<number | null>(null)
  const [updateInfo, setUpdateInfo] = useState<UpdateBannerInfo | null>(null)
  
  // 定时导出筛选状态
  const [scheduledFilter, setScheduledFilter] = useState<'all' | 'enabled' | 'disabled'>('all')
  
  // 表情包筛选状态
  const [stickerFilter, setStickerFilter] = useState<'all' | 'favorite' | 'market' | 'system'>('all')
  
  // 新手引导状态
  const [showOnboarding, setShowOnboarding] = useState(false)
  const [onboardingStep, setOnboardingStep] = useState(0)
  const [highlightedNav, setHighlightedNav] = useState<string | null>(null)
  
  // 侧边栏状态
  const [sidebarOpen, setSidebarOpen] = useState(true)
  useExternalLinksInBrowser()
  const [sidebarMobileOpen, setSidebarMobileOpen] = useState(false)
  
  const tasksLoadedRef = useRef(false)
  const scheduledExportsLoadedRef = useRef(false)
  const chatHistoryLoadedRef = useRef(false)
  const stickerPacksLoadedRef = useRef(false)

  // 是否偏好降级动画
  const reduceMotion = useReducedMotion() ?? false

  const setActiveTab = (tabId: string) => {
    setActiveTabState(tabId as TabId)
    if (typeof window !== "undefined") {
      localStorage.setItem("qce-active-tab", tabId)
      const basePath = tabId === "overview" ? "/qce" : `/qce/${tabId}`
      if (window.location.pathname.replace(/\/+$/, "") !== basePath) {
        window.history.pushState(null, "", basePath + "/")
      }
    }
    // On mobile, close sidebar when navigating
    setSidebarMobileOpen(false)
  }

  useEffect(() => {
    const onPopState = () => {
      setActiveTabState(getTabFromPath())
    }
    window.addEventListener("popstate", onPopState)
    return () => window.removeEventListener("popstate", onPopState)
  }, [])

  useEffect(() => {
      if (typeof window !== "undefined") {
        const urlTab = getTabFromPath()
        if (urlTab !== "overview" || window.location.pathname.replace(/\/+$/, "").endsWith("/overview")) {
          setActiveTabState(urlTab)
        } else {
          const savedTab = localStorage.getItem("qce-active-tab")
          if (savedTab && VALID_TABS.includes(savedTab as TabId)) {
            setActiveTabState(savedTab as TabId)
          }
        }
        // 检查是否需要显示新手引导
        const hasSeenOnboarding = localStorage.getItem("qce-onboarding-completed")
        if (!hasSeenOnboarding) {
          setShowOnboarding(true)
        }
        // Restore sidebar state
        const savedSidebar = localStorage.getItem("qce-sidebar-open")
        if (savedSidebar !== null) {
          setSidebarOpen(savedSidebar === "true")
        }
        // Detect mobile
        if (window.innerWidth < 768) {
          setSidebarOpen(false)
        }
      }
  }, [])

  // Save sidebar state
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("qce-sidebar-open", String(sidebarOpen))
    }
  }, [sidebarOpen])

  // 监听大规模导出帮助模态框事件
  useEffect(() => {
    const handleJsonlHelp = (e: CustomEvent<{ filePath: string }>) => {
      setHelpFilePath(e.detail.filePath)
      setExportHelpFormat('jsonl')
      setExportHelpOpen(true)
    }
    const handleStreamingZipHelp = (e: CustomEvent<{ filePath: string }>) => {
      setHelpFilePath(e.detail.filePath)
      setExportHelpFormat('zip')
      setExportHelpOpen(true)
    }
    
    window.addEventListener('show-jsonl-help', handleJsonlHelp as EventListener)
    window.addEventListener('show-streaming-zip-help', handleStreamingZipHelp as EventListener)
    
    return () => {
      window.removeEventListener('show-jsonl-help', handleJsonlHelp as EventListener)
      window.removeEventListener('show-streaming-zip-help', handleStreamingZipHelp as EventListener)
    }
  }, [])

  useEffect(() => {
    const fetchStars = async () => {
      try {
        const res = await fetch('https://api.github.com/repos/shuakami/qq-chat-exporter')
        if (res.ok) {
          const data = await res.json()
          setGithubStars(data.stargazers_count)
        }
      } catch {
        // 静默失败
      }
    }
    fetchStars()
  }, [])

  const addNotification = useCallback((
    type: 'success' | 'error' | 'info',
    title: string,
    message: string,
    actions?: Array<{
      label: string
      onClick: () => void
      variant?: 'default' | 'destructive'
      keepOpen?: boolean
    }>,
    duration?: number
  ) => {
    const showToast = type === 'success'
      ? toast.success
      : type === 'error'
        ? toast.error
        : toast.info

    return showToast(title, {
      description: message,
      actions,
      duration: duration === 0 ? Number.POSITIVE_INFINITY : duration,
    })
  }, [])

  const removeNotification = useCallback((id: string) => {
    toast.dismiss(id)
  }, [])

  const showDeleteConfirmationToast = useCallback((
    title: string,
    description: string,
    onConfirmDelete: () => Promise<void>,
  ) => {
    let toastId = ""

    toastId = toast.error(title, {
      description,
      duration: Number.POSITIVE_INFINITY,
      actions: [
        {
          label: "确认删除",
          onClick: () => {
            void toast.promise(
              onConfirmDelete,
              {
                loading: "正在删除...",
                success: "已删除",
                error: (err) => err instanceof Error ? err.message : "删除失败",
              },
              {
                id: toastId,
                description: undefined,
                actions: undefined,
                duration: 3200,
              }
            )
          },
          variant: "destructive",
        },
      ],
    })
  }, [])

  const handleQceNotification = useCallback((notification: {
    type: 'success' | 'error' | 'info'
    title: string
    message: string
    actions?: Array<{
      label: string
      onClick: () => void
      variant?: 'default' | 'destructive'
    }>
  }) => {
    addNotification(
      notification.type,
      notification.title,
      notification.message,
      notification.actions
    )
  }, [addNotification])

  const {
    systemInfo,
    refreshSystemInfo,
    groups,
    friends,
    recentActivityMap,
    loadChatData,
    tasks,
    loadTasks,
    deleteTask,
    cancelTask,
    createTask,
    downloadTask,
    getTaskStats,
    isTaskDataStale,
    isLoading,
    error,
    setError,
    exportGroupAvatars,
    avatarExportLoading,
    isJsonlExport,
    openTaskFileLocation,
  } = useQCE({ onNotification: handleQceNotification })

  useEffect(() => {
    const currentVersion = systemInfo?.version || BUILD_VERSION
    if (!currentVersion || currentVersion === 'unknown') return

    const checkUpdate = async () => {
      try {
        const res = await fetch('https://api.github.com/repos/shuakami/qq-chat-exporter/releases?per_page=1')
        if (!res.ok) return

        const releases = await res.json()
        const latest = releases?.[0]
        if (latest?.tag_name && latest?.html_url && isNewerVersion(latest.tag_name, currentVersion)) {
          setUpdateInfo({
            tag: latest.tag_name,
            url: latest.html_url,
            name: typeof latest.name === 'string' ? latest.name : undefined,
            image: extractReleaseImage(latest.body) ?? undefined,
            major: isMajorUpdate(latest.tag_name, currentVersion),
          })
        } else {
          setUpdateInfo(null)
        }
      } catch {
        // 静默失败
      }
    }

    checkUpdate()
  }, [systemInfo?.version])

  // 打开群精华消息模态框
  const handleOpenEssenceModal = useCallback((groupCode: string, groupName: string) => {
    setEssenceGroup({ groupCode, groupName })
    setIsEssenceModalOpen(true)
  }, [])

  // 关闭群精华消息模态框
  const handleCloseEssenceModal = () => {
    setIsEssenceModalOpen(false)
    setEssenceGroup(null)
  }

  // 打开群文件/群相册模态框
  const handleOpenGroupFilesModal = useCallback((groupCode: string, groupName: string) => {
    setGroupFilesTarget({ groupCode, groupName })
    setIsGroupFilesModalOpen(true)
  }, [])

  // 关闭群文件/群相册模态框
  const handleCloseGroupFilesModal = () => {
    setIsGroupFilesModalOpen(false)
    setGroupFilesTarget(null)
  }

  // 打开文件位置
  const openFileLocation = useCallback(async (filePath?: string) => {
    if (!filePath) {
      addNotification('error', '打开失败', '文件路径不存在')
      return
    }
    
    try {
      const response = await fetch('/api/open-file-location', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filePath })
      })
      
      const data = await response.json()
      if (!data.success) {
        const msg = typeof data.error === 'string' ? data.error : data.error?.message || '未知错误'
        addNotification('error', '打开失败', msg)
      }
    } catch (error) {
      console.error('[QCE] Open file location error:', error)
      addNotification('error', '打开失败', error instanceof Error ? error.message : '未知错误')
    }
  }, [addNotification])

  const handleExportGroupAvatars = useCallback(async (groupCode: string, groupName: string) => {
    const loadingId = addNotification('info', '正在导出', `正在导出群"${groupName}"的成员头像...`)

    try {
      const result = await exportGroupAvatars(groupCode)
      removeNotification(loadingId)

      if (result) {
        addNotification(
          'success',
          '导出成功',
          `已导出 ${result.successCount} 个头像\n文件: ${result.fileName}`,
          [
            {
              label: '打开文件位置',
              onClick: () => openFileLocation(result.filePath)
            }
          ],
          0
        )
      } else {
        addNotification('error', '导出失败', '导出群头像失败')
      }
    } catch (error) {
      removeNotification(loadingId)
      addNotification('error', '导出失败', error instanceof Error ? error.message : '未知错误')
    }
  }, [addNotification, exportGroupAvatars, openFileLocation, removeNotification])

  // 打开导出目录
  const openExportDirectory = async () => {
    try {
      const response = await fetch('/api/open-export-directory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      })
      
      const data = await response.json()
      if (!data.success) {
        const msg = typeof data.error === 'string' ? data.error : data.error?.message || '未知错误'
        addNotification('error', '打开失败', msg)
      }
    } catch (error) {
      console.error('[QCE] Open export directory error:', error)
      addNotification('error', '打开失败', error instanceof Error ? error.message : '未知错误')
    }
  }

  const {
    scheduledExports,
    loading: scheduledLoading,
    error: scheduledError,
    loadScheduledExports,
    createScheduledExport,
    updateScheduledExport,
    deleteScheduledExport,
    triggerScheduledExport,
    triggerScheduledExports,
    setScheduledExportsEnabled,
    deleteScheduledExports,
    toggleScheduledExport,
    getExecutionHistory,
    getStats: getScheduledStats,
    setError: setScheduledError,
  } = useScheduledExports()

  const filteredScheduledExports = useMemo(() =>
    scheduledExports.filter(task =>
      scheduledFilter === 'all' || (scheduledFilter === 'enabled' ? task.enabled : !task.enabled)
    ),
  [scheduledExports, scheduledFilter])
  const selectedVisibleScheduledCount = filteredScheduledExports.reduce(
    (count, task) => count + (selectedScheduledExportIds.has(task.id) ? 1 : 0),
    0
  )
  const allVisibleScheduledSelected = filteredScheduledExports.length > 0
    && selectedVisibleScheduledCount === filteredScheduledExports.length

  useEffect(() => {
    const existingIds = new Set(scheduledExports.map(task => task.id))
    setSelectedScheduledExportIds(previous => {
      const next = new Set(Array.from(previous).filter(id => existingIds.has(id)))
      return next.size === previous.size ? previous : next
    })
  }, [scheduledExports])

  const {
    files: chatHistoryFiles,
    loading: chatHistoryLoading,
    error: chatHistoryError,
    loadChatHistory,
    getStats: getChatHistoryStats,
    deleteFile: deleteChatHistoryFile,
    downloadFile: downloadChatHistoryFile,
    setError: setChatHistoryError,
  } = useChatHistory()

  const {
    packs: stickerPacks,
    exportRecords: stickerExportRecords,
    loading: stickerPacksLoading,
    exporting: stickerPacksExporting,
    error: stickerPacksError,
    loadStickerPacks,
    loadExportRecords: loadStickerExportRecords,
    exportStickerPack,
    exportAllStickerPacks,
    getStats: getStickerPacksStats,
    setError: setStickerPacksError,
  } = useStickerPacks()

  const {
    index: resourceIndex,
    resourceFiles,
    resourceFilesTotal,
    resourceFilesHasMore,
    loading: resourceIndexLoading,
    filesLoading: resourceFilesLoading,
    error: resourceIndexError,
    loadResourceIndex,
    loadResourceFiles,
    formatSize: formatResourceSize,
    getStats: getResourceStats,
    setError: setResourceIndexError,
  } = useResourceIndex()

  const resourceIndexLoadedRef = useRef(false)
  const [historySubTab, setHistorySubTab] = useState<'records' | 'gallery'>('records')
  const [galleryType, setGalleryType] = useState<'all' | 'images' | 'videos' | 'audios' | 'files'>('all')
  const [galleryPage, setGalleryPage] = useState(1)
  // issue #294 子项 1：画廊文件名搜索。输入值是受控的，外加一份 debounce 后真正发请求的值，
  // 避免每敲一个字就打一次后端。
  const [gallerySearchInput, setGallerySearchInput] = useState('')
  const [gallerySearchActive, setGallerySearchActive] = useState('')

  const handleOpenTaskWizard = useCallback((preset?: Partial<CreateTaskForm>) => {
    setSelectedPreset(preset)
    setIsTaskWizardOpen(true)
  }, [])

  const handlePreviewChat = useCallback((
    type: 'group' | 'friend',
    id: string,
    name: string,
    peer: { chatType: number, peerUid: string }
  ) => {
    setPreviewingChat({ type, id, name, peer })
    setIsPreviewModalOpen(true)
  }, [])

  const handleCloseTaskWizard = () => {
    setIsTaskWizardOpen(false)
    setSelectedPreset(undefined)
  }

  const handleOpenScheduledExportWizard = (preset?: Partial<CreateScheduledExportForm>) => {
    setEditingScheduledExportId(null)
    setSelectedScheduledPreset(preset)
    setIsScheduledExportWizardOpen(true)
  }

  const handleEditScheduledExport = (task: ScheduledExportConfig & { id: string }) => {
    setEditingScheduledExportId(task.id)
    setSelectedScheduledPreset(scheduledExportConfigToForm(task))
    setIsScheduledExportWizardOpen(true)
  }

  const handleCloseScheduledExportWizard = () => {
    setIsScheduledExportWizardOpen(false)
    setSelectedScheduledPreset(undefined)
    setEditingScheduledExportId(null)
  }

  const handleToggleScheduledBatchMode = () => {
    setScheduledBatchMode(previous => {
      if (previous) setSelectedScheduledExportIds(new Set())
      return !previous
    })
  }

  const handleToggleScheduledSelection = (id: string, checked: boolean) => {
    setSelectedScheduledExportIds(previous => {
      const next = new Set(previous)
      if (checked) next.add(id)
      else next.delete(id)
      return next
    })
  }

  const handleToggleAllVisibleScheduled = (checked: boolean) => {
    setSelectedScheduledExportIds(previous => {
      const next = new Set(previous)
      for (const task of filteredScheduledExports) {
        if (checked) next.add(task.id)
        else next.delete(task.id)
      }
      return next
    })
  }

  const handleTriggerSelectedScheduledExports = async () => {
    const ids = scheduledExports
      .map(task => task.id)
      .filter(id => selectedScheduledExportIds.has(id))
    if (ids.length === 0) return
    try {
      await triggerScheduledExports(ids)
      setSelectedScheduledExportIds(new Set())
    } catch {
      // 错误提示由 hook 统一处理。
    }
  }

  const getSelectedScheduledIds = () => scheduledExports
    .map(task => task.id)
    .filter(id => selectedScheduledExportIds.has(id))

  const handleDisableSelectedScheduledExports = async () => {
    const ids = getSelectedScheduledIds()
    if (ids.length === 0) return
    try {
      await setScheduledExportsEnabled(ids, false)
      setSelectedScheduledExportIds(new Set())
    } catch {
      // 错误提示由 hook 统一处理。
    }
  }

  const handleDeleteSelectedScheduledExports = () => {
    const ids = getSelectedScheduledIds()
    if (ids.length === 0) return
    showDeleteConfirmationToast(
      `删除已选择的 ${ids.length} 个定时任务？`,
      "相关执行历史也会删除，此操作不可撤销",
      async () => {
        await deleteScheduledExports(ids)
        setSelectedScheduledExportIds(new Set())
      }
    )
  }

  const handleOpenHistoryModal = (taskId: string, taskName: string) => {
    setSelectedHistoryTask({ id: taskId, name: taskName })
    setIsHistoryModalOpen(true)
  }

  const handleCloseHistoryModal = () => {
    setIsHistoryModalOpen(false)
    setTimeout(() => setSelectedHistoryTask(null), 300)
  }

  const handleOpenFilePathModal = (filePath: string, sessionName: string, fileName: string, size?: number) => {
    setSelectedFile({ filePath, sessionName, fileName, size })
    setIsFilePathModalOpen(true)
  }

  const handleCloseFilePathModal = () => {
    // Clear iframe content first to prevent browser freeze on large files
    // (compositing 3MB+ content during exit animation causes hang)
    const iframes = document.querySelectorAll('iframe[title^="预览"]')
    iframes.forEach(f => { (f as HTMLIFrameElement).src = 'about:blank' })
    setIsFilePathModalOpen(false)
    setSelectedFile(null)
  }

  const handleExportStickerPack = async (packId: string, packName: string) => {
    const loadingId = addNotification('info', '正在导出', `正在导出表情包"${packName}"...`)
    
    try {
      const result = await exportStickerPack(packId)
      removeNotification(loadingId)
      
      if (result) {
        const exportPath = result.exportPath
        addNotification(
          'success',
          '导出成功',
          `表情包“${packName}”已导出`,
          exportPath ? [
            {
              label: '打开位置',
              onClick: () => openFileLocation(exportPath)
            }
          ] : undefined,
          0
        )
        await loadStickerExportRecords()
      } else {
        addNotification('error', '导出失败', `表情包"${packName}"导出失败`)
      }
    } catch (error) {
      removeNotification(loadingId)
      addNotification('error', '导出失败', error instanceof Error ? error.message : '未知错误')
    }
  }

  const handleExportAllStickerPacks = async () => {
    const loadingId = addNotification('info', '正在导出', '正在导出所有表情包...')
    
    try {
      const result = await exportAllStickerPacks()
      removeNotification(loadingId)
      
      if (result) {
        const exportPath = result.exportPath
        const packCount = result.packCount || 0
        addNotification(
          'success',
          '导出成功',
          `已导出 ${packCount} 个表情包`,
          exportPath ? [
            {
              label: '打开位置',
              onClick: () => openFileLocation(exportPath)
            }
          ] : undefined,
          0
        )
        await loadStickerExportRecords()
      } else {
        addNotification('error', '导出失败', '表情包导出失败')
      }
    } catch (error) {
      removeNotification(loadingId)
      addNotification('error', '导出失败', error instanceof Error ? error.message : '未知错误')
    }
  }

  // 任务列表加载（首页和任务页都需要）
  useEffect(() => {
    if ((activeTab === "tasks" || activeTab === "overview") && !tasksLoadedRef.current) {
      tasksLoadedRef.current = true
      loadTasks().catch(() => {
        tasksLoadedRef.current = false
      })
    }
  }, [activeTab, loadTasks])

  // issue #294 子项 1：画廊搜索框 debounce。用户停止输入 250ms 之后，才把
  // input 值同步到 active 值上，避免每敲一个字就打一次后端。
  useEffect(() => {
    if (gallerySearchInput === gallerySearchActive) return
    const timer = setTimeout(() => {
      setGallerySearchActive(gallerySearchInput)
    }, 250)
    return () => clearTimeout(timer)
  }, [gallerySearchInput, gallerySearchActive])

  // 画廊搜索：active 关键词变化时回到第一页重新拉数据。仅在 gallery 子页激活时触发，
  // 避免用户根本没切到画廊时被多余请求打扰。
  useEffect(() => {
    if (historySubTab !== 'gallery') return
    setGalleryPage(1)
    loadResourceFiles(galleryType, 1, 50, false, gallerySearchActive)
  }, [gallerySearchActive, historySubTab, galleryType, loadResourceFiles])
  
  // 定时导出加载
  useEffect(() => {
    if (activeTab === "scheduled" && !scheduledExportsLoadedRef.current) {
      scheduledExportsLoadedRef.current = true
      loadScheduledExports().catch(() => {
        scheduledExportsLoadedRef.current = false
      })
    }
  }, [activeTab])
  
  // 聊天历史加载
  useEffect(() => {
    if (activeTab === "history" && !chatHistoryLoadedRef.current) {
      chatHistoryLoadedRef.current = true
      loadChatHistory().catch(() => {
        chatHistoryLoadedRef.current = false
      })
    }
  }, [activeTab])
  
  // 表情包加载
  useEffect(() => {
    if (activeTab === "stickers" && !stickerPacksLoadedRef.current) {
      stickerPacksLoadedRef.current = true
      Promise.all([
        loadStickerPacks(),
        loadStickerExportRecords()
      ]).catch((error) => {
        console.error('[QCE] 加载表情包数据失败:', error)
        stickerPacksLoadedRef.current = false
      })
    }
  }, [activeTab])

  // 资源索引加载（与聊天记录一起加载）
  useEffect(() => {
    if (activeTab === "history" && !resourceIndexLoadedRef.current) {
      resourceIndexLoadedRef.current = true
      loadResourceIndex().catch((error) => {
        console.error('[QCE] 加载资源索引失败:', error)
        resourceIndexLoadedRef.current = false
      })
    }
  }, [activeTab])
  
  const handleLoadTasks = async () => {
    tasksLoadedRef.current = false
    try {
      await loadTasks()
      tasksLoadedRef.current = true
    } catch {
      tasksLoadedRef.current = false
    }
  }

  const handleLoadScheduledExports = async () => {
    scheduledExportsLoadedRef.current = false
    try {
      await loadScheduledExports()
      scheduledExportsLoadedRef.current = true
    } catch {
      scheduledExportsLoadedRef.current = false
    }
  }

  const handleLoadChatHistory = async () => {
    chatHistoryLoadedRef.current = false
    await loadChatHistory()
    chatHistoryLoadedRef.current = true
  }

  const handleCreateTask = async (form: CreateTaskForm) => {
    const success = await createTask(form)
    if (success) {
      tasksLoadedRef.current = false
      setActiveTab("tasks")
    }
    return success
  }

  const handleCreateScheduledExport = async (form: CreateScheduledExportForm) => {
    const success = await createScheduledExport(form)
    if (success) {
      // Immediately reload the list after successful creation
      await loadScheduledExports()
    }
    return success
  }

  // 批量模式处理函数
  const handleToggleBatchMode = useCallback(() => {
    setBatchMode(!batchMode)
    if (batchMode) setSelectedItems(new Set())
  }, [batchMode])

  const handleSelectAll = useCallback((filteredIds?: Set<string>) => {
    if (filteredIds) {
      setSelectedItems(filteredIds)
    } else {
      const allIds = new Set<string>()
      groups.forEach(g => allIds.add(`group_${g.groupCode}`))
      friends.forEach(f => allIds.add(`friend_${f.uid}`))
      setSelectedItems(allIds)
    }
  }, [friends, groups])

  const handleClearSelection = useCallback(() => {
    setSelectedItems(new Set())
  }, [])

  /**
   * Issue #344: 区间多选 / 分类全选用的批量增删入口。
   * - mode = 'add' 把 ids 全部加进当前选区；
   * - mode = 'remove' 把 ids 全部从当前选区移除。
   * 不替换其它已选项，避免按「全选群」会清掉用户手挑的好友。
   */
  const handleSelectMany = useCallback((ids: Set<string>, mode: 'add' | 'remove') => {
    setSelectedItems((prev) => {
      const next = new Set(prev)
      if (mode === 'add') {
        ids.forEach((id) => next.add(id))
      } else {
        ids.forEach((id) => next.delete(id))
      }
      return next
    })
  }, [])

  const handleToggleItem = useCallback((type: 'group' | 'friend', id: string) => {
    const itemId = `${type}_${id}`
    setSelectedItems((previous) => {
      const next = new Set(previous)
      if (next.has(itemId)) next.delete(itemId)
      else next.add(itemId)
      return next
    })
  }, [])

  const handleOpenBatchExportDialog = useCallback(() => {
    if (selectedItems.size === 0) return
    setIsBatchExportDialogOpen(true)
  }, [selectedItems.size])

  // 获取批量导出的项目列表
  const getBatchExportItems = (): BatchExportItem[] => {
    const items: BatchExportItem[] = []
    
    selectedItems.forEach(itemId => {
      const [type, ...idParts] = itemId.split('_')
      const id = idParts.join('_') // 重新组合ID部分
      
      if (type === 'group') {
        const group = groups.find(g => g.groupCode === id)
        if (group) {
          items.push({
            type: 'group',
            id: group.groupCode,
            name: group.groupName,
            chatType: 2,
            peerUid: group.groupCode,
            peerUin: group.groupCode,
            avatarUrl: group.avatarUrl
          })
        }
      } else if (type === 'friend') {
        const friend = friends.find(f => f.uid === id)
        if (friend) {
          // Issue #364: 合并自最近联系人的特殊会话（QQ Bot / 服务号 / 临时会话）
          // 会带上原始 chatType，避免在导出请求里被强制覆写为 1。
          items.push({
            type: 'friend',
            id: friend.uid,
            name: friend.remark || friend.nick,
            chatType: friend.chatType ?? 1,
            peerUid: friend.uid,
            peerUin: String(friend.uin || ""),
            avatarUrl: friend.avatarUrl
          })
        }
      }
    })
    
    return items
  }

  // 批量导出处理函数
  const handleBatchExport = async (
    config: BatchExportConfig,
    onProgress?: (index: number, status: 'success' | 'failed', error?: string) => void
  ) => {
    const items = getBatchExportItems()
    const results: Array<{ name: string; status: 'success' | 'failed'; error?: string }> = []

    for (let i = 0; i < items.length; i++) {
      const item = items[i]
      
      try {
        // 构建导出表单
        let startTime: string | undefined
        let endTime: string | undefined
        
        if (config.timeRange === 'recent') {
          const now = new Date()
          const threeMonthsAgo = new Date()
          threeMonthsAgo.setMonth(now.getMonth() - 3)
          startTime = threeMonthsAgo.toISOString()
          endTime = now.toISOString()
        } else if (config.timeRange === 'custom') {
          if (config.customStartDate) {
            startTime = new Date(config.customStartDate).toISOString()
          }
          if (config.customEndDate) {
            const endDate = new Date(config.customEndDate)
            endDate.setHours(23, 59, 59, 999)
            endTime = endDate.toISOString()
          }
        }

        const form: CreateTaskForm = {
          chatType: item.chatType,
          peerUid: item.peerUid,
          peerUin: item.peerUin,
          sessionName: item.name,
          format: config.format,
          startTime,
          endTime,
          includeRecalled: false,
          includeSystemMessages: config.includeSystemMessages,
          filterPureImageMessages: config.filterPureImageMessages,
          // 高级选项
          streamingZipMode: config.streamingZipMode,
          exportAsZip: config.exportAsZip,
          embedAvatarsAsBase64: config.embedAvatarsAsBase64,
          // Issue #311: 自包含 HTML
          embedResourcesAsDataUri: config.embedResourcesAsDataUri,
          preferGroupMemberName: config.preferGroupMemberName,
          debugExport: config.debugExport,
          outputDir: config.outputDir,
          keywords: config.keywords,
          excludeUserUins: config.excludeUserUins,
          useNameInFileName: config.useNameInFileName,
          // Issue #134: 友好文件名格式
          useFriendlyFileName: config.useFriendlyFileName,
          // Issue #341
          ...(Array.isArray(config.skipDownloadResourceTypes) && config.skipDownloadResourceTypes.length > 0 && {
            skipDownloadResourceTypes: config.skipDownloadResourceTypes,
          }),
        }

        // 调用单个导出 API
        const success = await createTask(form)
        
        if (success) {
          onProgress?.(i, 'success')
          results.push({ name: item.name, status: 'success' })
        } else {
          onProgress?.(i, 'failed', '导出失败')
          results.push({ name: item.name, status: 'failed', error: '导出失败' })
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : '未知错误'
        onProgress?.(i, 'failed', message)
        results.push({ 
          name: item.name, 
          status: 'failed', 
          error: message 
        })
      }

      // 添加短暂延迟，避免请求过快
      if (i < items.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 500))
      }
    }

    // 导出完成，退出批量模式，清空选择
    setBatchMode(false)
    setSelectedItems(new Set())
    setIsBatchExportDialogOpen(false)

    // 刷新任务列表
    tasksLoadedRef.current = false

    // 显示通知，带跳转按钮
    const successCount = results.filter(r => r.status === 'success').length
    const failedCount = results.filter(r => r.status === 'failed').length
    const goToTasksAction = { label: '查看任务', onClick: () => setActiveTab('tasks') }
    
    if (failedCount === 0) {
      addNotification('success', '批量导出完成', `成功创建 ${successCount} 个导出任务`, [goToTasksAction], 8000)
    } else if (successCount === 0) {
      addNotification('error', '批量导出失败', `所有 ${failedCount} 个任务都失败了`, [goToTasksAction], 8000)
    } else {
      addNotification('info', '批量导出部分完成', `成功 ${successCount} 个，失败 ${failedCount} 个`, [goToTasksAction], 8000)
    }
  }

  // 加载定时备份任务
  const loadScheduledBackups = async () => {
    setLoadingScheduledTasks(true)
    try {
      const response = await fetch('/api/merge-resources/available-tasks')
      const data = await response.json()
      if (data.success) {
        setScheduledTasks(data.data.scheduledTasks || [])
        setManualTasks(data.data.manualTasks || [])
      }
    } catch (error) {
      console.error('加载备份列表失败:', error)
      addNotification('error', '加载失败', '无法获取备份列表')
    } finally {
      setLoadingScheduledTasks(false)
    }
  }

  // 打开定时备份合并对话框
  const handleOpenScheduledMergeDialog = async () => {
    await loadScheduledBackups()
    setIsScheduledMergeDialogOpen(true)
  }

  // 执行定时备份合并
  const handleScheduledMerge = async (config: {
    sourceTaskIds: string[]  // 文件名列表
    deleteSourceFiles: boolean
    deduplicateMessages: boolean
    formats?: string[]  // 输出格式:json / html
  }) => {
    const loadingId = addNotification('info', '正在合并', '合并任务已开始，请稍候...')
    
    try {
      const response = await fetch('/api/merge-resources', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      })
      
      const data = await response.json()
      
      if (data.success) {
        const result = data.data.result
        removeNotification(loadingId)
        
        // 按聊天分组的结果:每组一条成功消息 + 一个「打开文件位置」动作。
        const groups: Array<{
          chatType?: string
          displayName?: string
          sourceCount?: number
          totalMessages?: number
          deduplicatedMessages?: number
          jsonPath?: string
          htmlPath?: string
          status?: string
          error?: string
        }> = result.groups || []
        const skipped: Array<{ fileName?: string; reason?: string }> = result.skipped || []

        const successGroups = groups.filter(g => g.status === 'success')
        const failedGroups = groups.filter(g => g.status === 'failed')
        const lines = successGroups.map(g =>
          `${g.displayName}:合并 ${g.sourceCount} 个备份 → ${g.totalMessages} 条消息${g.deduplicatedMessages ? `（去重 ${g.deduplicatedMessages} 条）` : ''}`
        )
        if (failedGroups.length > 0) {
          lines.push(`失败:${failedGroups.map(g => `${g.displayName}（${g.error || '未知错误'}）`).join('、')}`)
        }
        if (skipped.length > 0) {
          lines.push(`跳过:${skipped.map(s => s.fileName).join('、')}（每个聊天至少 2 个备份才会合并）`)
        }
        const formats = config.formats || []
        const formatLabel = formats.includes('json') && formats.includes('html')
          ? 'JSON 和 HTML'
          : formats.includes('json')
            ? 'JSON'
            : 'HTML'
        const message = `成功合并 ${result.sourceCount} 个备份文件，共 ${result.totalMessages} 条消息${result.deduplicatedMessages > 0 ? `（去重 ${result.deduplicatedMessages} 条）` : ''}\n\n${lines.join('\n')}\n\n每个聊天已生成 ${formatLabel} 文件`
        
        addNotification(
          'success',
          '合并完成',
          message,
          successGroups.map(g => ({
            label: `打开文件位置:${g.displayName}`,
            onClick: async () => {
              try {
                await fetch('/api/open-file-location', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ filePath: g.jsonPath || g.htmlPath })
                })
              } catch (error) {
                console.error('打开文件位置失败:', error)
              }
            }
          })),
          0 // 不自动关闭，需要用户手动关闭
        )
        setIsScheduledMergeDialogOpen(false)
      } else {
        removeNotification(loadingId)
        addNotification('error', '合并失败', data.error?.message || '未知错误')
      }
    } catch (error) {
      removeNotification(loadingId)
      addNotification('error', '合并失败', error instanceof Error ? error.message : '网络错误')
    }
  }

  // Issue #340：独立模式（start-standalone.bat 启动、没有 NapCat / QQ 登录态）
  // 下，/api/friends 和 /api/groups 只会回 503 STANDALONE_MODE，没必要发请求；
  // 「会话」一类需要登录态的页面也直接换成引导卡片。
  const isStandalone = systemInfo?.mode === "standalone"

  useEffect(() => {
    if (isStandalone) return
    // Issue #641：「导出任务」页的群聊集合也需要真实群列表，否则新建任务时群组
    // 选择器一直是空的，用户既搜不到也选不了自己的群。
    if ((activeTab === "sessions" || activeTab === "plans") && groups.length === 0 && friends.length === 0) {
      loadChatData()
    }
  }, [activeTab, groups.length, friends.length, loadChatData, isStandalone])

  useEffect(() => {
    if (!error) return
    // Issue #340：独立模式下 friends/groups 必然失败，错误文案里通常带
    // 「独立模式」或后端的 `STANDALONE_MODE` code，统一吞掉，避免连续弹两次
    // 红色 toast 把用户吓走。Sessions tab 上已经有专门的引导卡片说明。
    if (isStandalone && /独立模式|STANDALONE_MODE/i.test(error)) {
      setError(null)
      return
    }
    toast.error("发生错误", { description: error })
    setError(null)
  }, [error, setError, isStandalone])

  useEffect(() => {
    if (!scheduledError) return
    toast.error("定时任务错误", { description: scheduledError })
    setScheduledError(null)
  }, [scheduledError, setScheduledError])

  useEffect(() => {
    if (!chatHistoryError) return
    toast.error("聊天记录错误", { description: chatHistoryError })
    setChatHistoryError(null)
  }, [chatHistoryError, setChatHistoryError])

  useEffect(() => {
    if (!stickerPacksError) return
    toast.error("表情包错误", { description: stickerPacksError })
    setStickerPacksError(null)
  }, [stickerPacksError, setStickerPacksError])

  useEffect(() => {
    if (!resourceIndexError) return
    toast.error("资源索引错误", { description: resourceIndexError })
    setResourceIndexError(null)
  }, [resourceIndexError, setResourceIndexError])

  const getStatusText = (status: string) => {
    switch (status) {
      case "queued": return "排队中"
      case "pending": return "等待中"
      case "running": return "进行中"
      case "completed": return "已完成"
      case "failed": return "失败"
      case "cancelled": return "已停止"
      default: return "等待中"
    }
  }

  // 级联动画 variants（受 reduced-motion 影响）
  // 对于大列表（超过50项），禁用 stagger 动画以提升性能
  const hasLargeList = groups.length > 50 || friends.length > 50

  const taskStatsCacheRef = useRef<{
    size: number
    value: Record<string, SessionTaskStats>
  }>({ size: 0, value: {} })
  const taskStatsMap = useMemo<Record<string, SessionTaskStats>>(() => {
    const map: Record<string, SessionTaskStats> = {}
    let size = 0
    for (const t of tasks) {
      const uid = t.peer?.peerUid
      if (!uid || t.status !== 'completed') continue
      const type = t.peer.chatType === 2 ? 'group' : 'friend'
      const key = sessionTaskStatsKey(type, uid)
      let stats = map[key]
      if (!stats) {
        stats = {
          exportedMessageCount: 0,
          successfulExportCount: 0,
        }
        map[key] = stats
        size += 1
      }

      if (typeof t.messageCount === 'number') {
        stats.exportedMessageCount += t.messageCount
      }

      stats.successfulExportCount += 1
      const completedAt = Date.parse(t.completedAt ?? t.createdAt)
      if (
        Number.isFinite(completedAt) &&
        (stats.lastSuccessfulExportAt === undefined ||
          completedAt > stats.lastSuccessfulExportAt)
      ) {
        stats.lastSuccessfulExportAt = completedAt
      }
    }

    const previous = taskStatsCacheRef.current
    if (previous.size === size) {
      let unchanged = true
      for (const key in map) {
        const stats = map[key]
        const old = previous.value[key]
        if (!(
          old?.exportedMessageCount === stats.exportedMessageCount &&
          old.successfulExportCount === stats.successfulExportCount &&
          old.lastSuccessfulExportAt === stats.lastSuccessfulExportAt
        )) {
          unchanged = false
          break
        }
      }
      if (unchanged) {
        return previous.value
      }
    }

    taskStatsCacheRef.current = { size, value: map }
    return map
  }, [tasks])
  const STAG = useMemo(() => makeStagger(reduceMotion || hasLargeList ? 0 : 0.06, reduceMotion || hasLargeList), [reduceMotion, hasLargeList])
  const SIDEBAR_WIDTH = 240
  // Issue #641：导出任务管理面板（通过 ref 触发「新建导出任务」向导）
  const exportPlansPanelRef = useRef<import("@/components/export-plans/plans-panel").ExportTaskPlansPanelHandle>(null)

  const sidebarTransition = useMemo(
    () => reduceMotion
      ? { duration: DUR.fast, ease: EASE.out }
      : { type: "spring" as const, stiffness: 260, damping: 30, mass: 0.9 },
    [reduceMotion],
  )
  const sidebarContentTransition = useMemo(
    () => reduceMotion
      ? { duration: DUR.fast, ease: EASE.out }
      : { type: "spring" as const, stiffness: 320, damping: 32, mass: 0.82, delay: 0.03 },
    [reduceMotion],
  )
  const onboardingTransition = useMemo(
    () => reduceMotion
      ? { duration: DUR.fast, ease: EASE.out }
      : { type: "spring" as const, stiffness: 340, damping: 28, mass: 0.84 },
    [reduceMotion],
  )

  const getAnchoredOnboardingPosition = useCallback((targetId: string, width: number) => {
    if (typeof window === "undefined") return null
    const targetEl = document.getElementById(targetId)
    if (!targetEl) return null

    const rect = targetEl.getBoundingClientRect()
    const gutter = 16
    const left = Math.min(
      Math.max(rect.right + 16, gutter),
      window.innerWidth - width - gutter,
    )
    const top = Math.min(
      Math.max(rect.top + rect.height / 2 - 64, gutter),
      window.innerHeight - 164,
    )

    return { left, top }
  }, [])

  const getBottomOnboardingPosition = useCallback((width: number) => {
    if (typeof window === "undefined") return null
    const gutter = 16
    return {
      left: Math.max((window.innerWidth - width) / 2, gutter),
      top: Math.max(window.innerHeight - 168, gutter),
    }
  }, [])

  // Navigation items configuration
  const navItems = [
    { id: "overview", label: "概览", icon: Activity },
    { id: "sessions", label: "会话", icon: MessageCircle },
    { id: "tasks", label: "任务", icon: Zap },
    { id: "plans", label: "导出任务", icon: Layers },
    { id: "scheduled", label: "定时导出", icon: Clock },
    { id: "history", label: "聊天记录", icon: History },
    { id: "stickers", label: "表情包", icon: Smile },
  ]

  const navItemsBottom = [
    { id: "settings", label: "设置", icon: Settings },
    { id: "about", label: "关于", icon: HelpCircle },
  ]

  // Page titles mapping
  const pageTitles: Record<string, string> = {
    overview: "概览",
    sessions: "会话",
    tasks: "任务",
    plans: "导出任务",
    scheduled: "定时导出",
    history: "聊天记录",
    stickers: "表情包",
    settings: "设置",
    about: "关于",
  }
  const onboardingPanelClass = "relative overflow-hidden rounded-[24px] bg-background/95 px-5 py-4 text-foreground shadow-[0_24px_80px_rgba(15,23,42,0.22)] backdrop-blur-2xl "
  const onboardingPrimaryButtonClass = "w-full rounded-full bg-blue-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-blue-700"
  const onboardingSecondaryButtonClass = "w-full rounded-full px-4 py-2 text-xs text-muted-foreground transition-colors hover:text-foreground"

  return (
    <div className="flex h-screen w-full bg-background font-sans antialiased overflow-hidden">
      {/* Mobile sidebar overlay */}
      <AnimatePresence>
        {sidebarMobileOpen && (
          <motion.div
            initial={{ opacity: 0, backdropFilter: "blur(0px)" }}
            animate={{ opacity: 1, backdropFilter: "blur(10px)" }}
            exit={{ opacity: 0, backdropFilter: "blur(0px)" }}
            transition={sidebarTransition}
            className="fixed inset-0 z-40 bg-black/24 md:hidden"
            onClick={() => setSidebarMobileOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <AnimatePresence initial={false}>
        {(sidebarOpen || sidebarMobileOpen) && (
          <motion.div
            initial={{ width: 0, opacity: 0, filter: "blur(10px)" }}
            animate={{ width: SIDEBAR_WIDTH, opacity: 1, filter: "blur(0px)" }}
            exit={{ width: 0, opacity: 0, filter: "blur(12px)" }}
            transition={sidebarTransition}
            className={`h-full flex flex-col flex-shrink-0 overflow-hidden select-none ${
              sidebarMobileOpen ? 'fixed left-0 top-0 z-50 bg-background/95 shadow-[0_24px_80px_rgba(15,23,42,0.22)] backdrop-blur-2xl' : 'relative'
            }`}
          >
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={sidebarContentTransition}
              className="w-[240px] h-full flex flex-col"
            >
              {/* Sidebar header */}
              <div data-tauri-drag-region className="flex items-center px-4 h-14 flex-shrink-0">
                {systemInfo?.napcat.selfInfo ? (
                  <AccountMenu>
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Avatar className="w-7 h-7 flex-shrink-0 rounded-full">
                      <AvatarImage
                        src={
                          systemInfo.napcat.selfInfo.uin
                            ? `http://q.qlogo.cn/g?b=qq&nk=${systemInfo.napcat.selfInfo.uin}&s=100`
                            : "/static/qce/qce-logo.png"
                        }
                        className="rounded-full"
                      />
                      <AvatarFallback className="text-[11px] rounded-full">
                        {systemInfo.napcat.selfInfo.nick?.[0] || "Q"}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-[13px] font-semibold text-foreground truncate">
                      {systemInfo.napcat.selfInfo.nick || "QQ Chat Exporter"}
                    </span>
                  </div>
                  </AccountMenu>
                ) : (
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-full bg-black/[0.04] dark:bg-white/[0.06] animate-pulse" />
                    <div className="w-20 h-3.5 bg-black/[0.04] dark:bg-white/[0.06] rounded animate-pulse" />
                  </div>
                )}
                <WindowDragRegion />
              </div>

              {/* Main nav */}
              <motion.div
                className="flex-1 overflow-y-auto px-2 py-1"
                variants={STAG.container}
                initial="initial"
                animate="animate"
              >
                <div className="space-y-0.5">
                  {navItems.map((item) => {
                    const isActive = activeTab === item.id
                    const Icon = item.icon
                    return (
                      <motion.button
                        key={item.id}
                        variants={STAG.item}
                        id={`nav-${item.id}`}
                        onClick={() => setActiveTab(item.id)}
                        className={`w-full flex items-center gap-2.5 px-2 py-[6px] text-[13px] font-medium rounded-lg transition-colors ${
                          isActive 
                            ? "text-foreground bg-black/[0.05] dark:bg-white/[0.05]" 
                            : "text-muted-foreground hover:text-foreground hover:bg-black/[0.04] dark:hover:bg-white/[0.04]"
                        } ${highlightedNav === item.id ? "ring-2 ring-black/10 dark:ring-white/14 ring-offset-2 ring-offset-background" : ""}`}
                      >
                        <Icon className="w-4 h-4 flex-shrink-0" />
                        <span className="truncate">{item.label}</span>
                        {item.id === "tasks" && getTaskStats().running > 0 && (
                          <Loader size={12} className="ml-auto text-blue-600 dark:text-blue-400" />
                        )}
                      </motion.button>
                    )
                  })}
                </div>

                <div className="mt-4 mb-1 px-2">
                  <span className="text-[11px] font-medium text-muted-foreground/60 uppercase tracking-wider">系统</span>
                </div>
                <div className="space-y-0.5">
                  {navItemsBottom.map((item) => {
                    const isActive = activeTab === item.id
                    const Icon = item.icon
                    return (
                      <motion.button
                        key={item.id}
                        variants={STAG.item}
                        id={`nav-${item.id}`}
                        onClick={() => setActiveTab(item.id)}
                        className={`w-full flex items-center gap-2.5 px-2 py-[6px] text-[13px] font-medium rounded-lg transition-colors ${
                          isActive 
                            ? "text-foreground bg-black/[0.05] dark:bg-white/[0.05]" 
                            : "text-muted-foreground hover:text-foreground hover:bg-black/[0.04] dark:hover:bg-white/[0.04]"
                        }`}
                      >
                        <Icon className="w-4 h-4 flex-shrink-0" />
                        <span className="truncate">{item.label}</span>
                      </motion.button>
                    )
                  })}
                </div>
              </motion.div>

              {/* Sidebar footer + 新版本更新卡片（锚定该行正上方，检测到新版本自动弹出） */}
              <div className="flex-shrink-0 px-2 pb-2 space-y-1">
                <UpdatePopover update={updateInfo}>
                <div className="flex items-center justify-between px-2 py-1">
                  {/* GitHub + star count */}
                  <a
                    href="https://github.com/shuakami/qq-chat-exporter"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 h-8 px-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-black/[0.04] dark:hover:bg-white/[0.04] transition-colors"
                  >
                    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                    </svg>
                    {githubStars !== null && (
                      <span className="text-[12px] font-medium tabular-nums">
                        {githubStars >= 1000 ? `${(githubStars / 1000).toFixed(1)}k` : githubStars}
                      </span>
                    )}
                  </a>

                  <div className="flex items-center gap-0.5">
                    {/* Help dropdown (docs) */}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button
                          className="relative inline-flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-black/[0.04] dark:hover:bg-white/[0.04] transition-colors"
                          aria-label={updateInfo ? `帮助，有新版本 ${updateInfo.tag}` : '帮助'}
                        >
                          <HelpCircle className="w-4 h-4" />
                          {updateInfo && (
                            <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-red-500 ring-2 ring-card" />
                          )}
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="rounded-xl border-black/[0.06] dark:border-white/[0.08] shadow-xl min-w-[220px]">
                        {updateInfo && (
                          <>
                            <DropdownMenuItem asChild>
                              <a
                                href={updateInfo.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex cursor-pointer flex-col items-start gap-0.5 py-2"
                              >
                                <span className="text-[13px] font-medium text-foreground">发现新版本</span>
                                <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                                  <span>{updateInfo.tag}</span>
                                  <span>查看更新内容</span>
                                </span>
                              </a>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                          </>
                        )}
                        <DropdownMenuItem asChild>
                          <a
                            href="https://shuakami.github.io/qq-chat-exporter/"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2 cursor-pointer"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>使用文档</span>
                          </a>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <a
                            href="https://github.com/shuakami/qq-chat-exporter/releases"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2 cursor-pointer"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>Release</span>
                          </a>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>

                    {/* Theme toggle */}
                    <ThemeToggle />
                  </div>
                </div>
                </UpdatePopover>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden sm:m-2 sm:rounded-xl sm:border sm:border-black/[0.05] sm:shadow-[0_2px_8px_rgba(0,0,0,0.015)] bg-card dark:border-white/[0.06]">
        {/* Page header bar; doubles as the window drag region in the desktop shell */}
        <div data-tauri-drag-region className="flex flex-shrink-0 items-center justify-between border-b border-black/[0.06] dark:border-white/[0.06] px-4 h-12">
          <div className="flex items-center gap-2 text-[14px]">
            <button
              onClick={() => {
                if (window.innerWidth < 768) {
                  setSidebarMobileOpen(!sidebarMobileOpen)
                } else {
                  setSidebarOpen(!sidebarOpen)
                }
              }}
              className="p-1 -ml-1 rounded-full text-muted-foreground/60 hover:text-muted-foreground hover:bg-black/[0.04] dark:hover:bg-white/[0.04] transition-colors"
            >
              {sidebarOpen ? <PanelLeftClose className="w-4 h-4" /> : <PanelLeftOpen className="w-4 h-4" />}
            </button>
            <span className="font-medium text-muted-foreground">QCE</span>
            <span className="text-muted-foreground/30">/</span>
            <span className="font-semibold text-foreground">{pageTitles[activeTab] || activeTab}</span>
          </div>
          <WindowDragRegion />
          <div className="flex items-center gap-2">
            {/* Page-specific actions */}

            {activeTab === "sessions" && !isStandalone && (
              <>
                <Button size="sm" variant="ghost" className="h-8 text-[13px] rounded-full px-2" onClick={loadChatData} disabled={isLoading}>
                  {isLoading ? <Loader size={16} /> : <RefreshCw className="w-4 h-4" />}
                </Button>
                {!batchMode && (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-8 text-[13px] rounded-full px-2.5"
                    onClick={handleToggleBatchMode}
                  >
                    批量选择
                  </Button>
                )}
              </>
            )}
            {activeTab === "tasks" && (
              <>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-8 text-[13px] rounded-full px-2"
                  aria-label="导出格式说明"
                  onClick={() => {
                    setHelpFilePath('')
                    setExportHelpFormat('html')
                    setExportHelpOpen(true)
                  }}
                >
                  <HelpCircle className="w-4 h-4" />
                </Button>
                <Button size="sm" variant="ghost" className="h-8 text-[13px] rounded-full px-2" onClick={handleLoadTasks} disabled={isLoading}>
                  {isLoading ? <Loader size={16} /> : <RefreshCw className="w-4 h-4" />}
                </Button>
                <Button size="sm" className="h-8 text-[13px] rounded-full px-2.5" onClick={() => handleOpenTaskWizard()}>
                  新建任务
                </Button>
              </>
            )}
            {activeTab === "plans" && (
              <Button
                size="sm"
                className="h-8 text-[13px] rounded-full px-2.5"
                onClick={() => exportPlansPanelRef.current?.openCreateWizard()}
              >
                新建导出任务
              </Button>
            )}
            {activeTab === "scheduled" && (
              <>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-8 text-[13px] rounded-full px-2"
                  onClick={handleLoadScheduledExports}
                  disabled={scheduledLoading}
                >
                  {scheduledLoading ? <Loader size={16} /> : <RefreshCw className="w-4 h-4" />}
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-8 text-[13px] rounded-full px-2.5"
                  onClick={handleOpenScheduledMergeDialog}
                  disabled={loadingScheduledTasks}
                >
                  合并
                </Button>
                {scheduledExports.length > 0 && !scheduledBatchMode && (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-8 text-[13px] rounded-full px-2.5"
                    onClick={handleToggleScheduledBatchMode}
                  >
                    批量选择
                  </Button>
                )}
                <Button size="sm" className="h-8 text-[13px] rounded-full px-2.5" onClick={() => handleOpenScheduledExportWizard()}>
                  新建定时任务
                </Button>
              </>
            )}
            {activeTab === "history" && (
              <>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-8 text-[13px] rounded-full px-2"
                  onClick={async () => {
                    chatHistoryLoadedRef.current = false
                    resourceIndexLoadedRef.current = false
                    await Promise.all([handleLoadChatHistory(), loadResourceIndex()])
                    chatHistoryLoadedRef.current = true
                    resourceIndexLoadedRef.current = true
                  }}
                  disabled={chatHistoryLoading || resourceIndexLoading}
                >
                  {(chatHistoryLoading || resourceIndexLoading) ? <Loader size={16} /> : <RefreshCw className="w-4 h-4" />}
                </Button>
                {/* Issue #163: 在「聊天记录」页也可以打开合并对话框，覆盖手动导出场景。 */}
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-8 text-[13px] rounded-full px-2.5"
                  onClick={handleOpenScheduledMergeDialog}
                  disabled={loadingScheduledTasks}
                >
                  合并
                </Button>
              </>
            )}
            {activeTab === "stickers" && (
              <>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-8 text-[13px] rounded-full px-2"
                  onClick={async () => {
                    stickerPacksLoadedRef.current = false
                    try {
                      await Promise.all([loadStickerPacks(), loadStickerExportRecords()])
                      stickerPacksLoadedRef.current = true
                    } catch (error) {
                      console.error('[QCE] 刷新表情包失败:', error)
                      stickerPacksLoadedRef.current = false
                    }
                  }}
                  disabled={stickerPacksLoading || stickerPacksExporting}
                >
                  {stickerPacksLoading ? <Loader size={16} /> : <RefreshCw className="w-4 h-4" />}
                </Button>
                <Button
                  size="sm"
                  className="h-8 text-[13px] rounded-full px-2.5"
                  onClick={handleExportAllStickerPacks}
                  disabled={stickerPacksLoading || stickerPacksExporting || stickerPacks.length === 0}
                >
                  导出所有
                </Button>
              </>
            )}
            <WindowControls />
          </div>
        </div>

        {/* Public-exposure security warning (shown above all tabs) */}
        <SecurityExposureBanner />

        {/* Content area */}
        <div className="flex-1 overflow-auto">
          <>
            {/* ==================== OVERVIEW ==================== */}
            {activeTab === "overview" && (
              <div className="p-6 space-y-6">
                {/* User info card */}
                {systemInfo?.napcat.selfInfo && (
                  <div className="flex items-center gap-4">
                    <Avatar className="w-12 h-12 rounded-full">
                      <AvatarImage
                        src={
                          systemInfo.napcat.selfInfo.uin
                            ? `http://q.qlogo.cn/g?b=qq&nk=${systemInfo.napcat.selfInfo.uin}&s=100`
                            : "/static/qce/qce-logo.png"
                        }
                        className="rounded-full"
                      />
                      <AvatarFallback className="rounded-full text-sm">
                        {systemInfo.napcat.selfInfo.nick?.[0] || "Q"}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h2 className="text-lg font-semibold text-foreground">
                        {systemInfo.napcat.selfInfo.nick || "QQ Chat Exporter"}
                      </h2>
                      <div className="flex items-center gap-2 mt-0.5 text-sm text-muted-foreground">
                        {systemInfo.napcat.selfInfo.uin ? (
                          <span>QQ {systemInfo.napcat.selfInfo.uin}</span>
                        ) : (
                          <span>独立模式 · 未登录 QQ</span>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Stats row */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="rounded-xl p-4">
                    <div className="text-sm text-muted-foreground">导出任务</div>
                    <div className="text-2xl font-semibold tracking-tight mt-1">{getTaskStats().total}</div>
                    <div className="text-xs text-muted-foreground/60 mt-1">
                      进行中 {getTaskStats().running}{INLINE_DIVIDER}完成 {getTaskStats().completed}
                    </div>
                  </div>
                  <div className="rounded-xl p-4">
                    <div className="text-sm text-muted-foreground">群组</div>
                    <div className="text-2xl font-semibold tracking-tight mt-1">{groups.length}</div>
                  </div>
                  <div className="rounded-xl p-4">
                    <div className="text-sm text-muted-foreground">好友</div>
                    <div className="text-2xl font-semibold tracking-tight mt-1">{friends.length}</div>
                  </div>
                </div>

                {/* Quick actions */}
                <div className="flex items-center gap-3">
                  <Button onClick={() => handleOpenTaskWizard()} className="rounded-full">
                    新建任务
                  </Button>
                  <Button variant="outline" onClick={() => setActiveTab("sessions")} className="rounded-full">
                    浏览会话
                  </Button>
                  <Button variant="outline" onClick={() => setActiveTab("tasks")} className="rounded-full">
                    查看任务
                  </Button>
                </div>

                {/* Recent tasks */}
                {tasks.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-sm font-medium text-foreground">最近任务</h3>
                      <button
                        onClick={() => setActiveTab("tasks")}
                        className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                      >
                        查看全部
                      </button>
                    </div>
                    <div className="rounded-xl divide-y divide-black/[0.04] dark:divide-white/[0.04] overflow-hidden">
                      {tasks.slice(0, 5).map((task) => (
                        <div
                          key={task.id}
                          className="flex items-center justify-between px-4 py-3 hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors"
                        >
                          <div className="min-w-0 flex-1 flex items-center gap-3">
                            <span className="text-sm font-medium text-foreground truncate">{task.sessionName}</span>
                            <Badge
                              className={`text-[11px] px-1.5 py-0 rounded-full border-0 ${
                                task.status === "completed"
                                  ? "text-green-700 bg-green-50 dark:text-green-300 dark:bg-green-950/40"
                                  : isActiveExportTaskStatus(task.status)
                                  ? "text-blue-700 bg-blue-50 dark:text-blue-300 dark:bg-blue-950/40"
                                  : task.status === "failed"
                                  ? "text-red-700 bg-red-50 dark:text-red-300 dark:bg-red-950/40"
                                  : task.status === "cancelled"
                                  ? "text-zinc-700 bg-zinc-100 dark:text-zinc-300 dark:bg-zinc-800"
                                  : ""
                              }`}
                            >
                              {getStatusText(task.status)}
                            </Badge>
                            {task.taskKind === "roaming_export" && (
                              <Badge className="border-0 bg-violet-500/10 px-1.5 py-0 text-[11px] text-violet-700 dark:text-violet-300">
                                漫游
                              </Badge>
                            )}
                            {task.taskKind === "roaming_export" && task.roamingScan?.partial && (
                              <Badge className="border-0 bg-amber-500/10 px-1.5 py-0 text-[11px] text-amber-700 dark:text-amber-300">
                                结果可能不完整
                              </Badge>
                            )}
                            <TaskFormatLabel format={task.format} className="text-xs text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">{new Date(task.createdAt).toLocaleDateString()}</span>
                            {task.messageCount !== undefined && task.messageCount > 0 && (
                              <span className="text-xs text-muted-foreground">{task.messageCount.toLocaleString()} 条</span>
                            )}
                          </div>
                          <div className="ml-4 flex items-center gap-2 flex-shrink-0">
                            {isActiveExportTaskStatus(task.status) && (
                              <>
                                <Progress value={task.progress} shimmer={true} className="w-20 h-1.5 rounded-full" />
                                <span className="text-xs text-muted-foreground font-medium tabular-nums">{task.progress}%</span>
                              </>
                            )}
                            {task.status === "completed" && (
                              <>
                                <Button size="sm" variant="ghost" className="h-8 rounded-lg px-2" onClick={() => openTaskFileLocation(task)} title="打开文件位置">
                                  <FolderOpen className="w-4 h-4" />
                                </Button>
                                <Button size="sm" variant="ghost" className="h-8 rounded-lg px-2" onClick={() => downloadTask(task)} title={isJsonlExport(task) ? "打开文件夹" : "下载"}>
                                  {isJsonlExport(task) ? <FolderOpen className="w-4 h-4" /> : <Download className="w-4 h-4" />}
                                </Button>
                              </>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* ==================== SESSIONS ==================== */}
            {activeTab === "sessions" && (
              <div className="px-4 pt-2 pb-5 space-y-2">
                {/* Issue #340：独立模式下没有 NapCat / QQ 登录态，无法拉群组和好友列表。
                    用一张引导卡片替换原来的 SessionList，避免红色错误 toast 把用户吓退。 */}
                {isStandalone ? (
                  <div
                    data-testid="sessions-standalone-banner"
                    className="rounded-xl bg-card p-6 space-y-4"
                  >
                    <div className="space-y-1.5 min-w-0">
                      <h3 className="text-[15px] font-semibold text-foreground">
                        独立模式：仅可浏览已导出的内容
                      </h3>
                      <p className="text-[13px] text-muted-foreground/80 leading-relaxed">
                        独立模式下暂时无法预览群聊、好友列表。如需导出新记录，请用完整模式启动并登录 QQ。
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2 pt-1">
                      <Button
                        size="sm"
                        variant="default"
                        className="h-8 text-[13px] rounded-full px-3"
                        onClick={() => setActiveTab("history")}
                      >
                        浏览聊天记录
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 text-[13px] rounded-full px-3"
                        onClick={() => setActiveTab("stickers")}
                      >
                        表情包
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    {batchMode && (
                      <div className="text-[13px] text-muted-foreground px-1">
                        已选择 {selectedItems.size} 个会话
                      </div>
                    )}
                    <SessionList
                      groups={groups}
                      friends={friends}
                      isLoading={isLoading}
                      batchMode={batchMode}
                      selectedItems={selectedItems}
                      avatarExportLoading={avatarExportLoading}
                      recentActivityMap={recentActivityMap}
                      taskStatsMap={taskStatsMap}
                      onRefresh={loadChatData}
                      onToggleBatchMode={handleToggleBatchMode}
                      onSelectAll={handleSelectAll}
                      onClearSelection={handleClearSelection}
                      onToggleItem={handleToggleItem}
                      onSelectMany={handleSelectMany}
                      onOpenBatchExportDialog={handleOpenBatchExportDialog}
                      onPreviewChat={handlePreviewChat}
                      onOpenTaskWizard={handleOpenTaskWizard}
                      onExportGroupAvatars={handleExportGroupAvatars}
                      onOpenEssenceModal={handleOpenEssenceModal}
                      onOpenGroupFilesModal={handleOpenGroupFilesModal}
                    />
                  </>
                )}
              </div>
            )}

            {/* ==================== TASKS ==================== */}
            {activeTab === "tasks" && (
              <div className="p-6 space-y-1">
                {tasks.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-20 text-center">
                    <Zap className="w-8 h-8 text-muted-foreground/20 mb-3" />
                    <p className="text-sm text-foreground font-medium">暂无导出任务</p>
                    <p className="text-xs text-muted-foreground/60 mt-1">从「会话」中选择一个会话来创建任务</p>
                  </div>
                ) : (
                  tasks.map((task) => (
                    <div
                      key={task.id}
                      className="flex items-center justify-between px-4 py-3.5 text-sm rounded-lg hover:bg-black/[0.03] dark:hover:bg-white/[0.03] transition-colors group"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-foreground truncate">{task.sessionName}</span>
                          <Badge
                            className={`text-[11px] px-1.5 py-0 rounded-full border-0 ${
                              task.status === "completed"
                                ? "text-green-700 bg-green-50 dark:text-green-300 dark:bg-green-950/40"
                                : isActiveExportTaskStatus(task.status)
                                ? "text-blue-700 bg-blue-50 dark:text-blue-300 dark:bg-blue-950/40"
                                : task.status === "failed"
                                ? "text-red-700 bg-red-50 dark:text-red-300 dark:bg-red-950/40"
                                : task.status === "cancelled"
                                ? "text-zinc-700 bg-zinc-100 dark:text-zinc-300 dark:bg-zinc-800"
                                : ""
                            }`}
                          >
                            {getStatusText(task.status)}
                          </Badge>
                          {task.taskKind === "roaming_export" && (
                            <Badge className="border-0 bg-violet-500/10 px-1.5 py-0 text-[11px] text-violet-700 dark:text-violet-300">
                              漫游
                            </Badge>
                          )}
                          {task.taskKind === "roaming_export" && task.roamingScan?.partial && (
                            <Badge className="border-0 bg-amber-500/10 px-1.5 py-0 text-[11px] text-amber-700 dark:text-amber-300">
                              结果可能不完整
                            </Badge>
                          )}
                        </div>
                        <div className="mt-0.5 flex flex-wrap items-center gap-3 text-xs text-muted-foreground/50">
                          {formatTaskPeerLabel(task.peer) && (
                            <span className="font-mono">{formatTaskPeerLabel(task.peer)}</span>
                          )}
                          <TaskFormatLabel format={task.format} />
                          <span>{new Date(task.createdAt).toLocaleDateString()}</span>
                          {task.messageCount !== undefined &&
                            (task.messageCount > 0 || task.taskKind === "roaming_export") && (
                            <span className="inline-flex items-center gap-1 whitespace-nowrap">
                              <span>{task.messageCount.toLocaleString()} 条消息</span>
                              {task.status === "completed" && task.resourceSummary && task.resourceSummary.failed > 0 && (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <button
                                      type="button"
                                      className="inline-flex h-4 w-4 items-center justify-center rounded-full text-muted-foreground/60 outline-none transition-colors hover:bg-amber-500/10 hover:text-amber-700 focus-visible:ring-2 focus-visible:ring-ring dark:hover:text-amber-400"
                                      aria-label="查看资源下载统计"
                                    >
                                      <HelpCircle className="h-3.5 w-3.5" />
                                    </button>
                                  </TooltipTrigger>
                                  <TooltipContent side="top" sideOffset={6} className="max-w-72">
                                    <div className="space-y-1">
                                      <div className="font-medium">
                                        资源 {(task.resourceSummary.alreadyAvailable + task.resourceSummary.downloaded)}/{task.resourceSummary.attempted}
                                        ，失败 {task.resourceSummary.failed}
                                        {task.resourceSummary.skipped > 0 && `，跳过 ${task.resourceSummary.skipped}`}
                                      </div>
                                      <div className="text-xs opacity-80">
                                        部分资源因 QQ Rkey 服务临时不可用而下载失败，文字内容不受影响；可在 QQ 客户端重新打开相关消息后重试。
                                      </div>
                                    </div>
                                  </TooltipContent>
                                </Tooltip>
                              )}
                            </span>
                          )}
                          {task.taskKind === "roaming_export" && task.roamingScan && (
                            <span className="inline-flex items-center gap-1 whitespace-nowrap">
                              <span>
                                已扫描 {task.roamingScan.scannedDays}/{task.roamingScan.requestedDays} 天
                              </span>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <button
                                    type="button"
                                    className="inline-flex h-4 w-4 items-center justify-center rounded-full text-muted-foreground/60 outline-none transition-colors hover:bg-violet-500/10 hover:text-violet-700 focus-visible:ring-2 focus-visible:ring-ring dark:hover:text-violet-300"
                                    aria-label="查看漫游扫描说明"
                                  >
                                    <HelpCircle className="h-3.5 w-3.5" />
                                  </button>
                                </TooltipTrigger>
                                <TooltipContent side="top" sideOffset={6} className="max-w-80">
                                  <div className="space-y-1">
                                    <div className="font-medium">
                                      日期锚点 {task.roamingScan.anchorDays} 个，逐序号核对 {task.roamingScan.sequenceQueries} 次
                                    </div>
                                    {!!task.roamingScan.emptySequenceQueries && (
                                      <div className="text-xs opacity-80">
                                        其中 {task.roamingScan.emptySequenceQueries} 个序号没有可读取消息，扫描已继续。
                                      </div>
                                    )}
                                    {!!task.roamingScan.calendarErrors && (
                                      <div className="text-xs opacity-80">
                                        月历提示查询失败 {task.roamingScan.calendarErrors} 次；逐日扫描仍已继续。
                                      </div>
                                    )}
                                    <div className="text-xs opacity-80">
                                      {task.status === "queued" || task.status === "pending"
                                        ? "漫游任务正在等待开始扫描。"
                                        : task.status === "running"
                                          ? "有界漫游扫描正在进行中。"
                                        : task.roamingScan.partial
                                          ? `任务已按边界停止（${formatRoamingStopReason(task.roamingScan.stopReason)}），结果可能不完整。`
                                          : "任务已完成所选日期的有界扫描。"}
                                      腾讯接口不会证明服务端记录完整，请以当前账号和客户端实际可见结果为准。
                                    </div>
                                  </div>
                                </TooltipContent>
                              </Tooltip>
                            </span>
                          )}
                          {(task.startTime || task.endTime) && (
                            <span className="font-medium">
                              {task.startTime && task.endTime
                                ? `${new Date(task.startTime * 1000).toLocaleDateString()} ~ ${new Date(task.endTime * 1000).toLocaleDateString()}`
                                : task.startTime
                                ? `从 ${new Date(task.startTime * 1000).toLocaleDateString()}`
                                : `到 ${new Date(task.endTime! * 1000).toLocaleDateString()}`}
                            </span>
                          )}
                          {isActiveExportTaskStatus(task.status) && task.progressMessage && (
                            <span className="text-muted-foreground/40">{task.progressMessage}</span>
                          )}
                        </div>

                        {/* Running progress inline */}
                        {isActiveExportTaskStatus(task.status) && (
                          <div className="mt-1.5 flex items-center gap-2">
                            <Progress
                              value={task.progress}
                              shimmer={true}
                              className="h-1.5 rounded-full flex-1 max-w-[240px]"
                            />
                            <span className="text-xs font-medium text-muted-foreground/50 tabular-nums">{task.progress}%</span>
                          </div>
                        )}

                        {/* Error */}
                        {task.error && (
                          <div className="mt-1.5 text-xs text-red-600 dark:text-red-400">
                            {task.error}
                          </div>
                        )}

                      </div>

                      <div className="ml-3 flex items-center gap-1.5 flex-shrink-0">
                        {/* issue #446：运行中的任务可以停止，打断分页抓取，不必干等。 */}
                        {isActiveExportTaskStatus(task.status) && (
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-8 w-8 rounded-full p-0 text-muted-foreground/60 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30"
                            onClick={() => {
                              showDeleteConfirmationToast(
                                `停止任务「${task.sessionName}」？`,
                                "任务不会标记为完成；任务会尽快停止，正在执行的单次查询或写盘可能需要稍候，已写入磁盘的中间文件或结果文件可能保留",
                                async () => {
                                  const success = await cancelTask(task.id)
                                  if (!success) throw new Error("停止失败")
                                },
                              )
                            }}
                            title="停止"
                          >
                            <Square className="w-4 h-4" />
                          </Button>
                        )}
                        {task.status === "completed" && (
                          <>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8 w-8 rounded-full p-0"
                              onClick={() => openTaskFileLocation(task)}
                              title="打开文件位置"
                            >
                              <FolderOpen className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8 w-8 rounded-full p-0"
                              onClick={() => downloadTask(task)}
                              title={isJsonlExport(task) ? "打开文件夹" : "下载"}
                            >
                              {isJsonlExport(task) ? <FolderOpen className="w-4 h-4" /> : <Download className="w-4 h-4" />}
                            </Button>
                          </>
                        )}
                        {(task.status === "completed" || task.status === "failed" || task.status === "cancelled") && (
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-8 w-8 rounded-full p-0 text-muted-foreground/50 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30"
                            onClick={() => {
                              showDeleteConfirmationToast(`删除任务「${task.sessionName}」？`, "此操作不可撤销", async () => {
                                const success = await deleteTask(task.id)
                                if (!success) throw new Error("删除失败")
                                tasksLoadedRef.current = false
                              })
                            }}
                            title="删除"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* ==================== EXPORT TASK PLANS (Issue #641) ==================== */}
            {activeTab === "plans" && (
              <Suspense fallback={<div className="flex items-center justify-center py-20"><Loader size={24} /></div>}>
                <ExportTaskPlansPanel ref={exportPlansPanelRef} groups={groups} />
              </Suspense>
            )}

            {/* ==================== SCHEDULED ==================== */}
            {activeTab === "scheduled" && (
              <div className="p-5 space-y-4 max-w-4xl mx-auto w-full">
                {/* Filter Tabs */}
                {scheduledExports.length > 0 && (
                  <div className="flex flex-wrap items-center gap-3 px-1">
                    <div className="flex items-center gap-1">
                      {[
                        { id: 'all', label: `全部 ${getScheduledStats().total}` },
                        { id: 'enabled', label: `启用 ${getScheduledStats().enabled}` },
                        { id: 'disabled', label: `禁用 ${getScheduledStats().disabled}` },
                      ].map(tab => {
                        const isActive = scheduledFilter === tab.id
                        return (
                          <button
                            key={tab.id}
                            onClick={() => setScheduledFilter(tab.id as typeof scheduledFilter)}
                            className={`px-3 py-1.5 rounded-full text-[12px] font-medium transition-colors ${
                              isActive
                                ? 'bg-black/[0.06] dark:bg-white/[0.08] text-foreground'
                                : 'text-muted-foreground/70 hover:text-foreground'
                            }`}
                          >
                            {tab.label}
                          </button>
                        )
                      })}
                    </div>

                  </div>
                )}

                {/* List */}
                {scheduledExports.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-20 text-center">
                    <Clock className="w-8 h-8 text-muted-foreground/20 mb-3" />
                    <p className="text-[13px] text-foreground font-medium">暂无定时导出任务</p>
                    <p className="text-[12px] text-muted-foreground/60 mt-1">点击右上角「新建定时任务」开始</p>
                  </div>
                ) : (
                  <div className="space-y-1">
                    {filteredScheduledExports.map((scheduledExport, index, items) => {
                      const isSelected = selectedScheduledExportIds.has(scheduledExport.id)
                      const isPreviousSelected = index > 0 && selectedScheduledExportIds.has(items[index - 1].id)
                      const isNextSelected = index < items.length - 1 && selectedScheduledExportIds.has(items[index + 1].id)
                      return (
                      <div
                        key={scheduledExport.id}
                        className={[
                          "group flex items-center justify-between px-3 py-2.5 transition-colors",
                          scheduledBatchMode
                            ? isSelected
                              ? "bg-black/[0.045] dark:bg-white/[0.075] cursor-pointer"
                              : "hover:bg-black/[0.03] dark:hover:bg-white/[0.03] cursor-pointer"
                            : "hover:bg-black/[0.03] dark:hover:bg-white/[0.03]",
                          isSelected && scheduledBatchMode
                            ? `${isPreviousSelected ? "rounded-t-none" : "rounded-t-xl"} ${isNextSelected ? "rounded-b-none" : "rounded-b-xl"}`
                            : "rounded-xl",
                        ].join(" ")}
                        onClick={() => {
                          if (scheduledBatchMode) handleToggleScheduledSelection(scheduledExport.id, !isSelected)
                        }}
                      >
                        <div className="flex items-center gap-3 min-w-0 flex-1">
                          <BatchSelectionCheckbox
                            visible={scheduledBatchMode}
                            checked={isSelected}
                            label={`选择定时任务 ${scheduledExport.name}`}
                            onCheckedChange={checked => handleToggleScheduledSelection(scheduledExport.id, checked)}
                          />
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2.5">
                              <span className="text-[13px] font-medium text-foreground truncate">
                                {scheduledExport.name}
                              </span>
                              <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${
                                scheduledExport.enabled 
                                  ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300' 
                                  : 'bg-black/[0.04] dark:bg-white/[0.04] text-muted-foreground/50'
                              }`}>
                                {scheduledExport.enabled ? "启用" : "禁用"}
                              </span>
                            </div>
                            <div className="flex items-center gap-3 mt-0.5 text-[11px] text-muted-foreground/50">
                              <span>
                                {scheduledExport.scheduleType === "daily" && "每天"}
                                {scheduledExport.scheduleType === "weekly" && "每周"}
                                {scheduledExport.scheduleType === "monthly" && "每月"}
                                {scheduledExport.scheduleType === "custom" && "自定义"}
                                {" "}
                                {scheduledExport.scheduleType === "custom" && scheduledExport.cronExpression
                                  ? scheduledExport.cronExpression
                                  : scheduledExport.executeTime}
                              </span>
                              {scheduledExport.nextRun && (
                                <span className="text-muted-foreground/40">
                                  下次 {new Date(scheduledExport.nextRun).toLocaleString("zh-CN", {
                                    month: "numeric",
                                    day: "numeric",
                                    hour: "2-digit",
                                    minute: "2-digit",
                                  })}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className={`items-center gap-1 flex-shrink-0 transition-opacity ${
                          scheduledBatchMode
                            ? 'hidden'
                            : selectedScheduledExportIds.has(scheduledExport.id) ? 'flex opacity-100' : 'flex opacity-0 group-hover:opacity-100'
                        }`}>
                          <button
                            className="px-2.5 py-1.5 text-[12px] font-medium text-muted-foreground/60 hover:text-foreground rounded-full hover:bg-black/[0.05] dark:hover:bg-white/[0.06] transition-colors"
                            onClick={() => handleEditScheduledExport(scheduledExport)}
                          >
                            编辑
                          </button>
                          <button
                            className="px-2.5 py-1.5 text-[12px] font-medium text-muted-foreground/60 hover:text-foreground rounded-full hover:bg-black/[0.05] dark:hover:bg-white/[0.06] transition-colors"
                            onClick={() => toggleScheduledExport(scheduledExport.id, !scheduledExport.enabled)}
                          >
                            {scheduledExport.enabled ? "禁用" : "启用"}
                          </button>
                          <button
                            className="px-2.5 py-1.5 text-[12px] font-medium text-muted-foreground/60 hover:text-foreground rounded-full hover:bg-black/[0.05] dark:hover:bg-white/[0.06] transition-colors"
                            onClick={() => triggerScheduledExport(scheduledExport.id)}
                          >
                            执行
                          </button>
                          <button
                            className="px-2.5 py-1.5 text-[12px] font-medium text-muted-foreground/60 hover:text-foreground rounded-full hover:bg-black/[0.05] dark:hover:bg-white/[0.06] transition-colors"
                            onClick={() => handleOpenHistoryModal(scheduledExport.id, scheduledExport.name)}
                          >
                            历史
                          </button>
                          <button
                            className="p-1.5 ml-1 text-muted-foreground/40 hover:text-red-500 rounded-full hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
                            onClick={() => {
                              showDeleteConfirmationToast(`删除定时任务「${scheduledExport.name}」？`, "此操作不可撤销", async () => {
                                const success = await deleteScheduledExport(scheduledExport.id)
                                if (!success) throw new Error("删除失败")
                                await loadScheduledExports()
                              })
                            }}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    )
                    })}
                  </div>
                )}

                <AnimatePresence>
                  {scheduledBatchMode && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.94 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.94 }}
                      transition={{ type: "spring", stiffness: 400, damping: 35, mass: 0.8 }}
                      className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50"
                    >
                      <div className="flex items-center gap-1 rounded-full bg-white/80 dark:bg-neutral-900/80 backdrop-blur-xl shadow-[0_8px_32px_rgba(0,0,0,0.08)] border border-black/[0.06] dark:border-white/[0.08] px-2 py-1.5">
                        <span className="text-[13px] font-medium text-foreground px-3 tabular-nums">
                          已选择 {selectedScheduledExportIds.size} 项
                        </span>
                        {selectedScheduledExportIds.size > 0 && (
                          <button
                            onClick={() => setSelectedScheduledExportIds(new Set())}
                            className="px-2 py-0.5 text-[12px] text-muted-foreground/60 hover:text-muted-foreground rounded-full hover:bg-black/[0.04] dark:hover:bg-white/[0.06] transition-colors mr-1"
                          >
                            清空
                          </button>
                        )}
                        <span className="w-px h-4 bg-black/[0.08] dark:bg-white/[0.1]" />
                        <button
                          onClick={() => handleToggleAllVisibleScheduled(!allVisibleScheduledSelected)}
                          className="px-3 py-1.5 text-[13px] text-muted-foreground hover:text-foreground rounded-full hover:bg-black/[0.04] dark:hover:bg-white/[0.06] transition-colors"
                        >
                          {allVisibleScheduledSelected ? "取消全选" : "全选当前"}
                        </button>
                        <span className="w-px h-4 bg-black/[0.08] dark:bg-white/[0.1]" />
                        <button
                          onClick={handleDisableSelectedScheduledExports}
                          disabled={selectedScheduledExportIds.size === 0 || scheduledLoading}
                          className="px-3 py-1.5 text-[13px] text-muted-foreground hover:text-foreground rounded-full hover:bg-black/[0.04] dark:hover:bg-white/[0.06] transition-colors disabled:opacity-40 disabled:pointer-events-none"
                        >
                          禁用
                        </button>
                        <button
                          onClick={handleDeleteSelectedScheduledExports}
                          disabled={selectedScheduledExportIds.size === 0 || scheduledLoading}
                          className="px-3 py-1.5 text-[13px] text-red-500 hover:text-red-600 rounded-full hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors disabled:opacity-40 disabled:pointer-events-none"
                        >
                          删除
                        </button>
                        <button
                          onClick={handleTriggerSelectedScheduledExports}
                          disabled={selectedScheduledExportIds.size === 0 || scheduledLoading}
                          className="px-4 py-1.5 text-[13px] font-medium text-white bg-[#317CFF] rounded-full hover:bg-[#2867d6] transition-colors disabled:opacity-40 disabled:pointer-events-none"
                        >
                          {scheduledLoading ? "执行中…" : "执行"}
                        </button>
                        <button
                          onClick={handleToggleScheduledBatchMode}
                          className="p-1.5 text-muted-foreground hover:text-foreground rounded-full hover:bg-black/[0.04] dark:hover:bg-white/[0.06] transition-colors ml-1"
                          aria-label="退出批量选择"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}

            {/* ==================== HISTORY ==================== */}
            {activeTab === "history" && (
              <div className="p-5 space-y-4">
                {/* Sub Tabs */}
                <div className="flex items-center justify-between gap-4 flex-wrap px-1">
                  <div className="flex items-center gap-0.5">
                    <button
                      onClick={() => setHistorySubTab('records')}
                      className={`px-2.5 py-1 rounded-full text-[12px] transition-colors ${
                        historySubTab === 'records'
                          ? 'bg-black/[0.05] dark:bg-white/[0.05] text-foreground font-medium'
                          : 'text-muted-foreground/60 hover:text-muted-foreground'
                      }`}
                    >
                      记录列表
                    </button>
                    <button
                      onClick={() => {
                        setHistorySubTab('gallery')
                      }}
                      className={`px-2.5 py-1 rounded-full text-[12px] transition-colors ${
                        historySubTab === 'gallery'
                          ? 'bg-black/[0.05] dark:bg-white/[0.05] text-foreground font-medium'
                          : 'text-muted-foreground/60 hover:text-muted-foreground'
                      }`}
                    >
                      资源画廊
                    </button>
                  </div>
                  <div className="flex items-center justify-end gap-3 text-[12px] text-muted-foreground/50">
                    <span>{getChatHistoryStats().total} 个文件</span>
                    {resourceIndex && (
                      <>
                        <span>{resourceIndex.summary.totalResources.toLocaleString()} 资源</span>
                        <span>{formatResourceSize(resourceIndex.summary.totalSize)}</span>
                      </>
                    )}
                  </div>
                </div>

                {/* Records View */}
                {historySubTab === 'records' && (
                  <>
                    {/* Filters Row */}
                    {chatHistoryFiles.length > 0 && (
                      <div className="flex items-center justify-between gap-4 flex-wrap px-1">
                        <div className="flex items-center gap-0.5">
                          {[
                            { id: 'all', label: '全部' },
                            { id: 'group', label: '群组' },
                            { id: 'friend', label: '好友' },
                          ].map(tab => {
                            const isActive = (historyFilter || 'all') === tab.id;
                            return (
                              <button
                                key={tab.id}
                                onClick={() => setHistoryFilter(tab.id as 'all' | 'group' | 'friend')}
                                className={`px-2 py-0.5 rounded-full text-[11px] transition-colors ${
                                  isActive 
                                    ? 'bg-black/[0.05] dark:bg-white/[0.05] text-foreground font-medium' 
                                    : 'text-muted-foreground/50 hover:text-muted-foreground'
                                }`}
                              >
                                {tab.label}
                              </button>
                            );
                          })}
                        </div>
                        <div className="flex items-center gap-0.5">
                          {[
                            { id: 'all', label: '全部格式' },
                            { id: 'html', label: 'HTML' },
                            { id: 'json', label: 'JSON' },
                            { id: 'zip', label: 'ZIP' },
                            { id: 'jsonl', label: 'JSONL' },
                          ].map(tab => {
                            const isActive = (historyFormatFilter || 'all') === tab.id;
                            return (
                              <button
                                key={tab.id}
                                onClick={() => setHistoryFormatFilter(tab.id as 'all' | 'html' | 'json' | 'zip' | 'jsonl')}
                                className={`px-2 py-0.5 rounded-full text-[11px] transition-colors ${
                                  isActive 
                                    ? 'bg-black/[0.05] dark:bg-white/[0.05] text-foreground font-medium' 
                                    : 'text-muted-foreground/50 hover:text-muted-foreground'
                                }`}
                              >
                                {tab.label}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Empty State */}
                    {chatHistoryFiles.length === 0 ? (
                      <div className="flex flex-col items-center justify-center py-20 text-center">
                        <MessageCircle className="w-8 h-8 text-muted-foreground/20 mb-3" />
                        <p className="text-[13px] text-foreground font-medium">暂无聊天记录</p>
                        <p className="text-[12px] text-muted-foreground/60 mt-1">完成导出任务后，记录将在此处显示</p>
                      </div>
                    ) : (
                      /* Flat file list */
                      <div className="space-y-0.5">
                        {chatHistoryFiles
                          .filter(file => {
                            if (historyFilter === 'group' && file.chatType !== 'group') return false;
                            if (historyFilter === 'friend' && file.chatType === 'group') return false;
                            if (historyFormatFilter && historyFormatFilter !== 'all') {
                              const ext = file.fileName.toLowerCase().split('.').pop();
                              const isHtml = ext === 'html' || ext === 'htm';
                              const isJson = ext === 'json';
                              const isZip = ext === 'zip';
                              const isJsonl = file.fileName.includes('_chunked_jsonl');
                              if (historyFormatFilter === 'html' && !isHtml) return false;
                              if (historyFormatFilter === 'json' && !isJson) return false;
                              if (historyFormatFilter === 'zip' && !isZip) return false;
                              if (historyFormatFilter === 'jsonl' && !isJsonl) return false;
                            }
                            return true;
                          })
                          .map((file) => {
                            const ext = file.fileName.toLowerCase().split('.').pop();
                            const isJsonl = file.fileName.includes('_chunked_jsonl');
                            const formatLabel = isJsonl ? 'JSONL' : ext === 'html' || ext === 'htm' ? 'HTML' : ext === 'json' ? 'JSON' : ext === 'zip' ? 'ZIP' : ext?.toUpperCase();
                            
                            const resourceInfo = resourceIndex?.exports.find(e => 
                              e.fileName === file.fileName || 
                              e.fileName === file.fileName.replace(/\.(html|json)$/i, '')
                            );
                            
                            return (
                              <div
                                key={file.fileName}
                                className="group flex items-center px-3 py-3 rounded-lg hover:bg-black/[0.03] dark:hover:bg-white/[0.03] transition-colors cursor-pointer"
                                onClick={() => handleOpenFilePathModal(file.filePath, file.displayName || file.sessionName || file.chatId, file.fileName, file.size)}
                              >
                                <Avatar className="w-9 h-9 rounded-full flex-shrink-0 mr-3">
                                  {file.avatarUrl && <AvatarImage src={file.avatarUrl} className="rounded-full" />}
                                  <AvatarFallback className="rounded-full bg-black/[0.02] dark:bg-white/[0.04] text-muted-foreground/40">
                                    {file.chatType === 'group' ? <Users className="w-4 h-4" /> : <User className="w-4 h-4" />}
                                  </AvatarFallback>
                                </Avatar>
                                <div className="min-w-0 flex-1">
                                  <span className="text-[13px] font-medium text-foreground truncate block">
                                    {file.displayName || file.sessionName || file.chatId}
                                  </span>
                                </div>
                                <div className="flex items-center gap-3 ml-3 flex-shrink-0 text-[11px] text-muted-foreground/40">
                                  {file.messageCount !== undefined && file.messageCount > 0 && (
                                    <span>{file.messageCount} 条</span>
                                  )}
                                  {resourceInfo && resourceInfo.resourceCount > 0 && (
                                    <span>{resourceInfo.resourceCount} 资源</span>
                                  )}
                                  <span>{new Date(file.createTime).toLocaleDateString()}</span>
                                  <span className="text-[10px] font-medium bg-black/[0.04] dark:bg-white/[0.04] px-1.5 py-0.5 rounded text-muted-foreground/50">
                                    {formatLabel}
                                  </span>
                                </div>
                                <button
                                  className="p-1 ml-1 rounded-full text-muted-foreground/20 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 opacity-0 group-hover:opacity-100 transition-all"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    showDeleteConfirmationToast(`删除这条记录？`, file.displayName || file.sessionName || file.chatId, async () => {
                                      const success = await deleteChatHistoryFile(file.fileName);
                                      if (!success) throw new Error("删除失败");
                                      chatHistoryLoadedRef.current = false;
                                    })
                                  }}
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            );
                          })}
                      </div>
                    )}
                  </>
                )}

                {/* Gallery View */}
                {historySubTab === 'gallery' && (
                  <div className="space-y-4">
                    {/* Gallery Type Filter */}
                    <div className="flex items-center gap-0.5 px-1">
                      {[
                        { id: 'all', label: '全部' },
                        { id: 'images', label: '图片' },
                        { id: 'videos', label: '视频' },
                        { id: 'audios', label: '音频' },
                        { id: 'files', label: '文件' },
                      ].map(tab => {
                        const isActive = galleryType === tab.id;
                        return (
                          <button
                            key={tab.id}
                            onClick={() => {
                              // 切类型后由 useEffect（依赖 galleryType / gallerySearchActive）
                              // 自动重新加载，避免和 effect 各打一次。
                              setGalleryType(tab.id as typeof galleryType)
                            }}
                            className={`px-2.5 py-1 rounded-full text-[12px] transition-colors ${
                              isActive 
                                ? 'bg-black/[0.05] dark:bg-white/[0.05] text-foreground font-medium' 
                                : 'text-muted-foreground/60 hover:text-muted-foreground'
                            }`}
                          >
                            {tab.label}
                          </button>
                        );
                      })}
                      <span className="text-[11px] text-muted-foreground/40 ml-2">
                        {resourceFilesTotal} 个
                      </span>
                    </div>

                    {/* issue #294 子项 1：文件名搜索。后端按子串过滤后再分页，
                        匹配数会跟着「N 个」一起变。 */}
                    <div className="px-1">
                      <div className="relative max-w-md">
                        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground/40" />
                        <input
                          type="text"
                          value={gallerySearchInput}
                          onChange={(e) => setGallerySearchInput(e.target.value)}
                          placeholder="按文件名搜索..."
                          className="w-full pl-8 pr-8 py-1.5 text-[12px] rounded-full bg-black/[0.02] dark:bg-white/[0.02] border border-transparent focus:border-black/[0.08] dark:focus:border-white/[0.08] focus:bg-black/[0.03] dark:focus:bg-white/[0.03] outline-none transition-colors"
                        />
                        {gallerySearchInput && (
                          <button
                            onClick={() => setGallerySearchInput('')}
                            className="absolute right-2 top-1/2 -translate-y-1/2 p-0.5 rounded text-muted-foreground/40 hover:text-muted-foreground transition-colors"
                            title="清空"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Loading */}
                    {resourceFilesLoading && resourceFiles.length === 0 && (
                      <div className="flex items-center justify-center py-20">
                        <Loader size={16} className="text-muted-foreground/40" />
                        <span className="ml-2 text-muted-foreground/50 text-[13px]">加载中...</span>
                      </div>
                    )}

                    {/* Gallery Grid */}
                    {resourceFiles.length > 0 && (
                      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-2">
                        {resourceFiles.map((file, idx) => (
                          <div
                            key={`${file.fileName}-${idx}`}
                            className="relative aspect-square rounded-lg overflow-hidden bg-black/[0.02] dark:bg-white/[0.02] cursor-pointer group hover:ring-2 hover:ring-black/[0.08] dark:hover:ring-white/[0.08] transition-all"
                            onClick={() => setPreviewResource({ type: file.type, url: file.url, name: file.fileName })}
                          >
                            {file.type === 'image' ? (
                              <img
                                src={file.url}
                                alt={file.fileName}
                                className="w-full h-full object-cover"
                                loading="lazy"
                              />
                            ) : file.type === 'video' ? (
                              <div className="w-full h-full flex items-center justify-center bg-neutral-900">
                                <Video className="w-8 h-8 text-white/60" />
                              </div>
                            ) : file.type === 'audio' ? (
                              <div className="w-full h-full flex items-center justify-center">
                                <Music className="w-8 h-8 text-muted-foreground/30" />
                              </div>
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <File className="w-8 h-8 text-muted-foreground/30" />
                              </div>
                            )}
                            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
                            {/* issue #294 子项 3：音视频/文件 tile 直接把文件名摆在底栏，
                                免得用户必须点开才能看出来这是哪个资源。图片自身就说明
                                了内容，不强制塞文件名。 */}
                            {file.type !== 'image' && file.fileName && (
                              <div
                                className="absolute inset-x-0 bottom-0 px-1.5 py-1 bg-gradient-to-t from-black/55 to-transparent text-[10px] leading-tight text-white truncate"
                                title={file.fileName}
                              >
                                {file.fileName}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Load More */}
                    {resourceFilesHasMore && (
                      <div className="flex justify-center pt-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 text-[12px] rounded-full"
                          onClick={() => {
                            const nextPage = galleryPage + 1
                            setGalleryPage(nextPage)
                            loadResourceFiles(galleryType, nextPage, 50, true, gallerySearchActive)
                          }}
                          disabled={resourceFilesLoading}
                        >
                          {resourceFilesLoading ? '加载中...' : '加载更多'}
                        </Button>
                      </div>
                    )}

                    {/* Empty */}
                    {!resourceFilesLoading && resourceFiles.length === 0 && (
                      <div className="flex flex-col items-center justify-center py-16 text-center">
                        <Image className="w-8 h-8 text-muted-foreground/20 mb-3" />
                        {gallerySearchActive ? (
                          <>
                            <p className="text-[13px] text-foreground font-medium">没有匹配的资源</p>
                            <p className="text-[12px] text-muted-foreground/60 mt-1">
                              没有文件名包含「{gallerySearchActive}」的资源
                            </p>
                          </>
                        ) : (
                          <>
                            <p className="text-[13px] text-foreground font-medium">暂无资源</p>
                            <p className="text-[12px] text-muted-foreground/60 mt-1">导出聊天记录后，资源将显示在这里</p>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* Resource Preview Modal */}
                <AnimatePresence>
                  {previewResource && (
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center"
                      onClick={() => setPreviewResource(null)}
                    >
                      <motion.div 
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between bg-gradient-to-b from-black/60 to-transparent"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <p className="text-white/80 text-sm truncate max-w-md">{previewResource.name}</p>
                        <div className="flex items-center gap-2">
                          <button
                            className="p-2.5 rounded-full bg-background/10 text-white hover:bg-background/20 transition-colors"
                            onClick={async (e) => {
                              e.stopPropagation()
                              try {
                                const response = await fetch(previewResource.url)
                                const blob = await response.blob()
                                const url = window.URL.createObjectURL(blob)
                                const a = document.createElement('a')
                                a.href = url
                                a.download = previewResource.name
                                document.body.appendChild(a)
                                a.click()
                                document.body.removeChild(a)
                                window.URL.revokeObjectURL(url)
                              } catch (err) {
                                console.error('下载失败:', err)
                              }
                            }}
                            title="下载"
                          >
                            <Download className="w-5 h-5" />
                          </button>
                          <button
                            onClick={() => setPreviewResource(null)}
                            className="p-2.5 rounded-full bg-background/10 text-white hover:bg-background/20 transition-colors"
                            title="关闭"
                          >
                            <X className="w-5 h-5" />
                          </button>
                        </div>
                      </motion.div>

                      <motion.div 
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.9 }}
                        transition={{ duration: 0.2 }}
                        className="max-w-[95vw] max-h-[85vh] flex items-center justify-center"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {previewResource.type === 'image' ? (
                          <img
                            src={previewResource.url}
                            alt={previewResource.name}
                            className="max-w-full max-h-[85vh] object-contain rounded-lg cursor-zoom-in"
                            onClick={(e) => {
                              e.stopPropagation()
                              window.open(previewResource.url, '_blank')
                            }}
                          />
                        ) : previewResource.type === 'video' ? (
                          <video
                            src={previewResource.url}
                            controls
                            autoPlay
                            className="max-w-full max-h-[85vh] rounded-lg"
                          />
                        ) : previewResource.type === 'audio' ? (
                          <div className="p-10 flex flex-col items-center justify-center bg-background/5 backdrop-blur rounded-2xl ">
                            <Music className="w-16 h-16 text-white/40 mb-6" />
                            <p className="text-white/70 mb-6 text-center max-w-xs truncate">{previewResource.name}</p>
                            <audio src={previewResource.url} controls autoPlay className="w-80" />
                          </div>
                        ) : (
                          <div className="p-10 flex flex-col items-center justify-center bg-background/5 backdrop-blur rounded-2xl ">
                            <File className="w-16 h-16 text-white/40 mb-6" />
                            <p className="text-white/70 mb-6 text-center max-w-xs truncate">{previewResource.name}</p>
                            <button
                              onClick={async () => {
                                try {
                                  const response = await fetch(previewResource.url)
                                  const blob = await response.blob()
                                  const url = window.URL.createObjectURL(blob)
                                  const a = document.createElement('a')
                                  a.href = url
                                  a.download = previewResource.name
                                  document.body.appendChild(a)
                                  a.click()
                                  document.body.removeChild(a)
                                  window.URL.revokeObjectURL(url)
                                } catch (err) {
                                  console.error('下载失败:', err)
                                }
                              }}
                              className="px-6 py-3 bg-background text-foreground rounded-xl hover:bg-muted transition-colors font-medium flex items-center gap-2"
                            >
                              <Download className="w-4 h-4" />
                              下载文件
                            </button>
                          </div>
                        )}
                      </motion.div>

                      <motion.p 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white/40 text-xs"
                      >
                        {previewResource.type === 'image' ? '点击图片在新窗口打开原图' : '按 ESC 或点击空白处关闭'}
                      </motion.p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}

            {/* ==================== STICKERS ==================== */}
            {activeTab === "stickers" && (
              <div className="p-5 space-y-4">
                {/* Filter Tabs */}
                {stickerPacks.length > 0 && (
                  <div className="flex items-center gap-0.5 px-1">
                    {[
                      { id: 'all', label: `全部 ${getStickerPacksStats().total}` },
                      { id: 'favorite', label: `收藏 ${getStickerPacksStats().favorite_emoji}` },
                      { id: 'market', label: `市场 ${getStickerPacksStats().market_pack}` },
                      { id: 'system', label: `系统 ${getStickerPacksStats().system_pack}` },
                    ].map(tab => {
                      const isActive = stickerFilter === tab.id;
                      return (
                        <button
                          key={tab.id}
                          onClick={() => setStickerFilter(tab.id as typeof stickerFilter)}
                          className={`px-2.5 py-1 rounded-full text-[12px] transition-colors ${
                            isActive 
                              ? 'bg-black/[0.05] dark:bg-white/[0.05] text-foreground font-medium' 
                              : 'text-muted-foreground/60 hover:text-muted-foreground'
                          }`}
                        >
                          {tab.label}
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* Sticker Packs List */}
                {stickerPacksLoading ? (
                  <div className="flex flex-col items-center justify-center py-20 text-center">
                    <Loader size={24} />
                    <p className="mt-3 text-[12px] text-muted-foreground/60">正在加载表情包...</p>
                  </div>
                ) : stickerPacksError ? (
                  <div className="flex flex-col items-center justify-center py-20 text-center">
                    <p className="text-[13px] font-medium text-foreground">表情包加载失败</p>
                    <p className="mt-1 max-w-md text-[12px] text-muted-foreground/60">{stickerPacksError}</p>
                    <Button
                      size="sm"
                      variant="outline"
                      className="mt-4 rounded-full"
                      onClick={() => void Promise.all([loadStickerPacks(), loadStickerExportRecords()])}
                    >
                      重试
                    </Button>
                  </div>
                ) : stickerPacks.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-20 text-center">
                    <Smile className="w-8 h-8 text-muted-foreground/20 mb-3" />
                    <p className="text-[13px] text-foreground font-medium">暂无表情包</p>
                    <p className="text-[12px] text-muted-foreground/60 mt-1">点击刷新按钮加载表情包数据</p>
                  </div>
                ) : (
                  <div className="space-y-0.5">
                    {stickerPacks
                      .filter(pack => {
                        if (stickerFilter === 'all') return true;
                        if (stickerFilter === 'favorite') return pack.packType === 'favorite_emoji';
                        if (stickerFilter === 'market') return pack.packType === 'market_pack';
                        if (stickerFilter === 'system') return pack.packType === 'system_pack';
                        return true;
                      })
                      .map((pack) => (
                        <div
                          key={pack.packId}
                          className="flex items-center justify-between px-3 py-2.5 rounded-lg hover:bg-black/[0.03] dark:hover:bg-white/[0.03] transition-colors group"
                        >
                          <div className="flex items-center gap-3 min-w-0 flex-1">
                            <span className="text-[13px] font-medium text-foreground truncate">
                              {pack.packName}
                            </span>
                            <span className="text-[11px] text-muted-foreground/40 flex-shrink-0">
                              {pack.stickerCount} 个
                            </span>
                            <span className="text-[10px] text-muted-foreground/40 bg-black/[0.03] dark:bg-white/[0.03] px-1.5 py-0.5 rounded flex-shrink-0">
                              {pack.packType === 'favorite_emoji' ? '收藏' : 
                               pack.packType === 'market_pack' ? '市场' : '系统'}
                            </span>
                          </div>
                          <button
                            className="text-[11px] text-muted-foreground/40 hover:text-foreground transition-colors flex-shrink-0 ml-4 opacity-0 group-hover:opacity-100"
                            onClick={() => handleExportStickerPack(pack.packId, pack.packName)}
                            disabled={stickerPacksLoading || stickerPacksExporting}
                          >
                            导出
                          </button>
                        </div>
                      ))}
                  </div>
                )}

                {/* Export History */}
                {stickerExportRecords.length > 0 && (
                  <div id="sticker-export-history" className="space-y-2 pt-2">
                    <h3 className="text-[12px] font-medium text-muted-foreground/50 px-1">导出记录</h3>
                    <div className="space-y-0.5">
                      {stickerExportRecords.slice(0, 5).map((record) => (
                        <div
                          key={record.id}
                          className="flex items-center justify-between px-3 py-2 rounded-lg hover:bg-black/[0.03] dark:hover:bg-white/[0.03] transition-colors group"
                        >
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <span className="text-[13px] font-medium text-foreground truncate">
                                {record.packName || '全部导出'}
                              </span>
                              {!record.success && (
                                <span className="text-[10px] text-red-500 bg-red-50 dark:bg-red-950/30 px-1.5 py-0.5 rounded">
                                  失败
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2 mt-0.5 text-[11px] text-muted-foreground/40">
                              <span>{record.stickerCount} 个表情</span>
                              <span aria-hidden className="h-2.5 w-px bg-current opacity-20" />
                              <span>{new Date(record.exportTime).toLocaleDateString()}</span>
                            </div>
                          </div>
                          {record.success && record.exportPath && (
                            <button
                              className="text-[11px] text-muted-foreground/40 hover:text-foreground transition-colors opacity-0 group-hover:opacity-100"
                              onClick={() => openFileLocation(record.exportPath)}
                            >
                              打开位置
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* ==================== SETTINGS ==================== */}
            {activeTab === "settings" && (
              <Suspense><SettingsPanel /></Suspense>
            )}

            {/* ==================== ABOUT ==================== */}
            {activeTab === "about" && (
              <Suspense><AboutPanel /></Suspense>
            )}
          </>
        </div>
      </div>

      {/* Modals */}
      <Suspense>
      <TaskWizard
        isOpen={isTaskWizardOpen}
        onClose={handleCloseTaskWizard}
        onSubmit={handleCreateTask}
        isLoading={isLoading}
        prefilledData={selectedPreset}
        groups={groups}
        friends={friends}
        onLoadData={loadChatData}
        isStandalone={isStandalone}
        taskStatsMap={taskStatsMap}
        onPreview={(chat) => {
          setPreviewingChat(chat)
          setIsPreviewModalOpen(true)
        }}
        onExportAvatars={handleExportGroupAvatars}
        avatarExportLoading={avatarExportLoading}
      />

      <ScheduledExportWizard
        isOpen={isScheduledExportWizardOpen}
        onClose={handleCloseScheduledExportWizard}
        onSubmit={async (form) => {
          if (editingScheduledExportId) {
            await updateScheduledExport(editingScheduledExportId, scheduledExportFormToConfig(form))
          } else {
            await createScheduledExport(form)
          }
          return true
        }}
        isLoading={scheduledLoading}
        prefilledData={selectedScheduledPreset}
        mode={editingScheduledExportId ? 'edit' : 'create'}
        groups={groups}
        friends={friends}
        onLoadData={loadChatData}
        taskStatsMap={taskStatsMap}
      />

      {selectedHistoryTask && (
        <ExecutionHistoryModal
          isOpen={isHistoryModalOpen}
          onClose={handleCloseHistoryModal}
          scheduledExportId={selectedHistoryTask.id}
          taskName={selectedHistoryTask.name}
          onGetHistory={getExecutionHistory}
        />
      )}

      <MessagePreviewModal
        open={isPreviewModalOpen}
        onClose={() => setIsPreviewModalOpen(false)}
        chat={previewingChat}
        onExport={(peer, timeRange) => {
          handleOpenTaskWizard({
            chatType: peer.chatType,
            peerUid: peer.peerUid,
            sessionName: previewingChat?.name,
            startTime: timeRange?.startTime?.toString(),
            endTime: timeRange?.endTime?.toString()
          })
        }}
      />

      <BatchExportDialog
        open={isBatchExportDialogOpen}
        onOpenChange={setIsBatchExportDialogOpen}
        items={getBatchExportItems()}
        onExport={handleBatchExport}
      />

      <ScheduledBackupMergeDialog
        open={isScheduledMergeDialogOpen}
        onOpenChange={setIsScheduledMergeDialogOpen}
        scheduledTasks={scheduledTasks}
        manualTasks={manualTasks}
        onMerge={handleScheduledMerge}
      />

      {/* 群精华消息模态框 */}
      {essenceGroup && (
        <GroupEssenceModal
          isOpen={isEssenceModalOpen}
          onClose={handleCloseEssenceModal}
          groupCode={essenceGroup.groupCode}
          groupName={essenceGroup.groupName}
          onOpenFileLocation={openFileLocation}
          onNotification={addNotification}
        />
      )}

      {/* 群文件/群相册模态框 */}
      {groupFilesTarget && (
        <GroupFilesModal
          isOpen={isGroupFilesModalOpen}
          onClose={handleCloseGroupFilesModal}
          groupCode={groupFilesTarget.groupCode}
          groupName={groupFilesTarget.groupName}
          onNotification={addNotification}
        />
      )}
      </Suspense>

      {/* 聊天记录预览模态框 */}
      <AnimatePresence>
        {isFilePathModalOpen && selectedFile && (() => {
          const fileName = selectedFile.fileName.toLowerCase()
          const isHtml = fileName.endsWith('.html') || fileName.endsWith('.htm')
          const isJson = fileName.endsWith('.json')
          const isZip = fileName.endsWith('.zip')
          const isJsonl = fileName.includes('_chunked_jsonl') || fileName.includes('jsonl')
          const fileSize = selectedFile.size || 0
          const isLargeFile = fileSize > 15 * 1024 * 1024
          const canPreview = (isHtml || isJson) && !isLargeFile && !isZip && !isJsonl
          
          const formatSize = (bytes: number) => {
            if (bytes === 0) return '0 B'
            const sizes = ['B', 'KB', 'MB', 'GB']
            const i = Math.floor(Math.log(bytes) / Math.log(1024))
            return (bytes / Math.pow(1024, i)).toFixed(1) + ' ' + sizes[i]
          }

          return (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.15 }}
                className="fixed inset-0 bg-background/80 z-[110]"
                onClick={handleCloseFilePathModal}
              />
              {canPreview ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.97, y: 8 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.97, y: 8 }}
                  transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
                  className="fixed inset-4 z-[111] flex flex-col bg-card rounded-2xl shadow-[0_24px_80px_rgba(0,0,0,0.12)] dark:shadow-[0_24px_80px_rgba(0,0,0,0.4)] overflow-hidden"
                >
                  <div className="flex items-center justify-between px-6 py-4">
                    <div className="flex items-center gap-3">
                      <span className="font-medium text-foreground">{selectedFile.sessionName}</span>
                      <span className="text-xs text-muted-foreground">HTML</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="rounded-full text-[13px]"
                        onClick={() => {
                          const link = document.createElement('a')
                          link.href = `/api/download-file?path=${encodeURIComponent(selectedFile.filePath)}&token=${encodeURIComponent(AuthManager.getInstance().getToken() || "")}`
                          link.download = selectedFile.fileName
                          link.click()
                        }}
                      >
                        下载
                      </Button>
                      <button
                        onClick={handleCloseFilePathModal}
                        className="p-2 text-muted-foreground/70 hover:text-muted-foreground hover:bg-muted rounded-lg transition-colors"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <iframe
                      src={`/api/exports/files/${encodeURIComponent(selectedFile.fileName)}/preview?token=${encodeURIComponent(AuthManager.getInstance().getToken() || "")}`}
                      className="w-full h-full border-0"
                      title={`预览 ${selectedFile.sessionName}`}
                    />
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, scale: 0.97, y: 8 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.97, y: 8 }}
                  transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
                  className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-md z-[111] bg-card rounded-2xl shadow-[0_24px_80px_rgba(0,0,0,0.12)] dark:shadow-[0_24px_80px_rgba(0,0,0,0.4)] overflow-hidden"
                >
                  <div className="p-8 text-center">
                    <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-muted flex items-center justify-center">
                      {isZip ? <Package className="w-8 h-8 text-muted-foreground/70" /> :
                       isJsonl ? <Database className="w-8 h-8 text-muted-foreground/70" /> :
                       <FileText className="w-8 h-8 text-muted-foreground/70" />}
                    </div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">
                      {selectedFile.sessionName}
                    </h3>
                    <div className="flex items-center justify-center gap-2 mb-4">
                      <Badge variant="outline">
                        {isZip ? 'ZIP' : isJsonl ? 'JSONL' : isJson ? 'JSON' : 'FILE'}
                      </Badge>
                      {fileSize > 0 && (
                        <span className="text-sm text-muted-foreground">{formatSize(fileSize)}</span>
                      )}
                    </div>
                    
                    <p className="text-muted-foreground mb-6">
                      {isZip || isJsonl ? (
                        '此格式不支持在线预览，请下载后查看'
                      ) : isLargeFile ? (
                        '文件较大，建议下载后用专业编辑器打开'
                      ) : (
                        '此格式不支持在线预览'
                      )}
                    </p>

                    <div className="space-y-3">
                      <Button
                        className="w-full rounded-xl"
                        onClick={() => {
                          const link = document.createElement('a')
                          link.href = `/api/download-file?path=${encodeURIComponent(selectedFile.filePath)}&token=${encodeURIComponent(AuthManager.getInstance().getToken() || "")}`
                          link.download = selectedFile.fileName
                          link.click()
                        }}
                      >
                        下载文件
                      </Button>
                      
                      {(isJson || isJsonl || isLargeFile) && (
                        <div className="pt-3 border-t border-border">
                          <p className="text-xs text-muted-foreground/70 mb-3">推荐使用以下编辑器打开</p>
                          <div className="flex gap-2 justify-center">
                            <a
                              href="https://code.visualstudio.com/"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-colors"
                            >
                              VS Code
                            </a>
                            <a
                              href="https://zed.dev/"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-colors"
                            >
                              Zed
                            </a>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="px-6 py-4">
                    <Button
                      variant="ghost"
                      className="w-full rounded-full"
                      onClick={handleCloseFilePathModal}
                    >
                      关闭
                    </Button>
                  </div>
                </motion.div>
              )}
            </>
          )
        })()}
      </AnimatePresence>

      <ExportHelpDialog
        open={exportHelpOpen}
        format={exportHelpFormat}
        filePath={helpFilePath || undefined}
        onClose={() => setExportHelpOpen(false)}
        onOpenFileLocation={openFileLocation}
        onOpenExportDirectory={openExportDirectory}
      />

      {/* 新手引导 */}
      {showOnboarding && (() => {
        // step 0: 欢迎模态框
        // step 1: 指向「会话」
        // step 2: 在会话页，提示点击导出按钮
        // step 3: 指向「任务」看进度
        // step 4: 指向「聊天记录」查看文件
        
        // 欢迎模态框
        if (onboardingStep === 0) {
          return (
            <>
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={onboardingTransition}
                className="fixed inset-0 z-[100] bg-black/34 backdrop-blur-md" 
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.96, y: 18, filter: "blur(16px)" }}
                animate={{ opacity: 1, scale: 1, y: 0, filter: "blur(0px)" }}
                transition={onboardingTransition}
                className="fixed left-1/2 top-1/2 z-[101] w-full max-w-sm -translate-x-1/2 -translate-y-1/2 overflow-hidden rounded-[28px] bg-background/95 p-6 shadow-[0_28px_110px_rgba(15,23,42,0.28)] backdrop-blur-2xl "
              >
                <h2 className="text-xl font-medium text-foreground mb-2">欢迎使用</h2>
                <p className="text-muted-foreground text-sm mb-6">
                  QQ Chat Exporter 可以导出你的聊天记录。<br/>
                  花 30 秒了解一下基本操作？
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      localStorage.setItem("qce-onboarding-completed", "true")
                      setShowOnboarding(false)
                      setHighlightedNav(null)
                    }}
                    className="flex-1 py-2.5 text-sm text-muted-foreground hover:text-foreground"
                  >
                    跳过
                  </button>
                  <button
                    onClick={() => { setOnboardingStep(1); setHighlightedNav("sessions"); }}
                    className="flex-1 rounded-full bg-blue-600 py-2.5 text-sm font-medium text-white transition-colors hover:bg-blue-700"
                  >
                    开始
                  </button>
                </div>
              </motion.div>
            </>
          )
        }
        
        // 指向「会话」
        if (onboardingStep === 1) {
          const position = getAnchoredOnboardingPosition('nav-sessions', 280)
          const targetEl = typeof document !== 'undefined' ? document.getElementById('nav-sessions') : null
          if (!position || !targetEl) return null
          
          return (
            <motion.div 
              className="fixed z-[100]"
              initial={{ opacity: 0, scale: 0.96, y: 12, filter: "blur(12px)" }}
              animate={{ left: position.left, top: position.top, opacity: 1, scale: 1, y: 0, filter: "blur(0px)" }}
              transition={onboardingTransition}
            >
              <div className={onboardingPanelClass} style={{ width: 280 }}>
                <p className="text-sm font-medium mb-1">第 1 步：打开会话列表</p>
                <p className="text-muted-foreground text-xs mb-3">点击「会话」查看所有群聊和好友</p>
                <button
                  onClick={() => {
                    targetEl?.click()
                    setOnboardingStep(2)
                    setHighlightedNav(null)
                  }}
                  className={onboardingPrimaryButtonClass}
                >
                  点击前往
                </button>
                <button
                  onClick={() => {
                    localStorage.setItem("qce-onboarding-completed", "true")
                    setShowOnboarding(false)
                    setHighlightedNav(null)
                  }}
                  className={`${onboardingSecondaryButtonClass} mt-2`}
                >
                  跳过引导
                </button>
              </div>
            </motion.div>
          )
        }
        
        // 在会话页，提示点击导出
        if (onboardingStep === 2 && activeTab === 'sessions') {
          const position = getBottomOnboardingPosition(340)
          if (!position) return null

          return (
            <motion.div
              className="fixed z-[100]"
              initial={{ opacity: 0, scale: 0.96, y: 18, filter: "blur(12px)" }}
              animate={{ left: position.left, top: position.top, opacity: 1, scale: 1, y: 0, filter: "blur(0px)" }}
              transition={onboardingTransition}
            >
              <div className={onboardingPanelClass} style={{ width: 340 }}>
                <p className="text-sm font-medium mb-1">第 2 步：选择并导出</p>
                <p className="text-muted-foreground text-xs mb-3">
                  普通导出可直接点「导出」；私聊漫游记录请点右侧箭头选择「漫游导出」。列表里找不到联系人时，可在搜索框输入 QQ 号反查。
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      localStorage.setItem("qce-onboarding-completed", "true")
                    setShowOnboarding(false)
                    setHighlightedNav(null)
                  }}
                    className="flex-1 rounded-full px-4 py-2 text-xs text-muted-foreground transition-colors hover:text-foreground"
                  >
                    我知道了
                  </button>
                  <button
                    onClick={() => { setOnboardingStep(3); setHighlightedNav("tasks"); }}
                    className="flex-1 rounded-full bg-blue-600 px-4 py-2 text-xs font-medium text-white transition-colors hover:bg-blue-700"
                  >
                    下一步
                  </button>
                </div>
              </div>
            </motion.div>
          )
        }
        
        // 指向「任务」看进度
        if (onboardingStep === 3) {
          const position = getAnchoredOnboardingPosition('nav-tasks', 280)
          if (!position) return null
          
          return (
            <motion.div 
              className="fixed z-[100]"
              initial={{ opacity: 0, scale: 0.96, y: 12, filter: "blur(12px)" }}
              animate={{ left: position.left, top: position.top, opacity: 1, scale: 1, y: 0, filter: "blur(0px)" }}
              transition={onboardingTransition}
            >
              <div className={onboardingPanelClass} style={{ width: 280 }}>
                <p className="text-sm font-medium mb-1">第 3 步：查看导出进度</p>
                <p className="text-muted-foreground text-xs mb-3">
                  在「任务」页面可以看到导出进度和状态
                </p>
                <button
                  onClick={() => { setOnboardingStep(4); setHighlightedNav("history"); }}
                  className={onboardingPrimaryButtonClass}
                >
                  下一步
                </button>
                <button
                  onClick={() => {
                    localStorage.setItem("qce-onboarding-completed", "true")
                    setShowOnboarding(false)
                    setHighlightedNav(null)
                  }}
                  className={`${onboardingSecondaryButtonClass} mt-2`}
                >
                  跳过引导
                </button>
              </div>
            </motion.div>
          )
        }
        
        // 指向「聊天记录」查看文件
        if (onboardingStep === 4) {
          const position = getAnchoredOnboardingPosition('nav-history', 300)
          if (!position) return null
          
          return (
            <motion.div 
              className="fixed z-[100]"
              initial={{ opacity: 0, scale: 0.96, y: 12, filter: "blur(12px)" }}
              animate={{ left: position.left, top: position.top, opacity: 1, scale: 1, y: 0, filter: "blur(0px)" }}
              transition={onboardingTransition}
            >
              <div className={onboardingPanelClass} style={{ width: 300 }}>
                <p className="text-sm font-medium mb-1">第 4 步：查看导出文件</p>
                <p className="text-muted-foreground text-xs mb-3">
                  导出完成后，在「聊天记录」可以查看、下载、预览所有文件
                </p>
                <button
                  onClick={() => {
                    localStorage.setItem("qce-onboarding-completed", "true")
                    setShowOnboarding(false)
                    setHighlightedNav(null)
                  }}
                  className={onboardingPrimaryButtonClass}
                >
                  完成
                </button>
              </div>
            </motion.div>
          )
        }
        
        return null
      })()}
    </div>
  )
}
