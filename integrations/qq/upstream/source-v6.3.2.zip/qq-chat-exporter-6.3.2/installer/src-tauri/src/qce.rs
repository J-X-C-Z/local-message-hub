//! QCE (QQ Chat Exporter) runtime helpers: detect the HTTP server, build the
//! one-click WebUI link from `security.json`, and open the log file.

use std::path::PathBuf;
use std::time::Duration;

use serde::Serialize;
use serde_json::Value;
use tauri::{LogicalSize, State, WebviewWindow};

use crate::state::{AppState, Inner};
use crate::util::{self, QCE_PORT};

fn log(state: &State<'_, AppState>, msg: &str) {
    if let Some(dir) = install_dir(state) {
        util::installer_log(&dir, msg);
    }
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RunningInfo {
    pub running: bool,
    pub webui_url: Option<String>,
}

fn install_dir(state: &State<'_, AppState>) -> Option<PathBuf> {
    state.0.lock().ok().and_then(|s| s.install_dir())
}

/// Read the QCE access token from `security.json`. Prefer the install-local
/// config dir (we pin it via `QCE_CONFIG_DIR`); fall back to the user profile.
fn read_access_token(state: &State<'_, AppState>) -> Option<String> {
    let mut candidates: Vec<PathBuf> = Vec::new();
    if let Some(dir) = install_dir(state) {
        candidates.push(util::qce_config_dir(&dir).join("security.json"));
    }
    if let Some(home) = dirs::home_dir() {
        candidates.push(home.join(".qq-chat-exporter").join("security.json"));
    }
    for path in &candidates {
        if let Ok(text) = std::fs::read_to_string(path) {
            if let Ok(json) = serde_json::from_str::<Value>(&text) {
                if let Some(tok) = json.get("accessToken").and_then(Value::as_str) {
                    if !tok.is_empty() {
                        return Some(tok.to_string());
                    }
                }
            }
        }
    }
    log(
        state,
        &format!("access token not found in {:?}", candidates),
    );
    None
}

fn get_webui_url_inner(state: &State<'_, AppState>) -> Option<String> {
    let base = format!("http://127.0.0.1:{QCE_PORT}/qce");
    match read_access_token(state) {
        Some(token) => Some(format!("{base}/auth?token={}", urlencode(&token))),
        None => Some(base),
    }
}

fn take_webui_url_ready_log_slot_inner(inner: &mut Inner) -> bool {
    if inner.webui_url_ready_logged {
        false
    } else {
        inner.webui_url_ready_logged = true;
        true
    }
}

fn take_webui_url_ready_log_slot(state: &State<'_, AppState>) -> bool {
    state
        .0
        .lock()
        .map(|mut inner| take_webui_url_ready_log_slot_inner(&mut inner))
        .unwrap_or(false)
}

#[tauri::command]
pub fn get_webui_url(state: State<'_, AppState>) -> Option<String> {
    get_webui_url_inner(&state)
}

/// Turn the launcher window into the application window: resize it to a
/// normal desktop size and navigate the same webview to the WebUI. The window
/// stays undecorated; the WebUI draws its own titlebar controls (see the
/// `webui` capability, which grants that origin window controls only). The
/// access token stays inside the app (no browser history / address bar).
#[tauri::command]
pub fn enter_app(window: WebviewWindow, state: State<'_, AppState>) -> Result<(), String> {
    let url = get_webui_url_inner(&state)
        .ok_or("webui url unavailable")?
        .parse()
        .map_err(|e| format!("invalid webui url: {e}"))?;
    window.set_resizable(true).map_err(|e| e.to_string())?;
    window.set_maximizable(true).map_err(|e| e.to_string())?;
    window
        .set_min_size(Some(LogicalSize::new(960.0, 640.0)))
        .map_err(|e| e.to_string())?;
    window
        .set_size(LogicalSize::new(1200.0, 800.0))
        .map_err(|e| e.to_string())?;
    window.center().map_err(|e| e.to_string())?;
    window.navigate(url).map_err(|e| e.to_string())?;
    log(&state, "entered app window");
    Ok(())
}

#[tauri::command]
pub async fn qce_status(state: State<'_, AppState>) -> Result<RunningInfo, String> {
    let running = probe_qce().await;
    let webui_url = if running {
        // QCE's SecurityManager may still be writing security.json right
        // after the HTTP server starts.  Retry a few times so we don't
        // hand the frontend a URL without a token.
        let mut url = get_webui_url_inner(&state);
        if running && url.as_ref().map(|u| !u.contains("token=")).unwrap_or(true) {
            for _ in 0..4 {
                tokio::time::sleep(Duration::from_millis(500)).await;
                url = get_webui_url_inner(&state);
                if url.as_ref().map(|u| u.contains("token=")).unwrap_or(false) {
                    break;
                }
            }
        }
        if url.is_some() && take_webui_url_ready_log_slot(&state) {
            log(&state, "webui url ready");
        }
        url
    } else {
        None
    };
    Ok(RunningInfo { running, webui_url })
}

async fn probe_qce() -> bool {
    let client = match reqwest::Client::builder()
        .timeout(Duration::from_millis(1200))
        .build()
    {
        Ok(c) => c,
        Err(_) => return false,
    };
    // The frontend route returns 200 once QCE is serving.
    client
        .get(format!("http://127.0.0.1:{QCE_PORT}/qce"))
        .send()
        .await
        .map(|r| r.status().is_success() || r.status().is_redirection())
        .unwrap_or(false)
}

#[tauri::command]
pub fn open_log_file(state: State<'_, AppState>) -> Result<(), String> {
    let dir = install_dir(&state).ok_or_else(|| "尚未安装".to_string())?;
    let log = util::log_file_path(&dir);
    if !log.exists() {
        if let Some(parent) = log.parent() {
            let _ = std::fs::create_dir_all(parent);
        }
        let _ = std::fs::write(&log, b"");
    }
    open_path(&log)
}

fn open_path(path: &std::path::Path) -> Result<(), String> {
    #[cfg(windows)]
    {
        // 用记事本直接打开：`cmd /C start` 依赖文件关联，某些环境下会静默失败。
        std::process::Command::new("notepad")
            .arg(path)
            .spawn()
            .map_err(|e| e.to_string())?;
    }
    #[cfg(target_os = "macos")]
    {
        std::process::Command::new("open")
            .arg(path)
            .status()
            .map_err(|e| e.to_string())?;
    }
    #[cfg(all(not(windows), not(target_os = "macos")))]
    {
        std::process::Command::new("xdg-open")
            .arg(path)
            .status()
            .map_err(|e| e.to_string())?;
    }
    Ok(())
}

fn urlencode(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for b in s.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                out.push(b as char)
            }
            _ => out.push_str(&format!("%{b:02X}")),
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::take_webui_url_ready_log_slot_inner;
    use crate::state::Inner;

    #[test]
    fn webui_ready_is_logged_once_per_app_session() {
        let mut inner = Inner::default();
        assert!(take_webui_url_ready_log_slot_inner(&mut inner));
        assert!(!take_webui_url_ready_log_slot_inner(&mut inner));

        inner.webui_url_ready_logged = false;
        assert!(take_webui_url_ready_log_slot_inner(&mut inner));
    }
}
